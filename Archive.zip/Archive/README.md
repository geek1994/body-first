# Body First
# 
# 
# 
# 
# Build Command
ionic cordova build android --prod --aot --minifyjs --minifycss --optimizejs