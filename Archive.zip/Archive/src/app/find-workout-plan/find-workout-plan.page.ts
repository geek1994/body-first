import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-find-workout-plan',
  templateUrl: './find-workout-plan.page.html',
  styleUrls: ['./find-workout-plan.page.scss'],
})
export class FindWorkoutPlanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
