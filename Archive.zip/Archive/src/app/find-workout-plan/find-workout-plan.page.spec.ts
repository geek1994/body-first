import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FindWorkoutPlanPage } from './find-workout-plan.page';

describe('FindWorkoutPlanPage', () => {
  let component: FindWorkoutPlanPage;
  let fixture: ComponentFixture<FindWorkoutPlanPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindWorkoutPlanPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FindWorkoutPlanPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
