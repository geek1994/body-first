import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DetailspiritPage } from './detailspirit.page';

const routes: Routes = [
  {
    path: '',
    component: DetailspiritPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DetailspiritPageRoutingModule {}
