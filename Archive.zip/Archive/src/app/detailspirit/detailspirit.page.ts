import { Component, OnInit } from '@angular/core';
import { NavController ,ModalController} from "@ionic/angular";
import { ActivatedRoute, Router } from '@angular/router';

// import { NavParams ,Events} from '@ionic/angular';
@Component({
  selector: 'app-detailspirit',
  templateUrl: './detailspirit.page.html',
  styleUrls: ['./detailspirit.page.scss'],
})
export class DetailspiritPage implements OnInit {
data:any='';
type:any='';
  constructor(public modalController: ModalController,public route:ActivatedRoute) { 
    // this.data = this.navParams.get('data');
    // this.type = this.navParams.get('type');
    console.log(this.data, "data");
    this.route.queryParams.subscribe(params => {
      if (params && params.data) {
        this.data = params.data;
        console.log(this.data);    
      }
      if (params && params.type) {
        this.type = params.type;
        console.log(this.type);
    
      }
    });
  }

  ngOnInit() {
  }
  back(){
    this.modalController.dismiss();
  //  this.navCtrl.navigateBack(['/exercises'],{ queryParams: { type: 'guid' }});
  }
}
