import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DetailspiritPage } from './detailspirit.page';

describe('DetailspiritPage', () => {
  let component: DetailspiritPage;
  let fixture: ComponentFixture<DetailspiritPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailspiritPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DetailspiritPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
