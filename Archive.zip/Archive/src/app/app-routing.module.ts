import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'signup',
    loadChildren: () => import('./signup/signup.module').then( m => m.SignupPageModule)
  },
  {
    path: 'bodyfirst-program',
    loadChildren: () => import('./bodyfirst-program/bodyfirst-program.module').then( m => m.BodyfirstProgramPageModule)
  },
  {
    path: 'week-workout',
    loadChildren: () => import('./week-workout/week-workout.module').then( m => m.WeekWorkoutPageModule)
  },
  {
    path: 'edit-profile',
    loadChildren: () => import('./edit-profile/edit-profile.module').then( m => m.EditProfilePageModule)
  },
  {
    path: 'card-information',
    loadChildren: () => import('./card-information/card-information.module').then( m => m.CardInformationPageModule)
  },
  {
    path: 'exercises',
    loadChildren: () => import('./exercises/exercises.module').then( m => m.ExercisesPageModule)
  },
  {
    path: 'mindset',
    loadChildren: () => import('./mindset/mindset.module').then( m => m.MindsetPageModule)
  },
  {
    path: 'nutrition',
    loadChildren: () => import('./nutrition/nutrition.module').then( m => m.NutritionPageModule)
  },
  {
    path: 'spirit',
    loadChildren: () => import('./spirit/spirit.module').then( m => m.SpiritPageModule)
  },
  {
    path: 'abs',
    loadChildren: () => import('./abs/abs.module').then( m => m.AbsPageModule)
  },
  {
    path: 'functional',
    loadChildren: () => import('./functional/functional.module').then( m => m.FunctionalPageModule)
  },
  {
    path: 'survey',
    loadChildren: () => import('./survey/survey.module').then( m => m.SurveyPageModule)
  },
  {
    path: 'profile',
    loadChildren: () => import('./profile/profile.module').then( m => m.ProfilePageModule)
  },  {
    path: 'mobility-flexibility',
    loadChildren: () => import('./mobility-flexibility/mobility-flexibility.module').then( m => m.MobilityFlexibilityPageModule)
  },
  {
    path: 'balance-coordination',
    loadChildren: () => import('./balance-coordination/balance-coordination.module').then( m => m.BalanceCoordinationPageModule)
  },
  {
    path: 'core-conditioning',
    loadChildren: () => import('./core-conditioning/core-conditioning.module').then( m => m.CoreConditioningPageModule)
  },
  {
    path: 'liked-exercises',
    loadChildren: () => import('./liked-exercises/liked-exercises.module').then( m => m.LikedExercisesPageModule)
  },
  {
    path: 'settings',
    loadChildren: () => import('./settings/settings.module').then( m => m.SettingsPageModule)
  },
  {
    path: 'assessment',
    loadChildren: () => import('./assessment/assessment.module').then( m => m.AssessmentPageModule)
  },
  {
    path: 'find-workout-plan',
    loadChildren: () => import('./find-workout-plan/find-workout-plan.module').then( m => m.FindWorkoutPlanPageModule)
  },
  {
    path: 'selected-plan',
    loadChildren: () => import('./selected-plan/selected-plan.module').then( m => m.SelectedPlanPageModule)
  },
  {
    path: 'videos',
    loadChildren: () => import('./videos/videos.module').then( m => m.VideosPageModule)
  },
  {
    path: 'subscription',
    loadChildren: () => import('./subscription/subscription.module').then( m => m.SubscriptionPageModule)
  },
  {
    path: 'search-exercises',
    loadChildren: () => import('./search-exercises/search-exercises.module').then( m => m.SearchExercisesPageModule)
  },
  {
    path: 'subscriptions',
    loadChildren: () => import('./subscriptions/subscriptions.module').then( m => m.SubscriptionsPageModule)
  },
  {
    path: 'body-weight',
    loadChildren: () => import('./body-weight/body-weight.module').then( m => m.BodyWeightPageModule)
  },
  {
    path: 'detailspirit',
    loadChildren: () => import('./detailspirit/detailspirit.module').then( m => m.DetailspiritPageModule)
  },

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
