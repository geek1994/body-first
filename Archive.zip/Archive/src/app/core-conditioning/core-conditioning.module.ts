import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CoreConditioningPageRoutingModule } from './core-conditioning-routing.module';

import { CoreConditioningPage } from './core-conditioning.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CoreConditioningPageRoutingModule
  ],
  declarations: [CoreConditioningPage]
})
export class CoreConditioningPageModule {}
