import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CoreConditioningPage } from './core-conditioning.page';

const routes: Routes = [
  {
    path: '',
    component: CoreConditioningPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CoreConditioningPageRoutingModule {}
