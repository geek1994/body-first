import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { CoreConditioningPage } from './core-conditioning.page';

describe('CoreConditioningPage', () => {
  let component: CoreConditioningPage;
  let fixture: ComponentFixture<CoreConditioningPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoreConditioningPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(CoreConditioningPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
