import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-core-conditioning',
  templateUrl: './core-conditioning.page.html',
  styleUrls: ['./core-conditioning.page.scss'],
})
export class CoreConditioningPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
