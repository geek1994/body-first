import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-balance-coordination',
  templateUrl: './balance-coordination.page.html',
  styleUrls: ['./balance-coordination.page.scss'],
})
export class BalanceCoordinationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
