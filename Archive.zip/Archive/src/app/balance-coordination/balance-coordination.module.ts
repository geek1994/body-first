import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BalanceCoordinationPageRoutingModule } from './balance-coordination-routing.module';

import { BalanceCoordinationPage } from './balance-coordination.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BalanceCoordinationPageRoutingModule
  ],
  declarations: [BalanceCoordinationPage]
})
export class BalanceCoordinationPageModule {}
