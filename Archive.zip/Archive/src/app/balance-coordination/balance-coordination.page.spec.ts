import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { BalanceCoordinationPage } from './balance-coordination.page';

describe('BalanceCoordinationPage', () => {
  let component: BalanceCoordinationPage;
  let fixture: ComponentFixture<BalanceCoordinationPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BalanceCoordinationPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(BalanceCoordinationPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
