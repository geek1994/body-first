import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BalanceCoordinationPage } from './balance-coordination.page';

const routes: Routes = [
  {
    path: '',
    component: BalanceCoordinationPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BalanceCoordinationPageRoutingModule {}
