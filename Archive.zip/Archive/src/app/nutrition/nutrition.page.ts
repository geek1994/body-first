import { Component, OnInit } from '@angular/core';
import { NavController,ModalController } from "@ionic/angular";
import { Router, ActivatedRoute  } from "@angular/router";
import { SearchExercisesPage } from '..//search-exercises/search-exercises.page';
import { DomSanitizer, SafeResourceUrl } from "@angular/platform-browser";
import { DetailspiritPage } from '../detailspirit/detailspirit.page';

@Component({
  selector: 'app-nutrition',
  templateUrl: './nutrition.page.html',
  styleUrls: ['./nutrition.page.scss'],
})
export class NutritionPage implements OnInit {
  nutritiontData:any=[];
  nutritiontArray:any=[];
  type: any = 'mens-guid';
  toggled:boolean=false;
  searchTerm:any='';
  
  constructor(public modalController: ModalController,public sanitizer: DomSanitizer,public navCtrl: NavController, public router: Router, private route: ActivatedRoute) { 
    this.route.queryParams.subscribe(params => {
      this.type = params["type"];
      if(this.type == 'videos'){
           this.nutritiontData=[
          {'id': 1, 'title': 'Endurance Atheletes',url: "https://www.youtube.com/watch?v=mUns8O4YL5M" ,'image': 'assets/images/n1.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
          {'id': 2, 'title': 'Speed Recovery', url: "https://www.youtube.com/watch?v=jZK1m2G1nyQ" ,'image': 'assets/images/n1.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
         ]   
      var that = this;
      this.nutritiontArray=[];
      this.nutritiontData.forEach((element) => {   
        if (element.url != null) {
          const url = that.validateYouTubeUrl(element.url);
          console.log("url:- ", url);
          const pos = element.url.indexOf("watch");
          console.log(pos);
          if (pos !== -1) {
            element.url = element.url.replace("watch?v=", "embed/");
          } else {
            const pos = element.url.indexOf("youtu.be"); // 0
            if (pos !== -1) {
              element.url.replace(
                "youtu.be",
                "www.youtube.com/embed/" + url.vidId
              );
            } else {
              element.url;
            }
          }
          console.log("element:-----", element.url);
          element[
            "trustedVideoUrl"
          ] = this.sanitizer.bypassSecurityTrustResourceUrl(element.url);
          console.log("ooooo", element);
        }
        this.nutritiontArray.push(element);
        console.log(this.nutritiontArray);
      });
    }
    });
  }
  async search() {
    const modal = await this.modalController.create({
      component: SearchExercisesPage
    });
    return await modal.present();
  }
  ngOnInit() {
  }
  showDefaultBar() {
    if(this.toggled){
      this.toggled =false
    }else{
    this.toggled = true;
    }
  }
  clearData(){
    this.searchTerm= '';
  
  }
  validateYouTubeUrl(element: any) {
    if (element !== undefined || element !== "") {
      console.log("URL-->", element);
      const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|\?v=)([^#\&\?]*).*/;
      const match = element.match(regExp);
      if (match && match[2].length === 11) {
        console.log("MATCH YOUTUBE", match[2]);
        return { type: "youtube", vidId: match[2] };
      } else {
        return { type: "video" };
      }
    }
  }
  async detail(data, type) {
    var value_type;
    if(!type){
      value_type ='';
    }else{
      value_type =type;
    }
    const modal = await this.modalController.create({
      component: DetailspiritPage,
      componentProps: { data: data , type:value_type}
    });
    return await modal.present();
  }
  onSearchChange(){
    this.nutritiontArray =[]; 
      console.log(this.searchTerm);
        this.nutritiontData.filter((element,key) => {
          if (element.title && this.searchTerm!= '') {
            console.log(element.title.toLowerCase().indexOf(this.searchTerm.toLowerCase()));
        
            // return (element.title.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);
            if(element.title.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1){
             this.nutritiontArray.push(element);
            }
          }           
      });
      console.log(this.nutritiontArray)
      if(this.searchTerm == ''){
        this.nutritiontData=[
          {'id': 1, 'title': 'Endurance Atheletes',url: "https://www.youtube.com/watch?v=mUns8O4YL5M" ,'image': 'assets/images/n1.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
          {'id': 2, 'title': 'Speed Recovery', url: "https://www.youtube.com/watch?v=jZK1m2G1nyQ" ,'image': 'assets/images/n1.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
         ]   
      var that = this;
      this.nutritiontArray=[];
      this.nutritiontData.forEach((element) => {   
        if (element.url != null) {
          const url = that.validateYouTubeUrl(element.url);
          console.log("url:- ", url);
          const pos = element.url.indexOf("watch");
          console.log(pos);
          if (pos !== -1) {
            element.url = element.url.replace("watch?v=", "embed/");
          } else {
            const pos = element.url.indexOf("youtu.be"); // 0
            if (pos !== -1) {
              element.url.replace(
                "youtu.be",
                "www.youtube.com/embed/" + url.vidId
              );
            } else {
              element.url;
            }
          }
          console.log("element:-----", element.url);
          element[
            "trustedVideoUrl"
          ] = this.sanitizer.bypassSecurityTrustResourceUrl(element.url);
          console.log("ooooo", element);
        }
        this.nutritiontArray.push(element);
        console.log(this.nutritiontArray);
      });
      }
    }
}
