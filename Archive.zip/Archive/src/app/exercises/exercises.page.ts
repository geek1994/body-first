import { Component, OnInit } from "@angular/core";
import { NavController ,ModalController} from "@ionic/angular";
import { Router, ActivatedRoute } from "@angular/router";
import { SearchExercisesPage } from '..//search-exercises/search-exercises.page';
@Component({
  selector: "app-exercises",
  templateUrl: "./exercises.page.html",
  styleUrls: ["./exercises.page.scss"],
})
export class ExercisesPage implements OnInit {
  type: any = "guid";
  constructor(
    public navCtrl: NavController,
    public router: Router,
    private route: ActivatedRoute,
    public modalController: ModalController
  ) {
    this.route.queryParams.subscribe((params) => {
      this.type = params["type"];
    });
  }
  async search() {
    const modal = await this.modalController.create({
      component: SearchExercisesPage
    });
    return await modal.present();
  }
  mobility() {
    this.navCtrl.navigateForward("/mobility-flexibility");
  }
  balance() {
    this.navCtrl.navigateForward("/balance-coordination");
  }
  core() {
    this.navCtrl.navigateForward("/core-conditioning");
  }
  functional() {
    this.navCtrl.navigateForward("/functional");
  }
  // search() {
  //   this.navCtrl.navigateForward("/search-exercises");
  // }
  ngOnInit() {}
}
