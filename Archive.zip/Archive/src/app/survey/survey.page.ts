import { Component, OnInit } from "@angular/core";
import { NavController } from "@ionic/angular";
import { Router, NavigationExtras } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { EventsService } from '../service/events.service';

@Component({
  selector: "app-survey",
  templateUrl: "./survey.page.html",
  styleUrls: ["./survey.page.scss"],
})
export class SurveyPage implements OnInit {
  public surveyForm: FormGroup;
  constructor(public navCtrl: NavController, public router: Router,  public formBuilder: FormBuilder,public events:EventsService) {
    this.surveyForm = this.formBuilder.group({
      gender: ["", Validators.compose([Validators.required])],
      experience: ["", Validators.compose([Validators.required])],
      goal: ["", Validators.compose([Validators.required])],
      // gender:  ['', Validators.compose([Validators.required])],
    });
  }

  ngOnInit() {}
  search() {
    this.navCtrl.navigateForward("/search-exercises");
  }
  update() {
    var user ={
      gender: this.surveyForm.value.gender,
      experience: this.surveyForm.value.experience,
      goal: this.surveyForm.value.goal,
      name: JSON.parse(localStorage.getItem('userData')).name,
      email: JSON.parse(localStorage.getItem('userData')).email,
    }
    localStorage.setItem('userData', JSON.stringify(user));
    this.events.publish('user:created', {user: JSON.stringify(user)});
    this.navCtrl.navigateRoot('/profile');
    // let navigationExtras: NavigationExtras = {
    //   queryParams: {
    //     back: true,
    //   },
    // };
    // this.navCtrl.navigateForward(["profile"], navigationExtras);
    // this.router.navigate(["profile", { back: true }]);
  }
}
