import { Component, OnInit } from '@angular/core';
import { NavController } from "@ionic/angular";
import { ApiService } from "../service/api.service";
@Component({
  selector: 'app-subscriptions',
  templateUrl: './subscriptions.page.html',
  styleUrls: ['./subscriptions.page.scss'],
})
export class SubscriptionsPage implements OnInit {
  subscriptionData:any=[];
  constructor(public navCtrl: NavController,public api: ApiService) { 
    this.subscriptionData=[{
      'trial_name':'3 Months',
      'trial_payment':'$ 44.99',
      'trial_type': 'test',
      'id':1
    },{
      'trial_name':'1 Months',
      'trial_payment':'$ 14.99',
      'trial_type': 'test',
      'id':2
    }
  ]
  }

  ngOnInit() {
    this.getSuuscription();
  }

  purchasePlan() {
    this.navCtrl.navigateForward('/card-information');
  }
  getSuuscription() {
    console.log("gettt")
    this.api.get("/getPlans").subscribe((res: any) => {
      console.log(res, "data");
      if(res['success']){
        this.subscriptionData = res['data'];
      }else{
        this.subscriptionData = [];
      }
     });
  }

}
