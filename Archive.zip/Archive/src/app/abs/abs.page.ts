import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-abs',
  templateUrl: './abs.page.html',
  styleUrls: ['./abs.page.scss'],
})
export class AbsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
