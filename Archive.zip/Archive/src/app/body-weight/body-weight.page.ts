import { Component, OnInit } from "@angular/core";
import { DomSanitizer, SafeResourceUrl } from "@angular/platform-browser";

@Component({
  selector: "app-body-weight",
  templateUrl: "./body-weight.page.html",
  styleUrls: ["./body-weight.page.scss"],
})
export class BodyWeightPage implements OnInit {
  public weightData = [
    { id: 1, url: "https://www.youtube.com/watch?v=mUns8O4YL5M" },
    { id: 2, url: "https://www.youtube.com/watch?v=oAPCPjnU1wA" },
    { id: 3, url: "https://www.youtube.com/watch?v=dJlFmxiL11s" },
    { id: 4, url: "https://www.youtube.com/watch?v=GFus5TyIlCM" },
    { id: 5, url: "https://www.youtube.com/watch?v=zTPfzlZbtz8" },
    { id: 6, url: "https://www.youtube.com/watch?v=jZK1m2G1nyQ" },
  ];
  body_list: any = [];
  // isSpinner :boolean=false;
  constructor(public sanitizer: DomSanitizer) {
    var that = this;
    // this.isSpinner = true;
    this.weightData.forEach((element) => {
      if (element.url != null) {
        const url = that.validateYouTubeUrl(element.url);
        console.log("url:- ", url);
        const pos = element.url.indexOf("watch");
        console.log(pos);
        if (pos !== -1) {
          element.url = element.url.replace("watch?v=", "embed/");
        } else {
          const pos = element.url.indexOf("youtu.be"); // 0
          if (pos !== -1) {
            element.url.replace(
              "youtu.be",
              "www.youtube.com/embed/" + url.vidId
            );
          } else {
            element.url;
          }
        }
        console.log("element:-----", element.url);
        element[
          "trustedVideoUrl"
        ] = this.sanitizer.bypassSecurityTrustResourceUrl(element.url);
        console.log("ooooo", element);
      }
      this.body_list.push(element);
      // this.postlist = data.data.data;
      console.log(this.body_list);
    });
  }

  ngOnInit() {}
  validateYouTubeUrl(element: any) {
    if (element !== undefined || element !== "") {
      console.log("URL-->", element);
      const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|\?v=)([^#\&\?]*).*/;
      const match = element.match(regExp);
      if (match && match[2].length === 11) {
        console.log("MATCH YOUTUBE", match[2]);
        return { type: "youtube", vidId: match[2] };
      } else {
        return { type: "video" };
      }
    }
  }
}
