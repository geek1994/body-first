import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BodyWeightPage } from './body-weight.page';

const routes: Routes = [
  {
    path: '',
    component: BodyWeightPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BodyWeightPageRoutingModule {}
