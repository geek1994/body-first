import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { BodyWeightPage } from './body-weight.page';

describe('BodyWeightPage', () => {
  let component: BodyWeightPage;
  let fixture: ComponentFixture<BodyWeightPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BodyWeightPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(BodyWeightPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
