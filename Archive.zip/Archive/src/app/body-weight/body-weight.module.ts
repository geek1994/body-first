import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BodyWeightPageRoutingModule } from './body-weight-routing.module';

import { BodyWeightPage } from './body-weight.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BodyWeightPageRoutingModule
  ],
  declarations: [BodyWeightPage]
})
export class BodyWeightPageModule {}
