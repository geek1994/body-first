import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MobilityFlexibilityPageRoutingModule } from './mobility-flexibility-routing.module';

import { MobilityFlexibilityPage } from './mobility-flexibility.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MobilityFlexibilityPageRoutingModule
  ],
  declarations: [MobilityFlexibilityPage]
})
export class MobilityFlexibilityPageModule {}
