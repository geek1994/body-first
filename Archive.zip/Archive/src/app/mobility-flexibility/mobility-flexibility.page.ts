import { Component, OnInit } from '@angular/core';
import { NavController } from "@ionic/angular";
@Component({
  selector: 'app-mobility-flexibility',
  templateUrl: './mobility-flexibility.page.html',
  styleUrls: ['./mobility-flexibility.page.scss'],
})
export class MobilityFlexibilityPage implements OnInit {

  constructor(public navCtrl: NavController) { }

  ngOnInit() {
  }

  signup() {
    //this.navCtrl.navigateForward('/exercises');
  }

}
