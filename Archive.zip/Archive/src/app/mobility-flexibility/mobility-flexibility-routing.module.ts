import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MobilityFlexibilityPage } from './mobility-flexibility.page';

const routes: Routes = [
  {
    path: '',
    component: MobilityFlexibilityPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MobilityFlexibilityPageRoutingModule {}
