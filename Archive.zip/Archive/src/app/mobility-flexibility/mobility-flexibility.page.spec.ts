import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MobilityFlexibilityPage } from './mobility-flexibility.page';

describe('MobilityFlexibilityPage', () => {
  let component: MobilityFlexibilityPage;
  let fixture: ComponentFixture<MobilityFlexibilityPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MobilityFlexibilityPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MobilityFlexibilityPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
