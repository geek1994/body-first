import { Component } from "@angular/core";
import { Platform } from "@ionic/angular";
import { SplashScreen } from "@ionic-native/splash-screen/ngx";
import { StatusBar } from "@ionic-native/status-bar/ngx";
import { MenuController, NavController } from "@ionic/angular";
import { Router, RouterEvent, NavigationEnd } from "@angular/router";
import { EventsService } from './service/events.service';

@Component({
  selector: "app-root",
  templateUrl: "app.component.html",
  styleUrls: ["app.component.scss"],
})
export class AppComponent {
  isSpirit = 0;
  isMindset = 0;
  isAssessment = 0;
  isNutrition = 0;
  isExersise = 0;
  userData:any='';
  selectedItem:any= 'week-workout'
  appPages: any = [
    {
      title: "This Weeks Workout",
      url: "/week-workout",
      icon: "assets/images/work.png",
    },
    {
      title: "Profile",
      url: "/profile",
      icon: "assets/images/profile.png",
    },
    {
      title: "Assessment",
      url: "/assessment",
      icon: "assets/images/menu.png",
    },
    {
      title: "Goal Setting",
      url: "/settings",
      icon: "assets/images/goal.png",
    },
    // {
    //   title: 'Spirit',
    //   url: '/spirit',
    //   icon: 'assets/images/spirit.png'
    // },
    // {
    //   title: 'Mindset',
    //   url: '/mindset',
    //   icon: 'assets/images/mindse.png'
    // },
    // {
    //   title: 'Nutrition',
    //   url: '/nutrition',
    //   icon: 'assets/images/nutrition.png'
    // },
    // {
    //   title: 'Exercise',
    //   url: '/exercises',
    //   icon: 'assets/images/exercise.png'
    // },
    {
      title: "Body Weight Training",
      url: "/body-weight",
      icon: "assets/images/exercise.png",
    },
    {
      title: "Liked Exercises",
      url: "/liked-exercises",
      icon: "assets/images/heart.png",
    },
  ];
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    public navCtrl: NavController,
    public menuCtrl: MenuController,
    private router: Router,
    public events:EventsService,

  ) {
    this.initializeApp();
    this.router.events.subscribe((event: RouterEvent) => {
      if (event instanceof NavigationEnd && event.url === "/login") {
        this.menuCtrl.enable(false);
      } else if (event instanceof NavigationEnd && event.url === "/home") {
        console.log(event.url);
        this.menuCtrl.swipeGesture(false);
      } else if (event instanceof NavigationEnd && event.url === "/signup") {
        this.menuCtrl.enable(false);
      } else {
        this.menuCtrl.enable(true);
      }
    });
    console.log(localStorage.getItem('userData'),JSON.parse(localStorage.getItem('userData')))
    if(localStorage.getItem('userData') != undefined && localStorage.getItem('userData') != null){
      this.userData = JSON.parse(localStorage.getItem('userData'));
     this.navCtrl.navigateRoot("/week-workout");
    }
    this.events.subscribe('user:created', (data: any) => {
    this.userData = JSON.parse(localStorage.getItem('userData'));
  });
  this.platform.backButton.subscribe(()=>{
    alert("exitApp")
    navigator['app'].exitApp();
  });
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      if ( this.platform.is('android')) {
        this.statusBar.overlaysWebView(false);
       }   
       
      //  this.statusBar.backgroundColorByHexString('#ffffff');
    this.statusBar.styleLightContent();
    this.splashScreen.hide();
    });
  }

  signOut() {
    localStorage.clear();
    this.menuCtrl.close();
    this.navCtrl.navigateRoot("/login");
  }
  goTo(url, type){
    this.selectedItem = url+'?type='+type;
    this.navCtrl.navigateRoot(['/'+url],{ queryParams: { type: type }})
  }
  gotoPage(url){
    this.selectedItem = url;
    this.navCtrl.navigateRoot('/'+url)
  }
}
