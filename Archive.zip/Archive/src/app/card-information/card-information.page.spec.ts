import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { CardInformationPage } from './card-information.page';

describe('CardInformationPage', () => {
  let component: CardInformationPage;
  let fixture: ComponentFixture<CardInformationPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CardInformationPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(CardInformationPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
