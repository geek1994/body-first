import { Component, OnInit, NgZone } from "@angular/core";
import { NavController } from "@ionic/angular";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { HttpClient, HttpClientModule } from "@angular/common/http";
import { Stripe } from '@ionic-native/stripe/ngx';
import { ComponentService } from '../service/component.service';
import * as moment from 'moment';
declare var google: any;
declare var $: any;

@Component({
  selector: "app-card-information",
  templateUrl: "./card-information.page.html",
  styleUrls: ["./card-information.page.scss"],
})
export class CardInformationPage implements OnInit {
  public infromationForm: FormGroup;
  autocompleteItems = [];
  autocomplete;
  latitude: number = 0;
  longitude: number = 0;
  geo: any;
  city:any='';
  zip:any='';
  service = new google.maps.places.AutocompleteService();
  submitAttempt: boolean = false;
  minDate = new Date().getFullYear();
  date = (new Date().getFullYear()+5) +'-'+(new Date().getMonth()+1)+'-'+new Date().getDate();
  maxDate = '';
  constructor(
    public formBuilder: FormBuilder,
    public navCtrl: NavController,
    public zone: NgZone,
    public httpClient: HttpClient,
    private stripe: Stripe,
    public componentService:ComponentService
  ) {
    this.maxDate = moment(moment(this.date, 'YYYY-MM-DD')).format('YYYY-MM-DD');
    console.log(this.minDate,this.maxDate,new Date().getFullYear()+5);
    this.infromationForm = this.formBuilder.group({
      email: [
        "",
        Validators.compose([
          Validators.required,
          Validators.pattern("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$"),
        ]),
      ],
      name: ["", Validators.compose([Validators.required])],
      phone: ["", Validators.compose([Validators.required])],
      state: ["", Validators.compose([Validators.required])],
      // city: ['', Validators.compose([Validators.required])],
      street: ['', Validators.compose([Validators.required])],
      terms: [false, Validators.compose([Validators.required, Validators.pattern('true')])],
      cardnumber: ["", Validators.compose([Validators.required])],
      expDate: ["", Validators.compose([Validators.required])],
      cvv: ["", Validators.compose([Validators.required])],
      fullname: ["", Validators.compose([Validators.required])],
    });
    this.stripe.setPublishableKey('pk_test_51GxTOkD14WtYkgAkpDdgCHtDtoZWBnSZCEHzxgcQB9HNhJhcVHOCaZ60UWCqyruya5p3pGAHiTFEfvWIkmG1MLMq00JpQzbAPr');
  }

  ngOnInit() {}

  submitCard() { 
    var cardInfo = this.infromationForm.value;
    var date = cardInfo.expDate;
    var i = date.indexOf("-");
    var year = date.slice(0, i).trim();
    var month:any = new Date(cardInfo.expDate).getMonth() + 1;
    var newmonth = moment(cardInfo.expDate).format('MM');
    console.log("month", month, newmonth[0]);
    console.log("year", year);
    var card = {};
    this.stripe
      .validateCardNumber(cardInfo.cardnumber)
      .then(res => {
        card["number"] = cardInfo.cardnumber;
      })
      .catch(error => {
        this.componentService.presentToast('error','1'+error);
      });
    this.stripe
      .validateExpiryDate(month, year)
      .then(res => {
        card["expMonth"] = month;
        card["expYear"] = year;
      })
      .catch(error => {
        this.componentService.presentToast('error','2'+error);

      });
    this.stripe
      .validateCVC(cardInfo.cvv)
      .then(res => {
        card["cvc"] = cardInfo.cvv;
      })
      .catch(error => {
        this.componentService.presentToast('error','3'+error);

      });
    console.log("card", card);
    var card1 = {
      name: cardInfo.fullname,
      number: cardInfo.cardnumber,
      expMonth: newmonth,
      expYear: year,
      cvc: cardInfo.cvv
    };
    console.log("cards", card1);
    this.componentService.presentToast('success','Card added successfully');
    this.navCtrl.navigateForward("/bodyfirst-program");
  }
  validatecvv(cvv) {
    console.log('CVV Value:- ', cvv.value);
    if ($(cvv).val().length >= 4) {
      $(cvv).val($(cvv).val().substr(0, 4));
    }
    // cvv.value = '';
  }

  validateCard(card) {
    if (card.value.length > 0) {
      // this.formatCardNumber(card.value);
      $('input[formControlName="cardnumber"]').validateCreditCard(result => {
        if (result.card_type) {
          $('input[formControlName="cardnumber"]')
            // .parent()
            .addClass(result.card_type.name);
        }
        if (result.valid) {
          $('input[formControlName="cardnumber"]')
            // .parent()
            .addClass("valid");
        } else {
          $('input[formControlName="cardnumber"]')
            // .parent()
            .removeClass("valid");
        }
      });
    } else {
      $('input[formControlName="cardnumber"]')
        // .parent()
        .removeClass("visa");
      $('input[formControlName="cardnumber"]')
        // .parent()
        .removeClass("mastercard");
      $('input[formControlName="cardnumber"]')
        // .parent()
        .removeClass("visa_electron");
      $('input[formControlName="cardnumber"]')
        // .parent()
        .removeClass("maestro");
      $('input[formControlName="cardnumber"]')
        // .parent()
        .removeClass("discover");
      $('input[formControlName="cardnumber"]')
        // .parent()
        .removeClass("valid");
    }
  }
  formatCardNumber(value) {
    var formatVal: any;
    var v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '')
    var matches = v.match(/\d{4,16}/g);
    var match = matches && matches[0] || ''
    var parts = []

    for (var i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4))
    }

    if (parts.length) {
      formatVal = parts.join(' ');
    } else {
      formatVal = value;
    }
    console.log('formatVal:- ', parts, formatVal);
    $('input[formControlName="cardnumber"]').val(formatVal);
  }

  chooseItem(item: any) {
    console.log(item);
    // this.viewCtrl.dismiss(item);
    this.geo = item;
    this.geoCode(this.geo); //convert Address to lat and long
  }
  geoCode(address: any) {
    let geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address: address }, (results, status) => {
      this.latitude = results[0].geometry.location.lat();
      this.longitude = results[0].geometry.location.lng();
      this.autocompleteItems = [];
      this.infromationForm.controls.state.setValue(address);
      var latlng;
      latlng = new google.maps.LatLng(this.latitude, this.longitude);   
      var that = this;     
      new google.maps.Geocoder().geocode({'latLng' : latlng}, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
        console.log(results)    
        if (results[1]) {       
       
          var country = null,
            countryCode = null,
            postal = null,
            city = null,
            cityAlt = null;
          var c, lc, component;
          for (var r = 0, rl = results.length; r < rl; r += 1) {
            var result = results[r];

            if (!city && result.types[0] === "locality") {
              for (
                c = 0, lc = result.address_components.length;
                c < lc;
                c += 1
              ) {
                component = result.address_components[c];

                if (component.types[0] === "locality") {
                  city = component.long_name;
                  break;
                }
              }
            } else if (
              !city &&
              !cityAlt &&
              result.types[0] === "administrative_area_level_1"
            ) {
              for (
                c = 0, lc = result.address_components.length;
                c < lc;
                c += 1
              ) {
                component = result.address_components[c];

                if (component.types[0] === "administrative_area_level_1") {
                  cityAlt = component.long_name;
                  break;
                }
              }
            } else if (!country && result.types[0] === "country") {
              country = result.address_components[0].long_name;
              countryCode = result.address_components[0].short_name;
            }
            else if (!postal && result.types[0] === "postal_code") {
              postal = result.address_components[0].long_name;
            }
            if (city && country) {
              break;
            }
          }
          // that.infromationForm.controls.zip.setValue(postal);
          // that.infromationForm.setValue({city:city});
          console.log("City: " + city + ", City2: " + cityAlt + ", Country: " + country + ", Country Code: " + countryCode, postal);
          console.log(that.infromationForm.value);
          that.city = city;
          that.zip = postal;
        }
      }
    })
      // console.log(this.autocomplete.query)
      // alert("lat: " + this.latitude + ", long: " + this.longitude);
      // this.httpClient.get('https://nominatim.openstreetmap.org/search?format=geojson&q=' + this.latitude + ',' + this.longitude).subscribe(data => {
      //   console.log('newdata', data);
      //   if (data['features'].length > 0) {
      //   } else {
      //   }
      // });
    });
  }
  dismiss() {
    this.autocompleteItems = [];
  }
  updateSearch() {
    if (this.infromationForm.value.state == "") {
      this.autocompleteItems = [];
      return;
    }

    let me = this;
    this.service.getPlacePredictions(
      {
        input: this.infromationForm.value.state,
      },
      (predictions, status) => {
        me.autocompleteItems = [];
        console.log(predictions);
        me.zone.run(() => {
          if (predictions != null) {
            predictions.forEach((prediction) => {
              me.autocompleteItems.push(prediction.description);
            });
            console.log(me.autocompleteItems);
          }
        });
      }
    );
  }
}
