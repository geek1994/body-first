import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import { ReactiveFormsModule } from '@angular/forms';
import { CardInformationPageRoutingModule } from './card-information-routing.module';

import { CardInformationPage } from './card-information.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    CardInformationPageRoutingModule
  ],
  declarations: [CardInformationPage]
})
export class CardInformationPageModule {}
