import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, tap, switchMap } from 'rxjs/operators';
// import 'rxjs/add/operator/map';
// import { Http, HttpModule, RequestOptions, Headers } from '@angular/http';
@Injectable({
  providedIn: 'root'
})
export class ApiService {
public appUrl = environment.baseUrl;
  constructor(private http: HttpClient) { 
    console.log(this.appUrl, "appurl")
  }
  signup(url:string, data:object) {
    return this.http
      .post(
        `${environment.baseUrl}`+url,
        { name: data['name'], email: data['email'], password:data['password']}
      )
      .pipe(tap(resData=>{
        return resData; 
       
       }));
  }
  
  public post(url, params) {
    const headers = new HttpHeaders();
    headers.append('Accept', 'application/json');
    headers.append('Content-Type', 'application/json');
    const options = { headers: headers };
    console.log(JSON.stringify(params), 'data')
    return this.http
      .post(this.appUrl + url, JSON.stringify(params), options)
      .pipe(tap(resData=>{
        return resData;       
       }));
  }
  public get(url) {
    const headers = new HttpHeaders();
    headers.append('Accept', 'application/json');
    headers.append('Content-Type', 'application/json');
    const options = {
      headers: headers
    };
    return this.http.get(this.appUrl + url, options).pipe(res =>{return res;})
  }
  // public get(url) {
  //   console.log(url ,"url")
  // return this.http.get(`${environment.baseUrl}`+url).pipe(tap(resData=>{return resData;}));
  // }
}
