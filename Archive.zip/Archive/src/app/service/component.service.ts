import { Injectable } from '@angular/core';
import { ToastController,LoadingController } from '@ionic/angular';
@Injectable({
  providedIn: 'root'
})
export class ComponentService {
  constructor(public toastCtrl:ToastController, public loadingController:LoadingController) { }
  async presentToast(type,data) {
    const toast = await this.toastCtrl.create({
      message: data,
      color:type == 'error' ? 'danger' : type,
      duration: 2000
    });
    toast.present();
  }
  async presentLoading(){
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',
      // duration: 2000
    });
    await loading.present();

    const { role, data } = await loading.onDidDismiss();
    console.log('Loading dismissed!');
  }
  async dismissLoading(){
    this.loadingController.dismiss();
  }
}
