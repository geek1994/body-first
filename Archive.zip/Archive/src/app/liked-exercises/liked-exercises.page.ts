import { Component, OnInit } from '@angular/core';
import { ComponentService } from '../service/component.service';
@Component({
  selector: 'app-liked-exercises',
  templateUrl: './liked-exercises.page.html',
  styleUrls: ['./liked-exercises.page.scss'],
})
export class LikedExercisesPage implements OnInit {
public likedExercises= [
{'id':1, 'name': 'Shoulder', 'image':'assets/images/liked.png'},
{'id':2, 'name': 'Hand', 'image':'assets/images/ExerciseScreen.jpg'},
{'id':3, 'name': 'Abs', 'image':'assets/images/abs.png'},]
  constructor(public componentService:ComponentService) { }

  ngOnInit() {
  }
unlike(index){
  this.componentService.presentToast('success',"Unliked successfully");
  this.likedExercises.splice(index, 1); 
  
}
}
