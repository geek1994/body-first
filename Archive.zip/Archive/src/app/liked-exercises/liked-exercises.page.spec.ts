import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { LikedExercisesPage } from './liked-exercises.page';

describe('LikedExercisesPage', () => {
  let component: LikedExercisesPage;
  let fixture: ComponentFixture<LikedExercisesPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LikedExercisesPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LikedExercisesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
