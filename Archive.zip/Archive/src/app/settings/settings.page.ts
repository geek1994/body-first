import { Component, OnInit,Inject } from "@angular/core";
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { ComponentService } from '../service/component.service';
import { AlertController,Platform } from "@ionic/angular";
import { AppVersion } from '@ionic-native/app-version/ngx';
@Component({
  selector: "app-settings",
  templateUrl: "./settings.page.html",
  styleUrls: ["./settings.page.scss"],
})
export class SettingsPage implements OnInit {
  link:any='';
  app_version:any ='';
  constructor(
    public alertController: AlertController,
    @Inject(SocialSharing) private socialSharing,
    public componentService:ComponentService,
    public platform:Platform,
    private appVersion: AppVersion
    ) {
      this.appVersion.getVersionNumber().then(function (version) {
       this.app_version = version;
    });
    }
  async presentAlertConfirm() {
    const alert = await this.alertController.create({
      cssClass: "my-custom-class subscription-label",
      header: "SUBSCRIPTION",
      message: "",
      buttons: [
        {
          text: "ALLOW",
          role: "cancel",
          cssClass: "secondary",
          handler: (blah) => {
            console.log("Confirm Cancel: blah");
          },
        },
        {
          text: "DELETE ACCOUNT",
          handler: () => {
            console.log("Confirm Okay");
          },
        },
      ],
    });

    await alert.present();
  }
  ngOnInit() {
    this.platform.ready().then(() => {
      if ( this.platform.is('android')) {
        this.link ='https://play.google.com/store';
       }   
       if ( this.platform.is('ios')) {
        this.link ='https://www.apple.com/itunes/';
      }
    });
  }
  share(){
    this.componentService.presentLoading();
     console.log(this.link, "link")
    this.socialSharing.share("BodyFirst App",this.link).then(() => {
      this.componentService.dismissLoading()
      // this.socialSharing.share('Post',null, URL, link).then(() => {
        console.log("share");
     }).catch(() => {
        console.log("not share");
       this.componentService.dismissLoading()
       alert("not share");
        });
  }
}
