import { Component, OnInit } from "@angular/core";
import { NavController,ActionSheetController } from "@ionic/angular";
import { Router, ActivatedRoute  } from "@angular/router";
import { EventsService } from '../service/events.service';

@Component({
  selector: "app-profile",
  templateUrl: "./profile.page.html",
  styleUrls: ["./profile.page.scss"],
})
export class ProfilePage implements OnInit {
  back = false;
  userData:any='';

  constructor(public actionSheetController: ActionSheetController,public navCtrl: NavController, public router: Router, private route: ActivatedRoute , public events:EventsService) {
    console.log(JSON.parse(localStorage.getItem('userData')));
    this.userData = JSON.parse(localStorage.getItem('userData'));
    this.route.queryParams.subscribe(params => {
      this.back = params["back"];
    });
    console.log('back:: ', this.back);
    this.events.subscribe('user:created', (data: any) => {
      this.userData = JSON.parse(localStorage.getItem('userData'));
    });
  }

  setting() {
    this.navCtrl.navigateForward("/settings");
  }

  goBack() {
    this.navCtrl.navigateRoot("/week-workout");
  }

  editProfile() {
    this.navCtrl.navigateForward("/edit-profile");
  }

  ngOnInit() {}


}
