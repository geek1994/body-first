import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ComponentService } from '../service/component.service';
import { EventsService } from '../service/events.service';
import { NavController, MenuController,ActionSheetController} from "@ionic/angular";
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { isNumber } from 'util';
@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.page.html',
  styleUrls: ['./edit-profile.page.scss'],
})
export class EditProfilePage implements OnInit {
  public profileForm: FormGroup;
  profile_picture:any='';
  userData:any;
  imageUpload: any = '';
  ageError:any={};
   constructor(public actionSheetController: ActionSheetController,public formBuilder: FormBuilder,public events:EventsService, public componentService:ComponentService,public navCtrl:NavController,
    @Inject(Camera) private camera) {
    this.userData = JSON.parse(localStorage.getItem('userData'));
    console.log(this.userData, "userdata");
     this.profile_picture = this.userData.picture;
    this.profileForm = this.formBuilder.group({
      email: [''],
      name: ['', Validators.compose([Validators.required])],
      gender: ['', Validators.compose([Validators.required])],
      measuement: [''],
      age: ['', Validators.compose([Validators.required])],
      height: ['', Validators.compose([Validators.required])],
      weight: ['GBP', Validators.compose([Validators.required])],
      // appointment_duration: ['', Validators.compose([Validators.required])]
    });
    this.events.subscribe('user:created', (data: any) => {
      this.userData = JSON.parse(localStorage.getItem('userData'));
    });
   }

  ngOnInit() {
    this.profileForm.patchValue({
      name: this.userData.name,
      email: this.userData.email,
      gender: this.userData.gender,
      weight: this.userData.weight,
      height: this.userData.height,
      age: this.userData.age
    });
  }
  update(){
    if(!this.profileForm.valid){
    return false;
    }else{
     this.profileForm.patchValue({name:this.profileForm.value.name.trim()})
    //  localStorage.setItem('userData', JSON.stringify(this.profileForm.value))
    localStorage.setItem('userData', JSON.stringify({
    'name':this.profileForm.value.name,
    'weight':this.profileForm.value.weight,
    'height':this.profileForm.value.height,
    'age':this.profileForm.value.age,
    'measuement':this.profileForm.value.measuement,
    'gender':this.profileForm.value.gender,
    'email':this.userData.email,
    'picture':this.userData.picture,
    'id':this.userData.id,
    'goal': this.userData.goal    
    }));

     this.events.publish('user:created', {user: JSON.stringify(this.profileForm.value)});
     this.componentService.presentToast('success','User updated successfully!' )
     this.navCtrl.navigateBack("/profile");
    }
  };
  async selectImage() {
    const actionSheet = await this.actionSheetController.create({
      header: "Select Image source",
      buttons: [{
        text: 'Load from Library',
        handler: () => {
          this.openCamera(this.camera.PictureSourceType.PHOTOLIBRARY);
        }
      },
      {
        text: 'Use Camera',
        handler: () => {
          this.openCamera(this.camera.PictureSourceType.CAMERA);
        }
      },
      {
        text: 'Cancel',
        role: 'cancel'
      }
      ]
    });
    await actionSheet.present();
  }
  openCamera(sourceType) {
    // this.picture = '';
    const options: CameraOptions = {
      quality: 40,
      sourceType: sourceType,
      destinationType: this.camera.DestinationType.DATA_URL,
      // targetWidth: 300,
      // targetHeight: 300,
      mediaType: this.camera.MediaType.PICTURE,
      correctOrientation: true
    }

    this.camera.getPicture(options).then((imageData) => {
      this.profile_picture = 'data:image/jpeg;base64,' + imageData;
        console.log(this.userData, this.imageUpload);
        localStorage.setItem('userData', JSON.stringify({
        'name':this.profileForm.value.name,
        'weight':this.profileForm.value.weight,
        'height':this.profileForm.value.height,
        'age':this.profileForm.value.age,
        'measuement':this.profileForm.value.measuement,
        'gender':this.profileForm.value.gender,
        'email':this.userData.email,
        'picture':this.profile_picture,
        'id':this.userData.id
        }));
        this.componentService.presentToast('success', 'Profile picture updated successfully');
        this.events.publish('user:created', {user: JSON.stringify(this.profileForm.value)});
    }, (err) => {
      // Handle error
      alert(JSON.stringify(err))
    });

  }
  validateAge(){
    this.ageError['value'] = true;
    console.log(this.profileForm.value.age);
    console.log(isNumber(this.profileForm.value.age))
    if(isNumber(this.profileForm.value.age) == false){
      this.ageError['message'] = "Invalid Age.";
      this.ageError['value'] = false;
    }else if(this.profileForm.value.age<18){
      this.ageError['message'] = "too young";
      this.ageError['value'] = false;
    }else if(this.profileForm.value.age>120){
      this.ageError['message'] = "not realistic";
      this.ageError['value'] = false;
    }else{
      this.ageError['value'] = true;
    }
  }
}
