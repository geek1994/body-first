import { Component, OnInit } from "@angular/core";
import { NavController, MenuController } from "@ionic/angular";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ThrowStmt } from "@angular/compiler";
import { ApiService } from "../service/api.service";
import { ComponentService } from "../service/component.service";
import { EventsService } from '../service/events.service';
@Component({
  selector: "app-signup",
  templateUrl: "./signup.page.html",
  styleUrls: ["./signup.page.scss"],
})
export class SignupPage implements OnInit {
  public signupForm: FormGroup;
  passwordCheck: boolean = false;
  constructor(
    public navCtrl: NavController,
    public menuController: MenuController,
    public formBuilder: FormBuilder,
    public api: ApiService,
    public componentService: ComponentService,

  ) {
    this.menuController.swipeGesture(false);
    this.signupForm = this.formBuilder.group({
      name: ["", Validators.compose([Validators.required])],
      email: [
        "",
        Validators.compose([
          Validators.required,
          Validators.pattern("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$"),
        ]),
      ],
      password: ["", Validators.compose([Validators.required])],
      confirmpassword: ["", Validators.compose([Validators.required])],
      // gender:  ['', Validators.compose([Validators.required])],
    });
  }

  ngOnInit() {}
  vrifyConfirmpassword() {
    if (this.signupForm.value.confirmpassword != "") {
      console.log(
        this.signupForm.value.password,
        this.signupForm.value.confirmpassword
      );
      if (
        this.signupForm.value.password == this.signupForm.value.confirmpassword
      ) {
        this.passwordCheck = false;
      } else {
        this.passwordCheck = true;
      }
    }
  }
  signIn() {
    this.navCtrl.back();
  }
  getStarted() {
    localStorage.setItem('userData', JSON.stringify(this.signupForm.value));
       this.navCtrl.navigateForward("/subscriptions");
    return false;
    // this.navCtrl.navigateRoot('/week-workout');
    // this.navCtrl.navigateForward("/subscriptions");
    this.componentService.presentLoading();
    var data = {
      name: this.signupForm.value.name,
      email: this.signupForm.value.email,
      password: this.signupForm.value.password,
    };
    console.log(data, "data");
    this.api.signup("/register", data).subscribe(
      (res: any) => {
        console.log("res:- ", res);
        this.componentService.dismissLoading();
        if (res["success"]) {
          // Plugins.Storage.set({ key: 'userData', value: JSON.stringify(res['data']) });
          this.componentService.presentToast("success", res["message"]);
          this.signupForm.reset();
          // this.navCtrl.navigateForward("/survey");
          this.navCtrl.navigateForward("/subscriptions");
        } else {
          this.componentService.presentToast("error", res["message"]);
        }
      },
      (err) => {
        this.componentService.dismissLoading();

        console.log("login error:- ", err);
      }
    );
  }
  goTo(url){
    this.navCtrl.back();
  }
}
