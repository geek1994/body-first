import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SearchExercisesPageRoutingModule } from './search-exercises-routing.module';

import { SearchExercisesPage } from './search-exercises.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SearchExercisesPageRoutingModule
  ],
  declarations: [SearchExercisesPage]
})
export class SearchExercisesPageModule {}
