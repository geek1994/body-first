import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SearchExercisesPage } from './search-exercises.page';

describe('SearchExercisesPage', () => {
  let component: SearchExercisesPage;
  let fixture: ComponentFixture<SearchExercisesPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchExercisesPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SearchExercisesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
