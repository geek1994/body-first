import { Component, OnInit } from "@angular/core";
import { NavController ,ModalController} from "@ionic/angular";

@Component({
  selector: "app-search-exercises",
  templateUrl: "./search-exercises.page.html",
  styleUrls: ["./search-exercises.page.scss"],
})
export class SearchExercisesPage implements OnInit {
  constructor(public navCtrl :NavController, public modalController:ModalController) {}

  ngOnInit() {}
  home(){

  }
  back(){
    this.modalController.dismiss();
  //  this.navCtrl.navigateBack(['/exercises'],{ queryParams: { type: 'guid' }});
  }
}
