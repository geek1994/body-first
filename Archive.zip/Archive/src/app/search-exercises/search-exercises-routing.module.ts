import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SearchExercisesPage } from './search-exercises.page';

const routes: Routes = [
  {
    path: '',
    component: SearchExercisesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SearchExercisesPageRoutingModule {}
