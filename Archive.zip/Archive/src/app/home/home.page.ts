import { Component } from "@angular/core";
import { NavController, MenuController } from "@ionic/angular";

@Component({
  selector: "app-home",
  templateUrl: "home.page.html",
  styleUrls: ["home.page.scss"],
})
export class HomePage {
  constructor(
    public navCtrl: NavController,
    public menuController: MenuController
  ) {
    this.menuController.swipeGesture(false);
  }
  startHere() {
    this.navCtrl.navigateForward("/login");
  }
}
