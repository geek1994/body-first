import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { WeekWorkoutPageRoutingModule } from './week-workout-routing.module';

import { WeekWorkoutPage } from './week-workout.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    WeekWorkoutPageRoutingModule
  ],
  declarations: [WeekWorkoutPage]
})
export class WeekWorkoutPageModule {}
