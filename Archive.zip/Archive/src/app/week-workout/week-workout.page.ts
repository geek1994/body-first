import { Component, OnInit } from "@angular/core";
import { NavController } from "@ionic/angular";
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { NgStyle } from '@angular/common';

@Component({
  selector: "app-week-workout",
  templateUrl: "./week-workout.page.html",
  styleUrls: ["./week-workout.page.scss"],
})
export class WeekWorkoutPage implements OnInit {
  trustedVideoUrl: SafeResourceUrl;  
  public weekData=[
  {'id': 1, 'url': 'https://www.youtube.com/watch?v=z3MiUVxXx8Q'},
  {'id': 2, 'url': 'https://www.youtube.com/watch?v=HagVnWAeGcM'},
  {'id': 3, 'url': 'https://www.youtube.com/watch?v=z3MiUVxXx8Q'},
  {'id': 4, 'url': 'https://www.youtube.com/watch?v=HagVnWAeGcM'},
  {'id': 5, 'url': 'https://www.youtube.com/watch?v=z3MiUVxXx8Q'},
  {'id': 6, 'url': 'https://www.youtube.com/watch?v=HagVnWAeGcM'},]
  week_list:any=[];
  constructor(public navCtrl: NavController,public sanitizer: DomSanitizer) {
    console.log(this.weekData, "weeekdata")
    var that = this;
    this.weekData.forEach(element => {
      if (element.url != null) {
        const url = that.validateYouTubeUrl(element.url);
        console.log('url:- ', url);
        const pos = element.url.indexOf('watch');
        console.log(pos)
        if (pos !== -1) {
          element.url = element.url.replace('watch?v=', 'embed/');
        } else {
          const pos = element.url.indexOf('youtu.be'); // 0
          if (pos !== -1) {
            element.url.replace('youtu.be', 'www.youtube.com/embed/' + url.vidId);
          } else {
            element.url;
          }
        }
        console.log('element:-----', element.url)
        element['trustedVideoUrl'] = this.sanitizer.bypassSecurityTrustResourceUrl(element.url);
        console.log('ooooo', element);
      }
      this.week_list.push(element);
      // this.postlist = data.data.data;
      console.log(this.week_list);

    });
  }
  validateYouTubeUrl(element: any) {
    if (element !== undefined || element !== '') {
      console.log('URL-->', element);
      const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|\?v=)([^#\&\?]*).*/;
      const match = element.match(regExp);
      if (match && match[2].length === 11) {
        console.log('MATCH YOUTUBE', match[2]);
        return { type: 'youtube', vidId: match[2] };
      } else {
        return { type: 'video' };
      }
    }
  }
  ngOnInit() {}
  settings() {
    this.navCtrl.navigateForward("/settings");
  }
}
