import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { BodyfirstProgramPage } from './bodyfirst-program.page';

describe('BodyfirstProgramPage', () => {
  let component: BodyfirstProgramPage;
  let fixture: ComponentFixture<BodyfirstProgramPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BodyfirstProgramPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(BodyfirstProgramPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
