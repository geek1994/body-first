import { Component, OnInit } from '@angular/core';
import { NavController } from "@ionic/angular";

@Component({
  selector: 'app-bodyfirst-program',
  templateUrl: './bodyfirst-program.page.html',
  styleUrls: ['./bodyfirst-program.page.scss'],
})
export class BodyfirstProgramPage implements OnInit {

  constructor(public navCtrl: NavController) {}
  ngOnInit() {
  }

  getStarted() {
    this.navCtrl.navigateForward('/survey');
  }

}
