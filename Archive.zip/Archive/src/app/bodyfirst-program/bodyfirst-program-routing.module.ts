import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BodyfirstProgramPage } from './bodyfirst-program.page';

const routes: Routes = [
  {
    path: '',
    component: BodyfirstProgramPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BodyfirstProgramPageRoutingModule {}
