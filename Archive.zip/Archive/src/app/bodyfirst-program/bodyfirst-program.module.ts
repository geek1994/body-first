import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BodyfirstProgramPageRoutingModule } from './bodyfirst-program-routing.module';

import { BodyfirstProgramPage } from './bodyfirst-program.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BodyfirstProgramPageRoutingModule
  ],
  declarations: [BodyfirstProgramPage]
})
export class BodyfirstProgramPageModule {}
