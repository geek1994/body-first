import { Component, OnInit } from "@angular/core";
import { NavController, MenuController } from "@ionic/angular";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../service/api.service';
import { ComponentService } from '../service/component.service';
import { EventsService } from '../service/events.service';
import { Plugins } from '@capacitor/core';
import { Facebook, FacebookLoginResponse } from '@ionic-native/facebook/ngx';
import { GooglePlus } from '@ionic-native/google-plus/ngx';
@Component({
  selector: "app-login",
  templateUrl: "./login.page.html",
  styleUrls: ["./login.page.scss"],
})
export class LoginPage implements OnInit {
  public loginForm: FormGroup;
  constructor(
    public googlePlus:GooglePlus,
    public navCtrl: NavController,
    public menuController: MenuController,
    public formBuilder: FormBuilder,
    public api:ApiService,
    public componentService:ComponentService,
    private fb: Facebook,
    public events:EventsService,
  ) {
    this.menuController.swipeGesture(false);
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.compose([Validators.required, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')])],
      password: ['', Validators.compose([Validators.required])],
      });
 
  }

  signup() {
      this.navCtrl.navigateForward("/signup");
      // this.navCtrl.navigateForward("/card-information");
  }
  ngOnInit() {}

  login() {
    this.componentService.presentLoading();
    var data = {
      "email": this.loginForm.value.email,
      "password": this.loginForm.value.password      
    }
     console.log(data, "data")
     this.api.signup('/login',data).subscribe((res: any) => {
      console.log('res:- ', res); 
      this.componentService.dismissLoading();
      if(res['success']){
        Plugins.Storage.set({ key: 'userData', value: JSON.stringify(res['data']) });
        this.componentService.presentToast('success',res['message']);
        this.loginForm.reset();
        this.navCtrl.navigateRoot("/week-workout");
      }else{
      this.componentService.dismissLoading();

          this.componentService.presentToast('error',res['message']);
      }
    }, err => {
      
      console.log('login error:- ', err);
    });
    // this.navCtrl.navigateRoot("/week-workout");
  }

  
  async doFbLogin(){
    this.componentService.presentLoading();
		// const loading = await this.loadingController.create({
		// 	message: 'Please wait...'
		// });
		// this.presentLoading(loading);
		let permissions = new Array<string>();
		//the permissions your facebook app needs from the user
     permissions = ["public_profile", "email"];
		this.fb.login(permissions)
		.then((response: FacebookLoginResponse) =>{
			let userId = response.authResponse.userID;
			//Getting name and gender properties
			this.fb.api("/me?fields=name,email", permissions)
			.then(user =>{
				user.picture = "https://graph.facebook.com/" + userId + "/picture?type=large";
        console.log('user', user);
        this.componentService.dismissLoading();
        localStorage.setItem('userData', JSON.stringify(user));
        this.componentService.presentToast('success','User LoggedIn Successfully');
        this.events.publish('user:created', {
          user: JSON.stringify(user)});
        this.navCtrl.navigateRoot("/week-workout");
        // this.fblogin(user);       
			})
		}, error =>{
      console.log('error', error.errorMessage);
      this.componentService.presentToast('error',error.errorMessage);
      // loading.dismiss();
      this.componentService.dismissLoading();
		});
  }
  async doGoogleLogin(){
    this.componentService.presentLoading();
    this.googlePlus.login({
      'scopes': '', // optional, space-separated list of scopes, If not included or empty, defaults to `profile` and `email`.
      'webClientId': '1068443184827-rrut19d770nnqbgcjidrjstc331g5q6k.apps.googleusercontent.com', // optional clientId of your Web application from Credentials settings of your project - On Android, this MUST be included to get an idToken. On iOS, it is not required.
      'offline': true // Optional, but requires the webClientId - if set to true the plugin will also return a serverAuthCode, which can be used to grant offline access to a non-Google server
    })
    .then(user =>{
      this.componentService.dismissLoading();
       localStorage.setItem('userData',JSON.stringify({name: user.displayName,
        email: user.email,
        picture: user.imageUrl
      }) )
      this.componentService.presentToast('success','User LoggedIn Successfully');
      this.events.publish('user:created', {
        user: JSON.stringify(user)});
      this.navCtrl.navigateRoot("/week-workout");
     }, err =>{
      console.log(err, "eerr");
      alert(err)
      this.componentService.dismissLoading();
    });  
   }
}
