import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MindsetPage } from './mindset.page';

describe('MindsetPage', () => {
  let component: MindsetPage;
  let fixture: ComponentFixture<MindsetPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MindsetPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MindsetPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
