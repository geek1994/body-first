import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MindsetPageRoutingModule } from './mindset-routing.module';

import { MindsetPage } from './mindset.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MindsetPageRoutingModule
  ],
  declarations: [MindsetPage]
})
export class MindsetPageModule {}
