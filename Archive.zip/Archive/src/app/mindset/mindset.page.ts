import { Component, OnInit } from '@angular/core';
import { NavController,ModalController } from "@ionic/angular";
import { Router, ActivatedRoute  } from "@angular/router";
import { SearchExercisesPage } from '..//search-exercises/search-exercises.page';
import { DetailspiritPage } from '../detailspirit/detailspirit.page';

@Component({
  selector: 'app-mindset',
  templateUrl: './mindset.page.html',
  styleUrls: ['./mindset.page.scss'],
})
export class MindsetPage implements OnInit {
  mindsetData:any=[];
  type: any = 'guid';
  searchTerm:any='';
  mindsetArray:any=[]
  toggled:boolean=false;
  constructor( public modalController: ModalController,public navCtrl: NavController, public router: Router, private route: ActivatedRoute) { 
    this.route.queryParams.subscribe(params => {
      this.type = params["type"];
      if(this.type == 'sharping'){
          this.mindsetData=[
           {'id': 1, 'title': 'Jump', 'image': 'assets/images/mindset.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
           {'id': 2, 'title': 'Triceps', 'image': 'assets/images/mindset.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
           // {'id': 3, 'title': 'Chest', 'image': 'assets/images/s1.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
          ]   
          console.log(this.mindsetData);       
       this.mindsetArray = this.mindsetData
      }
    });
  }

  async search() {
    const modal = await this.modalController.create({
      component: SearchExercisesPage
    });
    return await modal.present();
  }
  ngOnInit() {
  }
  async detail(data,type) {
    const modal = await this.modalController.create({
      component: DetailspiritPage,
      componentProps: { data: data, type:type }
    });
    return await modal.present();
  }
  showDefaultBar() {
    if(this.toggled){
      this.toggled =false
    }else{
    this.toggled = true;
    }
  }
  clearData(){
    this.searchTerm= '';
    this.mindsetData=[
      {'id': 1, 'title': 'Jump', 'image': 'assets/images/mindset.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
      {'id': 2, 'title': 'Triceps', 'image': 'assets/images/mindset.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
      ]   
      this.mindsetArray = this.mindsetData
  }
  onSearchChange(){
  this.mindsetArray =[]; 
    console.log(this.searchTerm);
     this.mindsetData.filter((element,key) => {
        if (element.title && this.searchTerm!= '') {
          console.log(element.title.toLowerCase().indexOf(this.searchTerm.toLowerCase()));
      
          // return (element.title.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);
          if(element.title.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1){
           this.mindsetArray.push(element);
          }
        }           
    });
    console.log(this.mindsetArray)
    if(this.searchTerm == ''){
      this.mindsetData=[
        {'id': 1, 'title': 'Jump', 'image': 'assets/images/mindset.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
        {'id': 2, 'title': 'Triceps', 'image': 'assets/images/mindset.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
        ]   
        this.mindsetArray = this.mindsetData
    }
  }
}
