import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MindsetPage } from './mindset.page';

const routes: Routes = [
  {
    path: '',
    component: MindsetPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MindsetPageRoutingModule {}
