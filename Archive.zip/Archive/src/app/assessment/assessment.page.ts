import { Component, OnInit,Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ComponentService } from '../service/component.service';
import { NavController, MenuController,ActionSheetController} from "@ionic/angular";
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { EventsService } from '../service/events.service';
@Component({
  selector: 'app-assessment',
  templateUrl: './assessment.page.html',
  styleUrls: ['./assessment.page.scss'],
})
export class AssessmentPage implements OnInit {
  public assessmentForm: FormGroup;
  pageValue:any;
  assessmentData:any='';
  image:any='';
  constructor(public events:EventsService,public actionSheetController: ActionSheetController,@Inject(Camera) private camera,public route:ActivatedRoute,public formBuilder: FormBuilder,public componentService:ComponentService) { 
    this.assessmentForm = this.formBuilder.group({
      total_weight: ['', Validators.compose([Validators.required])],
      lean_weight: ['', Validators.compose([Validators.required])],
      fat: ['', Validators.compose([Validators.required])],
      fat_percantage: ['', Validators.compose([Validators.required])],
      hydration_percentage: ['', Validators.compose([Validators.required])],
    });
    this.route.queryParams.subscribe(params => {
      if (params && params.type) {
        this.pageValue = params.type;
        console.log(this.pageValue)
        if(this.pageValue == 'assessment'){
          console.log(localStorage.getItem('assessments'));
          if(localStorage.getItem('assessments') != undefined && localStorage.getItem('assessments') != null ){
             this.assessmentData = JSON.parse(localStorage.getItem('assessments'));
             this.assessmentData.iamge =  JSON.parse(localStorage.getItem('assessments')).image;
          }else{
            this.assessmentData ={
              'total_weight':52,
              'lean_weight': 40,
              'fat':50,
              'fat_percantage':50,
              'hydration_percentage':20,
              'image':null
            }
          }
            // localStorage.setItem('assessments', JSON.stringify(this.assessmentData));
          console.log( this.assessmentData );
        }
       }
      })
    // assessment
    this.events.subscribe('assessments:created', (data: any) => {
      console.log(JSON.parse(localStorage.getItem('assessments')));
      this.assessmentData = JSON.parse(localStorage.getItem('assessments'));
      this.assessmentData.iamge =  JSON.parse(localStorage.getItem('assessments')).image;
    });
  }

  ngOnInit() {
    if(this.pageValue == 'assessment'){
      this.assessmentForm.patchValue({
        total_weight: this.assessmentData.total_weight,
        lean_weight: this.assessmentData.lean_weight,
        fat: this.assessmentData.fat,
        fat_percantage: this.assessmentData.fat_percantage,
        hydration_percentage: this.assessmentData.hydration_percentage,
      });
    }
  }
  async selectImage() {
    const actionSheet = await this.actionSheetController.create({
      header: "Select Image source",
      buttons: [{
        text: 'Load from Library',
        handler: () => {
          this.openCamera(this.camera.PictureSourceType.PHOTOLIBRARY);
        }
      },
      {
        text: 'Use Camera',
        handler: () => {
          this.openCamera(this.camera.PictureSourceType.CAMERA);
        }
      },
      {
        text: 'Cancel',
        role: 'cancel'
      }
      ]
    });
    await actionSheet.present();
  }
  openCamera(sourceType) {
    // this.picture = '';
    const options: CameraOptions = {
      quality: 40,
      sourceType: sourceType,
      destinationType: this.camera.DestinationType.DATA_URL,
      // targetWidth: 300,
      // targetHeight: 300,
      mediaType: this.camera.MediaType.PICTURE,
      correctOrientation: true
    }

    this.camera.getPicture(options).then((imageData) => {
      this.image = 'data:image/jpeg;base64,' + imageData;
      this.assessmentData ={
        'total_weight':this.assessmentForm.value.total_weight,
        'lean_weight': this.assessmentForm.value.lean_weight,
        'fat':this.assessmentForm.value.fat,
        'fat_percantage':this.assessmentForm.value.fat_percantage,
        'hydration_percentage':this.assessmentForm.value.hydration_percentage,
        'image':this.image
      }
      localStorage.setItem('assessments', JSON.stringify(this.assessmentData));
      this.events.publish('assessments:created', {user: JSON.stringify(this.assessmentData)});
    }, (err) => {
      // Handle error
      alert(JSON.stringify(err))
    });

  }
  update(){
    if(!this.assessmentForm.valid){
    return false;
    }else{     
      this.assessmentData ={
        'total_weight':this.assessmentForm.value.total_weight,
        'lean_weight': this.assessmentForm.value.lean_weight,
        'fat':this.assessmentForm.value.fat,
        'fat_percantage':this.assessmentForm.value.fat_percantage,
        'hydration_percentage':this.assessmentForm.value.hydration_percentage,
        'image':this.image
      }
      localStorage.setItem('assessments', JSON.stringify(this.assessmentData));
      console.log(JSON.parse(localStorage.getItem('assessments')));
     this.events.publish('assessments:created', {user: JSON.stringify(this.assessmentData)});
     this.componentService.presentToast('success','Assessment updated successfully!' )
    //  this.navCtrl.navigateBack("/profile");
    }
  };
}
