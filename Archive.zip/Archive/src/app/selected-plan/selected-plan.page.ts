import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selected-plan',
  templateUrl: './selected-plan.page.html',
  styleUrls: ['./selected-plan.page.scss'],
})
export class SelectedPlanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
