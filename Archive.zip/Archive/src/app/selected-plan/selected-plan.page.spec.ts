import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SelectedPlanPage } from './selected-plan.page';

describe('SelectedPlanPage', () => {
  let component: SelectedPlanPage;
  let fixture: ComponentFixture<SelectedPlanPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectedPlanPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SelectedPlanPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
