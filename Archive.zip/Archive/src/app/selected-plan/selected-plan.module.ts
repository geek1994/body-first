import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SelectedPlanPageRoutingModule } from './selected-plan-routing.module';

import { SelectedPlanPage } from './selected-plan.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SelectedPlanPageRoutingModule
  ],
  declarations: [SelectedPlanPage]
})
export class SelectedPlanPageModule {}
