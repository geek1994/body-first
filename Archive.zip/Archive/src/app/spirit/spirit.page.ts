import { Component, OnInit } from '@angular/core';
import { NavController ,ModalController} from "@ionic/angular";
import { Router, ActivatedRoute  } from "@angular/router";
import { SearchExercisesPage } from '../search-exercises/search-exercises.page';
import { DetailspiritPage } from '../detailspirit/detailspirit.page';
@Component({
  selector: 'app-spirit',
  templateUrl: './spirit.page.html',
  styleUrls: ['./spirit.page.scss'],
})
export class SpiritPage implements OnInit {
  type: any = 'guid';
  spiritData:any=[];
  constructor( public modalController: ModalController,public navCtrl: NavController, public router: Router, private route: ActivatedRoute) { 
    this.route.queryParams.subscribe(params => {
      if (params && params.type) {
        this.type = params.type;
        console.log(this.type)
        if(this.type == 'connect'){
         this.spiritData=[
          {'id': 1, 'title': 'Chest', 'image': 'assets/images/s1.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
          {'id': 2, 'title': 'Biceps', 'image': 'assets/images/s2.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
          // {'id': 3, 'title': 'Chest', 'image': 'assets/images/s1.png' ,'description':' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '},
         ]   
         console.log(this.spiritData);       
        }
       }
      })
  }
  async search() {
    const modal = await this.modalController.create({
      component: SearchExercisesPage
    });
    return await modal.present();
  }
  async detail(data,type) {
    const modal = await this.modalController.create({
      component: DetailspiritPage,
      componentProps: { data: data ,type:type}
    });
    return await modal.present();
  }
  
  ngOnInit() {
  }

}
