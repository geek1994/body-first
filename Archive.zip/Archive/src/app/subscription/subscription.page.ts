import { Component, OnInit } from "@angular/core";
import { ApiService } from "../service/api.service";

@Component({
  selector: "app-subscription",
  templateUrl: "./subscription.page.html",
  styleUrls: ["./subscription.page.scss"],
})
export class SubscriptionPage implements OnInit {
  constructor(public api: ApiService) {
    this.getSuuscription();
  }

  ngOnInit() {
    this.getSuuscription();
  }
  getSuuscription() {
    console.log("gettt")
    this.api.get("/getPlans").subscribe((res: any) => {
      console.log(res, "data");
     });
  }
}
