import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FunctionalPage } from './functional.page';

describe('FunctionalPage', () => {
  let component: FunctionalPage;
  let fixture: ComponentFixture<FunctionalPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FunctionalPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FunctionalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
