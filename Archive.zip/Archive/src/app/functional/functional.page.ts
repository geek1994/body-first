import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-functional',
  templateUrl: './functional.page.html',
  styleUrls: ['./functional.page.scss'],
})
export class FunctionalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
