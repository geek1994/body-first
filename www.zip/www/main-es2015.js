(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet-ios.entry.js",
		"common",
		0
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet-md.entry.js",
		"common",
		1
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-alert-ios.entry.js",
		"common",
		2
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-alert-md.entry.js",
		"common",
		3
	],
	"./ion-app_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-app_8-ios.entry.js",
		"common",
		4
	],
	"./ion-app_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-app_8-md.entry.js",
		"common",
		5
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-avatar_3-ios.entry.js",
		"common",
		6
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-avatar_3-md.entry.js",
		"common",
		7
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-back-button-ios.entry.js",
		"common",
		8
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-back-button-md.entry.js",
		"common",
		9
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-backdrop-ios.entry.js",
		10
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-backdrop-md.entry.js",
		11
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-button_2-ios.entry.js",
		"common",
		12
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-button_2-md.entry.js",
		"common",
		13
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-card_5-ios.entry.js",
		"common",
		14
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-card_5-md.entry.js",
		"common",
		15
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-checkbox-ios.entry.js",
		"common",
		16
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-checkbox-md.entry.js",
		"common",
		17
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-chip-ios.entry.js",
		"common",
		18
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-chip-md.entry.js",
		"common",
		19
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js",
		20
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-datetime_3-ios.entry.js",
		"common",
		21
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-datetime_3-md.entry.js",
		"common",
		22
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-fab_3-ios.entry.js",
		"common",
		23
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-fab_3-md.entry.js",
		"common",
		24
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-img.entry.js",
		25
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-ios.entry.js",
		26
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-md.entry.js",
		27
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-input-ios.entry.js",
		"common",
		28
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-input-md.entry.js",
		"common",
		29
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item-option_3-ios.entry.js",
		"common",
		30
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item-option_3-md.entry.js",
		"common",
		31
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item_8-ios.entry.js",
		"common",
		32
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item_8-md.entry.js",
		"common",
		33
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-loading-ios.entry.js",
		"common",
		34
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-loading-md.entry.js",
		"common",
		35
	],
	"./ion-menu_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-menu_3-ios.entry.js",
		"common",
		36
	],
	"./ion-menu_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-menu_3-md.entry.js",
		"common",
		37
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-modal-ios.entry.js",
		"common",
		38
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-modal-md.entry.js",
		"common",
		39
	],
	"./ion-nav_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js",
		"common",
		40
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-popover-ios.entry.js",
		"common",
		41
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-popover-md.entry.js",
		"common",
		42
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-progress-bar-ios.entry.js",
		"common",
		43
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-progress-bar-md.entry.js",
		"common",
		44
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-radio_2-ios.entry.js",
		"common",
		45
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-radio_2-md.entry.js",
		"common",
		46
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-range-ios.entry.js",
		"common",
		47
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-range-md.entry.js",
		"common",
		48
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-refresher_2-ios.entry.js",
		"common",
		49
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-refresher_2-md.entry.js",
		"common",
		50
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-reorder_2-ios.entry.js",
		"common",
		51
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-reorder_2-md.entry.js",
		"common",
		52
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js",
		53
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js",
		"common",
		54
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-searchbar-ios.entry.js",
		"common",
		55
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-searchbar-md.entry.js",
		"common",
		56
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-segment_2-ios.entry.js",
		"common",
		57
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-segment_2-md.entry.js",
		"common",
		58
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-select_3-ios.entry.js",
		"common",
		59
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-select_3-md.entry.js",
		"common",
		60
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-slide_2-ios.entry.js",
		61
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-slide_2-md.entry.js",
		62
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js",
		"common",
		63
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-split-pane-ios.entry.js",
		64
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-split-pane-md.entry.js",
		65
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-ios.entry.js",
		"common",
		66
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-md.entry.js",
		"common",
		67
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js",
		"common",
		68
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-text.entry.js",
		"common",
		69
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-textarea-ios.entry.js",
		"common",
		70
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-textarea-md.entry.js",
		"common",
		71
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toast-ios.entry.js",
		"common",
		72
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toast-md.entry.js",
		"common",
		73
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toggle-ios.entry.js",
		"common",
		74
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toggle-md.entry.js",
		"common",
		75
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js",
		76
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <ion-split-pane contentId=\"main-content\">\n    <ion-menu contentId=\"main-content\" type=\"overlay\" auto-hide=\"false\">\n      <ion-header>\n        <div class=\"top-header\">\n          <img src=\"assets/images/profile_pic.jpg\" *ngIf=\"userData?.picture == null || userData?.picture == '' \"/>\n          <img src=\"{{userData?.picture}}\" *ngIf=\"userData?.picture != null && userData?.picture != ''\"/>\n          <p>{{userData?.name}}</p>\n        </div>\n      </ion-header>\n      <ion-content class=\"ion-menu-content\">\n        <ion-list class=\"ion-menu-list\">\n          <!-- <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\"> -->\n          <ion-menu-toggle auto-hide=\"false\">\n            <!-- <ion-item\n              routerDirection=\"root\"\n              [routerLink]=\"[p.url]\"\n              detail=\"false\"\n              class=\"side-menu-items\"\n            >\n              <img class=\"menu-icon-img\" [src]=\"p.icon\" />\n              <ion-label>\n                {{ p.title }}\n              </ion-label>\n            </ion-item> -->\n\n            <ion-item detail=\"false\" class=\"side-menu-items\" (click)=\"gotoPage('week-workout')\" [ngClass]=\"{'active': selectedItem == 'week-workout'}\">\n              <img class=\"menu-icon-img\" src=\"assets/images/work.png\" />\n              <ion-label>\n                This Weeks Workout\n              </ion-label>\n            </ion-item>\n\n            <ion-item detail=\"false\" class=\"side-menu-items\"  (click)=\"gotoPage('profile')\" [ngClass]=\"{'active': selectedItem == 'profile'}\">\n              <img class=\"menu-icon-img\" src=\"assets/images/profile.png\" />\n              <ion-label>\n                Profile\n              </ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n\n          <!-- Assessment -->\n          <!-- [routerLink]=\"/assessment\" -->\n\n          <ion-item detail=\"false\" (click)=\"\n              isAssessment === 1 ? (isAssessment = 0) : (isAssessment = 1)\n            \" class=\"side-menu-items\">\n            <img class=\"menu-icon-img\" src=\"assets/images/menu.png\" />\n            <ion-label>\n              Assessment\n            </ion-label>\n            <ion-icon style=\"font-size: 16px;\" slot=\"end\" color=\"light\"\n              [name]=\"isAssessment? 'caret-down-outline' : 'caret-forward-outline'\"></ion-icon>\n          </ion-item>\n\n          <ion-menu-toggle auto-hide=\"false\">\n            <ion-item [hidden]=\"!isAssessment\" (click)=\"goTo('assessment','assessment')\" [ngClass]=\"{'active': selectedItem == 'assessment?type=assessment'}\"  class=\"sub-menu\">\n              <!-- <ion-icon name=\"calendar\" slot=\"start\"></ion-icon> -->\n              <ion-label>\n                Update Assessment\n              </ion-label>\n            </ion-item>\n            <ion-item [hidden]=\"!isAssessment\" (click)=\"goTo('assessment','information')\" [ngClass]=\"{'active': selectedItem == 'assessment?type=information'}\" \n              class=\"sub-menu\">\n              <!-- <ion-icon name=\"calendar\" slot=\"start\"></ion-icon> -->\n              <ion-label>\n                Update Information\n              </ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n          <!--  -->\n\n          <ion-menu-toggle auto-hide=\"false\">\n            <ion-item  (click)=\"gotoPage('settings')\" [ngClass]=\"{'active': selectedItem == 'settings'}\"  detail=\"false\" class=\"side-menu-items\">\n              <img class=\"menu-icon-img\" src=\"assets/images/goal.png\" />\n              <ion-label>\n                Goal Setting\n              </ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n\n          <!-- <ion-menu-toggle auto-hide=\"false\"> -->\n          <!-- Spirit -->\n          <ion-item lines=\"none\" (click)=\"isSpirit === 1 ? (isSpirit = 0) : (isSpirit = 1)\">\n            <img class=\"menu-icon-img\" src=\"assets/images/spirit.png\" />\n            <ion-label>\n              Spirit\n            </ion-label>\n            <ion-icon style=\"font-size: 16px;\" slot=\"end\" color=\"light\"\n              [name]=\"isSpirit ? 'caret-down-outline' : 'caret-forward-outline'\"></ion-icon>\n\n          </ion-item>\n\n          <ion-menu-toggle auto-hide=\"false\">\n            <ion-list lines=\"none\">\n              <ion-item [hidden]=\"!isSpirit\" (click)=\"goTo('spirit','guid')\" [ngClass]=\"{'active': selectedItem == 'spirit?type=guid'}\"\n                class=\"sub-menu\">\n                <!-- <ion-icon name=\"calendar\" slot=\"start\"></ion-icon> -->\n                <ion-label>\n                  Spirit Guide\n                </ion-label>\n              </ion-item>\n              <ion-item [hidden]=\"!isSpirit\" (click)=\"goTo('spirit','connect')\" [ngClass]=\"{'active': selectedItem == 'spirit?type=connect'}\"\n                class=\"sub-menu\">\n                <!-- <ion-icon name=\"calendar\" slot=\"start\"></ion-icon> -->\n                <ion-label>\n                  Connect With Your Spirit\n                </ion-label>\n              </ion-item>\n            </ion-list>\n          </ion-menu-toggle>\n          <!--  -->\n          <!-- Mindset -->\n          <ion-item lines=\"none\" (click)=\"isMindset === 1 ? (isMindset = 0) : (isMindset = 1)\">\n            <img class=\"menu-icon-img\" src=\"assets/images/mindse.png\" />\n            <ion-label>\n              Mindset\n            </ion-label>\n            <ion-icon style=\"font-size: 16px;\" slot=\"end\" color=\"light\"\n              [name]=\"isMindset ? 'caret-down-outline' : 'caret-forward-outline'\"></ion-icon>\n          </ion-item>\n\n          <ion-menu-toggle auto-hide=\"false\">\n            <ion-list lines=\"none\">\n              <ion-item [hidden]=\"!isMindset\" (click)=\"goTo('mindset','guid')\" [ngClass]=\"{'active': selectedItem == 'mindset?type=guid'}\"\n                class=\"sub-menu\">\n                <!-- <ion-icon name=\"calendar\" slot=\"start\"></ion-icon> -->\n                <ion-label>\n                  Mindset Guide\n                </ion-label>\n              </ion-item>\n              <ion-item menuclose [hidden]=\"!isMindset\" (click)=\"goTo('mindset','sharping')\" [ngClass]=\"{'active': selectedItem == 'mindset?type=sharping'}\"\n                menuClose class=\"sub-menu\">\n                <!-- <ion-icon name=\"calendar\" slot=\"start\"></ion-icon> -->\n                <ion-label>\n                  Sharping Your Mindset\n                </ion-label>\n              </ion-item>\n            </ion-list>\n          </ion-menu-toggle>\n          <!--  -->\n          <!-- Nutrition -->\n          <ion-item lines=\"none\" (click)=\"isNutrition === 1 ? (isNutrition = 0) : (isNutrition = 1)\">\n            <img class=\"menu-icon-img\" src=\"assets/images/nutrition.png\" />\n            <ion-label>\n              Nutrition\n            </ion-label>\n            <ion-icon style=\"font-size: 16px;\" slot=\"end\" color=\"light\"\n              [name]=\"isNutrition ? 'caret-down-outline' : 'caret-forward-outline'\"></ion-icon>\n\n          </ion-item>\n\n          <ion-menu-toggle auto-hide=\"false\">\n            <ion-list lines=\"none\">\n              <ion-item [hidden]=\"!isNutrition\" (click)=\"goTo('nutrition','mens-guid')\" [ngClass]=\"{'active': selectedItem == 'nutrition?type=mens-guid'}\"\n                class=\"sub-menu\">\n                <!-- <ion-icon name=\"calendar\" slot=\"start\"></ion-icon> -->\n                <ion-label>\n                  Men's Nutrition Guide\n                </ion-label>\n              </ion-item>\n\n              <ion-item [hidden]=\"!isNutrition\" (click)=\"goTo('nutrition','womens-guid')\" [ngClass]=\"{'active': selectedItem == 'nutrition?type=womens-guid'}\"\n                class=\"sub-menu\">\n                <!-- <ion-icon name=\"calendar\" slot=\"start\"></ion-icon> -->\n                <ion-label>\n                  Women's Nutrition Guide\n                </ion-label>\n              </ion-item>\n\n              <ion-item menuclose [hidden]=\"!isNutrition\" (click)=\"goTo('nutrition','videos')\" [ngClass]=\"{'active': selectedItem == 'nutrition?type=videos'}\" menuClose class=\"sub-menu\">\n                <!-- <ion-icon name=\"calendar\" slot=\"start\"></ion-icon> -->\n                <ion-label>\n                  Nutrition Videos\n                </ion-label>\n              </ion-item>\n            </ion-list>\n          </ion-menu-toggle>\n          <!--  -->\n\n          <!-- Exercise -->\n          <ion-item lines=\"none\" (click)=\"isExersise === 1 ? (isExersise = 0) : (isExersise = 1)\">\n            <img class=\"menu-icon-img\" src=\"assets/images/nutrition.png\" />\n            <ion-label>\n              Exercise\n            </ion-label>\n            <ion-icon style=\"font-size: 16px;\" slot=\"end\" color=\"light\"\n              [name]=\"isExersise ? 'caret-down-outline' : 'caret-forward-outline'\"></ion-icon>\n          </ion-item>\n\n          <ion-menu-toggle auto-hide=\"false\">\n            <ion-list lines=\"none\">\n              <ion-item [hidden]=\"!isExersise\" (click)=\"goTo('exercises','guid')\" [ngClass]=\"{'active': selectedItem == 'exercises?type=guid'}\" \n                class=\"sub-menu\">\n                <!-- <ion-icon name=\"calendar\" slot=\"start\"></ion-icon> -->\n                <ion-label>\n                  Exercise Guide\n                </ion-label>\n              </ion-item>\n              <ion-item menuclose [hidden]=\"!isExersise\"  (click)=\"gotoPage('mobility-flexibility')\" [ngClass]=\"{'active': selectedItem == 'mobility-flexibility'}\" menuClose\n                class=\"sub-menu\">\n                <ion-label>\n                  Mobility & Flexibility\n                </ion-label>\n              </ion-item>\n              <ion-item menuclose [hidden]=\"!isExersise\" (click)=\"gotoPage('balance-coordination')\" [ngClass]=\"{'active': selectedItem == 'balance-coordination'}\" menuClose\n                class=\"sub-menu\">\n                <ion-label>\n                  Balance & Coordination\n                </ion-label>\n              </ion-item>\n              <ion-item menuclose [hidden]=\"!isExersise\" (click)=\"gotoPage('core-conditioning')\" [ngClass]=\"{'active': selectedItem == 'core-conditioning'}\" menuClose\n                class=\"sub-menu\">\n                <ion-label>\n                  Core & Conditioning\n                </ion-label>\n              </ion-item>\n              <ion-item menuclose [hidden]=\"!isExersise\" (click)=\"gotoPage('functional')\" [ngClass]=\"{'active': selectedItem == 'functional'}\" menuClose class=\"sub-menu\">\n                <ion-label>\n                  Functional Resistance Strength Training\n                </ion-label>\n              </ion-item>\n            </ion-list>\n          </ion-menu-toggle>\n          <!--  -->\n          <!-- </ion-menu-toggle> -->\n          <ion-menu-toggle auto-hide=\"false\">\n            <ion-item (click)=\"gotoPage('body-weight')\" [ngClass]=\"{'active': selectedItem == 'body-weight'}\"  detail=\"false\" class=\"side-menu-items\">\n              <img class=\"menu-icon-img\" src=\"assets/images/exercise.png\" />\n              <ion-label>\n                Body Weight Training\n              </ion-label>\n            </ion-item>\n\n            <ion-item (click)=\"gotoPage('liked-exercises')\" [ngClass]=\"{'active': selectedItem == 'liked-exercises'}\" detail=\"false\" class=\"side-menu-items\">\n              <img class=\"menu-icon-img\" src=\"assets/images/heart.png\" />\n              <ion-label>\n                Liked Exercises\n              </ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n      <ion-footer>\n        <div class=\"bottom-button\">\n          <ion-button class=\"signout\" (click)=\"signOut()\">\n            <ion-icon name=\"log-out-outline\"></ion-icon> SIGN OUT\n          </ion-button>\n        </div>\n      </ion-footer>\n    </ion-menu>\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/detailspirit/detailspirit.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/detailspirit/detailspirit.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>{{data.title}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-icon name=\"close-outline\" (click)=\"back()\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card>  \n    <ion-card-header>  \n      <!-- <ion-card-subtitle>Training Institute</ion-card-subtitle>   -->\n      <!-- <ion-card-title>{{data.title}}</ion-card-title>   -->\n      <!-- <ion-thumbnail> -->\n        <img src=\"{{data.image}}\" class=\"detail-spiritimage\" *ngIf=\"data?.image!= null && type != 'nutrition's\">\n        <iframe  *ngIf=\"data?.trustedVideoUrl!= null && type == 'nutrition' \" style= \"z-index:999\" height=\"200px\" width=\"100%\" preload=\"none\" target=\"_parent\"  [src]=\"data?.trustedVideoUrl\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe> \n      <!-- </ion-thumbnail> -->\n      </ion-card-header>  \n    <ion-card-content>  \n    {{data.description}}\n   </ion-card-content>  \n  </ion-card>  \n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/search-exercises/search-exercises.page.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/search-exercises/search-exercises.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <!-- <ion-menu-button (click)=\"home()\"></ion-menu-button> -->\n    </ion-buttons>\n    <ion-title>SEARCH EXERCISES</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-icon name=\"close-outline\" (click)=\"back()\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>");

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");



const routes = [
    {
        path: 'home',
        loadChildren: () => __webpack_require__.e(/*! import() | home-home-module */ "home-home-module").then(__webpack_require__.bind(null, /*! ./home/home.module */ "./src/app/home/home.module.ts")).then(m => m.HomePageModule)
    },
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'login',
        loadChildren: () => Promise.all(/*! import() | login-login-module */[__webpack_require__.e("common"), __webpack_require__.e("login-login-module")]).then(__webpack_require__.bind(null, /*! ./login/login.module */ "./src/app/login/login.module.ts")).then(m => m.LoginPageModule)
    },
    {
        path: 'signup',
        loadChildren: () => Promise.all(/*! import() | signup-signup-module */[__webpack_require__.e("common"), __webpack_require__.e("signup-signup-module")]).then(__webpack_require__.bind(null, /*! ./signup/signup.module */ "./src/app/signup/signup.module.ts")).then(m => m.SignupPageModule)
    },
    {
        path: 'bodyfirst-program',
        loadChildren: () => __webpack_require__.e(/*! import() | bodyfirst-program-bodyfirst-program-module */ "bodyfirst-program-bodyfirst-program-module").then(__webpack_require__.bind(null, /*! ./bodyfirst-program/bodyfirst-program.module */ "./src/app/bodyfirst-program/bodyfirst-program.module.ts")).then(m => m.BodyfirstProgramPageModule)
    },
    {
        path: 'week-workout',
        loadChildren: () => __webpack_require__.e(/*! import() | week-workout-week-workout-module */ "week-workout-week-workout-module").then(__webpack_require__.bind(null, /*! ./week-workout/week-workout.module */ "./src/app/week-workout/week-workout.module.ts")).then(m => m.WeekWorkoutPageModule)
    },
    {
        path: 'edit-profile',
        loadChildren: () => Promise.all(/*! import() | edit-profile-edit-profile-module */[__webpack_require__.e("common"), __webpack_require__.e("edit-profile-edit-profile-module")]).then(__webpack_require__.bind(null, /*! ./edit-profile/edit-profile.module */ "./src/app/edit-profile/edit-profile.module.ts")).then(m => m.EditProfilePageModule)
    },
    {
        path: 'card-information',
        loadChildren: () => Promise.all(/*! import() | card-information-card-information-module */[__webpack_require__.e("common"), __webpack_require__.e("card-information-card-information-module")]).then(__webpack_require__.bind(null, /*! ./card-information/card-information.module */ "./src/app/card-information/card-information.module.ts")).then(m => m.CardInformationPageModule)
    },
    {
        path: 'exercises',
        loadChildren: () => __webpack_require__.e(/*! import() | exercises-exercises-module */ "exercises-exercises-module").then(__webpack_require__.bind(null, /*! ./exercises/exercises.module */ "./src/app/exercises/exercises.module.ts")).then(m => m.ExercisesPageModule)
    },
    {
        path: 'mindset',
        loadChildren: () => __webpack_require__.e(/*! import() | mindset-mindset-module */ "mindset-mindset-module").then(__webpack_require__.bind(null, /*! ./mindset/mindset.module */ "./src/app/mindset/mindset.module.ts")).then(m => m.MindsetPageModule)
    },
    {
        path: 'nutrition',
        loadChildren: () => __webpack_require__.e(/*! import() | nutrition-nutrition-module */ "nutrition-nutrition-module").then(__webpack_require__.bind(null, /*! ./nutrition/nutrition.module */ "./src/app/nutrition/nutrition.module.ts")).then(m => m.NutritionPageModule)
    },
    {
        path: 'spirit',
        loadChildren: () => __webpack_require__.e(/*! import() | spirit-spirit-module */ "spirit-spirit-module").then(__webpack_require__.bind(null, /*! ./spirit/spirit.module */ "./src/app/spirit/spirit.module.ts")).then(m => m.SpiritPageModule)
    },
    {
        path: 'abs',
        loadChildren: () => __webpack_require__.e(/*! import() | abs-abs-module */ "abs-abs-module").then(__webpack_require__.bind(null, /*! ./abs/abs.module */ "./src/app/abs/abs.module.ts")).then(m => m.AbsPageModule)
    },
    {
        path: 'functional',
        loadChildren: () => __webpack_require__.e(/*! import() | functional-functional-module */ "functional-functional-module").then(__webpack_require__.bind(null, /*! ./functional/functional.module */ "./src/app/functional/functional.module.ts")).then(m => m.FunctionalPageModule)
    },
    {
        path: 'survey',
        loadChildren: () => __webpack_require__.e(/*! import() | survey-survey-module */ "survey-survey-module").then(__webpack_require__.bind(null, /*! ./survey/survey.module */ "./src/app/survey/survey.module.ts")).then(m => m.SurveyPageModule)
    },
    {
        path: 'profile',
        loadChildren: () => __webpack_require__.e(/*! import() | profile-profile-module */ "profile-profile-module").then(__webpack_require__.bind(null, /*! ./profile/profile.module */ "./src/app/profile/profile.module.ts")).then(m => m.ProfilePageModule)
    },
    {
        path: 'mobility-flexibility',
        loadChildren: () => __webpack_require__.e(/*! import() | mobility-flexibility-mobility-flexibility-module */ "mobility-flexibility-mobility-flexibility-module").then(__webpack_require__.bind(null, /*! ./mobility-flexibility/mobility-flexibility.module */ "./src/app/mobility-flexibility/mobility-flexibility.module.ts")).then(m => m.MobilityFlexibilityPageModule)
    },
    {
        path: 'balance-coordination',
        loadChildren: () => __webpack_require__.e(/*! import() | balance-coordination-balance-coordination-module */ "balance-coordination-balance-coordination-module").then(__webpack_require__.bind(null, /*! ./balance-coordination/balance-coordination.module */ "./src/app/balance-coordination/balance-coordination.module.ts")).then(m => m.BalanceCoordinationPageModule)
    },
    {
        path: 'core-conditioning',
        loadChildren: () => __webpack_require__.e(/*! import() | core-conditioning-core-conditioning-module */ "core-conditioning-core-conditioning-module").then(__webpack_require__.bind(null, /*! ./core-conditioning/core-conditioning.module */ "./src/app/core-conditioning/core-conditioning.module.ts")).then(m => m.CoreConditioningPageModule)
    },
    {
        path: 'liked-exercises',
        loadChildren: () => Promise.all(/*! import() | liked-exercises-liked-exercises-module */[__webpack_require__.e("common"), __webpack_require__.e("liked-exercises-liked-exercises-module")]).then(__webpack_require__.bind(null, /*! ./liked-exercises/liked-exercises.module */ "./src/app/liked-exercises/liked-exercises.module.ts")).then(m => m.LikedExercisesPageModule)
    },
    {
        path: 'settings',
        loadChildren: () => Promise.all(/*! import() | settings-settings-module */[__webpack_require__.e("common"), __webpack_require__.e("settings-settings-module")]).then(__webpack_require__.bind(null, /*! ./settings/settings.module */ "./src/app/settings/settings.module.ts")).then(m => m.SettingsPageModule)
    },
    {
        path: 'assessment',
        loadChildren: () => Promise.all(/*! import() | assessment-assessment-module */[__webpack_require__.e("common"), __webpack_require__.e("assessment-assessment-module")]).then(__webpack_require__.bind(null, /*! ./assessment/assessment.module */ "./src/app/assessment/assessment.module.ts")).then(m => m.AssessmentPageModule)
    },
    {
        path: 'find-workout-plan',
        loadChildren: () => __webpack_require__.e(/*! import() | find-workout-plan-find-workout-plan-module */ "find-workout-plan-find-workout-plan-module").then(__webpack_require__.bind(null, /*! ./find-workout-plan/find-workout-plan.module */ "./src/app/find-workout-plan/find-workout-plan.module.ts")).then(m => m.FindWorkoutPlanPageModule)
    },
    {
        path: 'selected-plan',
        loadChildren: () => __webpack_require__.e(/*! import() | selected-plan-selected-plan-module */ "selected-plan-selected-plan-module").then(__webpack_require__.bind(null, /*! ./selected-plan/selected-plan.module */ "./src/app/selected-plan/selected-plan.module.ts")).then(m => m.SelectedPlanPageModule)
    },
    {
        path: 'videos',
        loadChildren: () => __webpack_require__.e(/*! import() | videos-videos-module */ "videos-videos-module").then(__webpack_require__.bind(null, /*! ./videos/videos.module */ "./src/app/videos/videos.module.ts")).then(m => m.VideosPageModule)
    },
    {
        path: 'subscription',
        loadChildren: () => Promise.all(/*! import() | subscription-subscription-module */[__webpack_require__.e("common"), __webpack_require__.e("subscription-subscription-module")]).then(__webpack_require__.bind(null, /*! ./subscription/subscription.module */ "./src/app/subscription/subscription.module.ts")).then(m => m.SubscriptionPageModule)
    },
    {
        path: 'search-exercises',
        loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(null, /*! ./search-exercises/search-exercises.module */ "./src/app/search-exercises/search-exercises.module.ts")).then(m => m.SearchExercisesPageModule)
    },
    {
        path: 'subscriptions',
        loadChildren: () => Promise.all(/*! import() | subscriptions-subscriptions-module */[__webpack_require__.e("common"), __webpack_require__.e("subscriptions-subscriptions-module")]).then(__webpack_require__.bind(null, /*! ./subscriptions/subscriptions.module */ "./src/app/subscriptions/subscriptions.module.ts")).then(m => m.SubscriptionsPageModule)
    },
    {
        path: 'body-weight',
        loadChildren: () => __webpack_require__.e(/*! import() | body-weight-body-weight-module */ "body-weight-body-weight-module").then(__webpack_require__.bind(null, /*! ./body-weight/body-weight.module */ "./src/app/body-weight/body-weight.module.ts")).then(m => m.BodyWeightPageModule)
    },
    {
        path: 'detailspirit',
        loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(null, /*! ./detailspirit/detailspirit.module */ "./src/app/detailspirit/detailspirit.module.ts")).then(m => m.DetailspiritPageModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".top-header {\n  text-align: center;\n  background: #233942;\n  padding: 20px;\n  color: #fff;\n  border-bottom: 1px solid #fff;\n}\n.top-header p {\n  margin: 0;\n  text-align: center;\n  font-size: 18px;\n}\n.top-header img {\n  border-radius: 50%;\n  width: 100px;\n  height: 100px;\n  border: 3px solid #f77e21;\n}\nion-content {\n  background: #233942;\n  --background: #233942;\n}\nion-content ion-item {\n  background: #233942;\n  line-height: 18px;\n  --background: #233942;\n  border: 0px;\n  --border-color: #233942;\n  --border-bottom: 0px solid #233942;\n  --border-width: 0px;\n  border-top: 0px solid transparent;\n}\nion-content ion-item ion-label {\n  --color: #fff !important;\n  margin-left: 10px;\n  font-family: Rajdhani-Regular;\n  font-size: 16px !important;\n  border: 0px;\n  --border-color: transparent;\n  --border-width: 0px;\n  letter-spacing: 1px;\n}\nion-menu {\n  --width: 240px;\n  --background: #233942;\n}\nion-list {\n  background: #233942;\n}\n.side-menu-items ion-label {\n  color: #fff;\n  padding-left: 8px;\n}\nion-footer {\n  background: #233942;\n  --background: #233942;\n}\nion-footer .bottom-button {\n  margin: 0 auto;\n  margin-top: 40px;\n  text-align: center;\n  margin-bottom: 20px;\n}\nion-footer .bottom-button ion-button.signout {\n  --background: #f77e21;\n  --border-radius: 0px;\n  font-size: 14px;\n  color: #fff;\n  text-align: center;\n  letter-spacing: 1px;\n}\nion-footer .bottom-button ion-button.signout ion-icon {\n  color: #fff;\n  margin-right: 10px;\n}\nion-item.side-menu-items.active {\n  --background: #f77e21 !important;\n}\nion-item.sub-menu.active {\n  --background: #f77e21 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7QUNDSjtBRENJO0VBQ0ksU0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQ0NSO0FERUk7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7QUNBUjtBRElBO0VBQ0ksbUJBQUE7RUFDQSxxQkFBQTtBQ0RKO0FER0k7RUFDSSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsaUNBQUE7QUNEUjtBREdRO0VBQ0ksd0JBQUE7RUFDQSxpQkFBQTtFQUNBLDZCQUFBO0VBRUEsMEJBQUE7RUFDQSxXQUFBO0VBQ0EsMkJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0FDRlo7QURRQTtFQUNJLGNBQUE7RUFDQSxxQkFBQTtBQ0xKO0FEUUE7RUFDSSxtQkFBQTtBQ0xKO0FEU0k7RUFDSSxXQUFBO0VBQ0EsaUJBQUE7QUNOUjtBRFVBO0VBQ0ksbUJBQUE7RUFDQSxxQkFBQTtBQ1BKO0FEU0k7RUFDSSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDUFI7QURTUTtFQUNJLHFCQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUNQWjtBRFlZO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0FDVmhCO0FEZUE7RUFDSSxnQ0FBQTtBQ1pKO0FEY0E7RUFDSSxnQ0FBQTtBQ1hKIiwiZmlsZSI6InNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvcC1oZWFkZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICAgIHBhZGRpbmc6IDIwcHg7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmZmY7XG5cbiAgICBwIHtcbiAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICB9XG5cbiAgICBpbWcge1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgIHdpZHRoOiAxMDBweDtcbiAgICAgICAgaGVpZ2h0OiAxMDBweDtcbiAgICAgICAgYm9yZGVyOiAzcHggc29saWQgI2Y3N2UyMTtcbiAgICB9XG59XG5cbmlvbi1jb250ZW50IHtcbiAgICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICAgIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcblxuICAgIGlvbi1pdGVtIHtcbiAgICAgICAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICAgICAgbGluZS1oZWlnaHQ6IDE4cHg7XG4gICAgICAgIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICAgICAgYm9yZGVyOiAwcHg7XG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiAjMjMzOTQyO1xuICAgICAgICAtLWJvcmRlci1ib3R0b206IDBweCBzb2xpZCAjMjMzOTQyO1xuICAgICAgICAtLWJvcmRlci13aWR0aDogMHB4O1xuICAgICAgICBib3JkZXItdG9wOiAwcHggc29saWQgdHJhbnNwYXJlbnQ7XG5cbiAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgIC0tY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG5cbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweCAhaW1wb3J0YW50O1xuICAgICAgICAgICAgYm9yZGVyOiAwcHg7XG4gICAgICAgICAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICAgICAgICAtLWJvcmRlci13aWR0aDogMHB4O1xuICAgICAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICAgICAgfVxuICAgIH1cblxufVxuXG5pb24tbWVudSB7XG4gICAgLS13aWR0aDogMjQwcHg7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xufVxuXG5pb24tbGlzdCB7XG4gICAgYmFja2dyb3VuZDogIzIzMzk0Mjtcbn1cblxuLnNpZGUtbWVudS1pdGVtcyB7XG4gICAgaW9uLWxhYmVsIHtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgIHBhZGRpbmctbGVmdDogOHB4O1xuICAgIH1cbn1cblxuaW9uLWZvb3RlciB7XG4gICAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICAtLWJhY2tncm91bmQ6ICMyMzM5NDI7XG5cbiAgICAuYm90dG9tLWJ1dHRvbiB7XG4gICAgICAgIG1hcmdpbjogMCBhdXRvO1xuICAgICAgICBtYXJnaW4tdG9wOiA0MHB4O1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG5cbiAgICAgICAgaW9uLWJ1dHRvbi5zaWdub3V0IHtcbiAgICAgICAgICAgIC0tYmFja2dyb3VuZDogI2Y3N2UyMTtcbiAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogMHB4O1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuXG4gICAgICAgICAgICAvLyBib3R0b206IDEwcHg7XG4gICAgICAgICAgICAvLyBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAvLyBsZWZ0OiAzMiU7XG4gICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuaW9uLWl0ZW0uc2lkZS1tZW51LWl0ZW1zLmFjdGl2ZXtcbiAgICAtLWJhY2tncm91bmQ6ICNmNzdlMjEgIWltcG9ydGFudDtcbn1cbmlvbi1pdGVtLnN1Yi1tZW51LmFjdGl2ZXtcbiAgICAtLWJhY2tncm91bmQ6ICNmNzdlMjEgIWltcG9ydGFudDtcblxufSIsIi50b3AtaGVhZGVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBwYWRkaW5nOiAyMHB4O1xuICBjb2xvcjogI2ZmZjtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmZmY7XG59XG4udG9wLWhlYWRlciBwIHtcbiAgbWFyZ2luOiAwO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMThweDtcbn1cbi50b3AtaGVhZGVyIGltZyB7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgd2lkdGg6IDEwMHB4O1xuICBoZWlnaHQ6IDEwMHB4O1xuICBib3JkZXI6IDNweCBzb2xpZCAjZjc3ZTIxO1xufVxuXG5pb24tY29udGVudCB7XG4gIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0Mjtcbn1cbmlvbi1jb250ZW50IGlvbi1pdGVtIHtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgbGluZS1oZWlnaHQ6IDE4cHg7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgYm9yZGVyOiAwcHg7XG4gIC0tYm9yZGVyLWNvbG9yOiAjMjMzOTQyO1xuICAtLWJvcmRlci1ib3R0b206IDBweCBzb2xpZCAjMjMzOTQyO1xuICAtLWJvcmRlci13aWR0aDogMHB4O1xuICBib3JkZXItdG9wOiAwcHggc29saWQgdHJhbnNwYXJlbnQ7XG59XG5pb24tY29udGVudCBpb24taXRlbSBpb24tbGFiZWwge1xuICAtLWNvbG9yOiAjZmZmICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgZm9udC1zaXplOiAxNnB4ICFpbXBvcnRhbnQ7XG4gIGJvcmRlcjogMHB4O1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIC0tYm9yZGVyLXdpZHRoOiAwcHg7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG59XG5cbmlvbi1tZW51IHtcbiAgLS13aWR0aDogMjQwcHg7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0Mjtcbn1cblxuaW9uLWxpc3Qge1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xufVxuXG4uc2lkZS1tZW51LWl0ZW1zIGlvbi1sYWJlbCB7XG4gIGNvbG9yOiAjZmZmO1xuICBwYWRkaW5nLWxlZnQ6IDhweDtcbn1cblxuaW9uLWZvb3RlciB7XG4gIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0Mjtcbn1cbmlvbi1mb290ZXIgLmJvdHRvbS1idXR0b24ge1xuICBtYXJnaW46IDAgYXV0bztcbiAgbWFyZ2luLXRvcDogNDBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuaW9uLWZvb3RlciAuYm90dG9tLWJ1dHRvbiBpb24tYnV0dG9uLnNpZ25vdXQge1xuICAtLWJhY2tncm91bmQ6ICNmNzdlMjE7XG4gIC0tYm9yZGVyLXJhZGl1czogMHB4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjZmZmO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG59XG5pb24tZm9vdGVyIC5ib3R0b20tYnV0dG9uIGlvbi1idXR0b24uc2lnbm91dCBpb24taWNvbiB7XG4gIGNvbG9yOiAjZmZmO1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cbmlvbi1pdGVtLnNpZGUtbWVudS1pdGVtcy5hY3RpdmUge1xuICAtLWJhY2tncm91bmQ6ICNmNzdlMjEgIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW0uc3ViLW1lbnUuYWN0aXZlIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZjc3ZTIxICFpbXBvcnRhbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _service_events_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./service/events.service */ "./src/app/service/events.service.ts");








let AppComponent = class AppComponent {
    constructor(platform, splashScreen, statusBar, navCtrl, menuCtrl, router, events) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.navCtrl = navCtrl;
        this.menuCtrl = menuCtrl;
        this.router = router;
        this.events = events;
        this.isSpirit = 0;
        this.isMindset = 0;
        this.isAssessment = 0;
        this.isNutrition = 0;
        this.isExersise = 0;
        this.userData = '';
        this.selectedItem = 'week-workout';
        this.appPages = [
            {
                title: "This Weeks Workout",
                url: "/week-workout",
                icon: "assets/images/work.png",
            },
            {
                title: "Profile",
                url: "/profile",
                icon: "assets/images/profile.png",
            },
            {
                title: "Assessment",
                url: "/assessment",
                icon: "assets/images/menu.png",
            },
            {
                title: "Goal Setting",
                url: "/settings",
                icon: "assets/images/goal.png",
            },
            // {
            //   title: 'Spirit',
            //   url: '/spirit',
            //   icon: 'assets/images/spirit.png'
            // },
            // {
            //   title: 'Mindset',
            //   url: '/mindset',
            //   icon: 'assets/images/mindse.png'
            // },
            // {
            //   title: 'Nutrition',
            //   url: '/nutrition',
            //   icon: 'assets/images/nutrition.png'
            // },
            // {
            //   title: 'Exercise',
            //   url: '/exercises',
            //   icon: 'assets/images/exercise.png'
            // },
            {
                title: "Body Weight Training",
                url: "/body-weight",
                icon: "assets/images/exercise.png",
            },
            {
                title: "Liked Exercises",
                url: "/liked-exercises",
                icon: "assets/images/heart.png",
            },
        ];
        this.initializeApp();
        this.router.events.subscribe((event) => {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_5__["NavigationEnd"] && event.url === "/login") {
                this.menuCtrl.enable(false);
            }
            else if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_5__["NavigationEnd"] && event.url === "/home") {
                console.log(event.url);
                this.menuCtrl.swipeGesture(false);
            }
            else if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_5__["NavigationEnd"] && event.url === "/signup") {
                this.menuCtrl.enable(false);
            }
            else {
                this.menuCtrl.enable(true);
            }
        });
        console.log(localStorage.getItem('userData'), JSON.parse(localStorage.getItem('userData')));
        if (localStorage.getItem('userData') != undefined && localStorage.getItem('userData') != null) {
            this.userData = JSON.parse(localStorage.getItem('userData'));
            this.navCtrl.navigateRoot("/week-workout");
        }
        this.events.subscribe('user:created', (data) => {
            this.userData = JSON.parse(localStorage.getItem('userData'));
        });
        this.platform.backButton.subscribe(() => {
            alert("exitApp");
            navigator['app'].exitApp();
        });
    }
    initializeApp() {
        this.platform.ready().then(() => {
            this.statusBar.styleDefault();
            if (this.platform.is('android')) {
                this.statusBar.overlaysWebView(false);
            }
            //  this.statusBar.backgroundColorByHexString('#ffffff');
            this.statusBar.styleLightContent();
            this.splashScreen.hide();
        });
    }
    signOut() {
        localStorage.clear();
        this.menuCtrl.close();
        this.navCtrl.navigateRoot("/login");
    }
    goTo(url, type) {
        this.selectedItem = url + '?type=' + type;
        this.navCtrl.navigateRoot(['/' + url], { queryParams: { type: type } });
    }
    gotoPage(url) {
        this.selectedItem = url;
        this.navCtrl.navigateRoot('/' + url);
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _service_events_service__WEBPACK_IMPORTED_MODULE_6__["EventsService"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-root",
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")).default]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/google-plus/ngx */ "./node_modules/@ionic-native/google-plus/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _search_exercises_search_exercises_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./search-exercises/search-exercises.module */ "./src/app/search-exercises/search-exercises.module.ts");
/* harmony import */ var _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/facebook/ngx */ "./node_modules/@ionic-native/facebook/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/stripe/ngx */ "./node_modules/@ionic-native/stripe/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _detailspirit_detailspirit_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./detailspirit/detailspirit.module */ "./src/app/detailspirit/detailspirit.module.ts");
/* harmony import */ var _ionic_native_app_version_ngx__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic-native/app-version/ngx */ "./node_modules/@ionic-native/app-version/__ivy_ngcc__/ngx/index.js");












// import { HttpModule } from '@angular/http';






let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_10__["AppComponent"]],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"].forRoot(), _angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HttpClientModule"], _detailspirit_detailspirit_module__WEBPACK_IMPORTED_MODULE_16__["DetailspiritPageModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_11__["AppRoutingModule"], _search_exercises_search_exercises_module__WEBPACK_IMPORTED_MODULE_8__["SearchExercisesPageModule"]],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__["SplashScreen"],
            _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_9__["Facebook"],
            _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_4__["GooglePlus"],
            _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_13__["SocialSharing"],
            _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_14__["Camera"],
            _ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_15__["Stripe"],
            _ionic_native_app_version_ngx__WEBPACK_IMPORTED_MODULE_17__["AppVersion"],
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicRouteStrategy"] }
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_10__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/detailspirit/detailspirit-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/detailspirit/detailspirit-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: DetailspiritPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailspiritPageRoutingModule", function() { return DetailspiritPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _detailspirit_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./detailspirit.page */ "./src/app/detailspirit/detailspirit.page.ts");




const routes = [
    {
        path: '',
        component: _detailspirit_page__WEBPACK_IMPORTED_MODULE_3__["DetailspiritPage"]
    }
];
let DetailspiritPageRoutingModule = class DetailspiritPageRoutingModule {
};
DetailspiritPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DetailspiritPageRoutingModule);



/***/ }),

/***/ "./src/app/detailspirit/detailspirit.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/detailspirit/detailspirit.module.ts ***!
  \*****************************************************/
/*! exports provided: DetailspiritPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailspiritPageModule", function() { return DetailspiritPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _detailspirit_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./detailspirit-routing.module */ "./src/app/detailspirit/detailspirit-routing.module.ts");
/* harmony import */ var _detailspirit_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./detailspirit.page */ "./src/app/detailspirit/detailspirit.page.ts");







let DetailspiritPageModule = class DetailspiritPageModule {
};
DetailspiritPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _detailspirit_routing_module__WEBPACK_IMPORTED_MODULE_5__["DetailspiritPageRoutingModule"]
        ],
        declarations: [_detailspirit_page__WEBPACK_IMPORTED_MODULE_6__["DetailspiritPage"]]
    })
], DetailspiritPageModule);



/***/ }),

/***/ "./src/app/detailspirit/detailspirit.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/detailspirit/detailspirit.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".detail-spiritimage {\n  margin-top: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL2RldGFpbHNwaXJpdC9kZXRhaWxzcGlyaXQucGFnZS5zY3NzIiwic3JjL2FwcC9kZXRhaWxzcGlyaXQvZGV0YWlsc3Bpcml0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL2RldGFpbHNwaXJpdC9kZXRhaWxzcGlyaXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmRldGFpbC1zcGlyaXRpbWFnZXtcbiAgICBtYXJnaW4tdG9wOiA1cHg7XG59IiwiLmRldGFpbC1zcGlyaXRpbWFnZSB7XG4gIG1hcmdpbi10b3A6IDVweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/detailspirit/detailspirit.page.ts":
/*!***************************************************!*\
  !*** ./src/app/detailspirit/detailspirit.page.ts ***!
  \***************************************************/
/*! exports provided: DetailspiritPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailspiritPage", function() { return DetailspiritPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");




// import { NavParams ,Events} from '@ionic/angular';
let DetailspiritPage = class DetailspiritPage {
    constructor(modalController, route) {
        this.modalController = modalController;
        this.route = route;
        this.data = '';
        this.type = '';
        // this.data = this.navParams.get('data');
        // this.type = this.navParams.get('type');
        console.log(this.data, "data");
        this.route.queryParams.subscribe(params => {
            if (params && params.data) {
                this.data = params.data;
                console.log(this.data);
            }
            if (params && params.type) {
                this.type = params.type;
                console.log(this.type);
            }
        });
    }
    ngOnInit() {
    }
    back() {
        this.modalController.dismiss();
        //  this.navCtrl.navigateBack(['/exercises'],{ queryParams: { type: 'guid' }});
    }
};
DetailspiritPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] }
];
DetailspiritPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-detailspirit',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./detailspirit.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/detailspirit/detailspirit.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./detailspirit.page.scss */ "./src/app/detailspirit/detailspirit.page.scss")).default]
    })
], DetailspiritPage);



/***/ }),

/***/ "./src/app/search-exercises/search-exercises-routing.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/search-exercises/search-exercises-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: SearchExercisesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchExercisesPageRoutingModule", function() { return SearchExercisesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _search_exercises_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search-exercises.page */ "./src/app/search-exercises/search-exercises.page.ts");




const routes = [
    {
        path: '',
        component: _search_exercises_page__WEBPACK_IMPORTED_MODULE_3__["SearchExercisesPage"]
    }
];
let SearchExercisesPageRoutingModule = class SearchExercisesPageRoutingModule {
};
SearchExercisesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SearchExercisesPageRoutingModule);



/***/ }),

/***/ "./src/app/search-exercises/search-exercises.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/search-exercises/search-exercises.module.ts ***!
  \*************************************************************/
/*! exports provided: SearchExercisesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchExercisesPageModule", function() { return SearchExercisesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _search_exercises_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./search-exercises-routing.module */ "./src/app/search-exercises/search-exercises-routing.module.ts");
/* harmony import */ var _search_exercises_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./search-exercises.page */ "./src/app/search-exercises/search-exercises.page.ts");







let SearchExercisesPageModule = class SearchExercisesPageModule {
};
SearchExercisesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _search_exercises_routing_module__WEBPACK_IMPORTED_MODULE_5__["SearchExercisesPageRoutingModule"]
        ],
        declarations: [_search_exercises_page__WEBPACK_IMPORTED_MODULE_6__["SearchExercisesPage"]]
    })
], SearchExercisesPageModule);



/***/ }),

/***/ "./src/app/search-exercises/search-exercises.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/search-exercises/search-exercises.page.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 45px;\n  letter-spacing: 1px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n  margin: 5px;\n  margin-right: 10px;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\n.header ion-back-button {\n  font-size: 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL3NlYXJjaC1leGVyY2lzZXMvc2VhcmNoLWV4ZXJjaXNlcy5wYWdlLnNjc3MiLCJzcmMvYXBwL3NlYXJjaC1leGVyY2lzZXMvc2VhcmNoLWV4ZXJjaXNlcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQ0NKO0FERUk7RUFDSSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUNBUjtBREdJO0VBQ0ksV0FBQTtBQ0RSO0FESUk7RUFDSSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FDRlI7QURLSTtFQUNJLFlBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxXQUFBO0FDSFI7QURNSTtFQUNJLGVBQUE7QUNKUiIsImZpbGUiOiJzcmMvYXBwL3NlYXJjaC1leGVyY2lzZXMvc2VhcmNoLWV4ZXJjaXNlcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyIHtcbiAgICAtLWJhY2tncm91bmQ6ICMyMzM5NDI7XG4gICAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICAvL3BhZGRpbmc6ICA1cHg7XG5cbiAgICBpb24tdGl0bGUge1xuICAgICAgICBwYWRkaW5nOiAwcHg7XG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDQ1cHg7XG4gICAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gICAgfVxuXG4gICAgaW9uLW1lbnUtYnV0dG9uIHtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgfVxuXG4gICAgaW9uLWljb24ge1xuICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICBtYXJnaW46IDVweDtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIH1cblxuICAgIHAge1xuICAgICAgICBmbG9hdDogcmlnaHQ7XG4gICAgICAgIGNvbG9yOiAjZjc3ZTIxO1xuICAgICAgICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgICAgICAgbWFyZ2luOiAwZW07XG4gICAgfVxuXG4gICAgaW9uLWJhY2stYnV0dG9uIHtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgIH1cbn0iLCIuaGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbn1cbi5oZWFkZXIgaW9uLXRpdGxlIHtcbiAgcGFkZGluZzogMHB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgcGFkZGluZy1sZWZ0OiA0NXB4O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xufVxuLmhlYWRlciBpb24tbWVudS1idXR0b24ge1xuICBjb2xvcjogI2ZmZjtcbn1cbi5oZWFkZXIgaW9uLWljb24ge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBtYXJnaW46IDVweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLmhlYWRlciBwIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBjb2xvcjogI2Y3N2UyMTtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gIG1hcmdpbjogMGVtO1xufVxuLmhlYWRlciBpb24tYmFjay1idXR0b24ge1xuICBmb250LXNpemU6IDEycHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/search-exercises/search-exercises.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/search-exercises/search-exercises.page.ts ***!
  \***********************************************************/
/*! exports provided: SearchExercisesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchExercisesPage", function() { return SearchExercisesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let SearchExercisesPage = class SearchExercisesPage {
    constructor(navCtrl, modalController) {
        this.navCtrl = navCtrl;
        this.modalController = modalController;
    }
    ngOnInit() { }
    home() {
    }
    back() {
        this.modalController.dismiss();
        //  this.navCtrl.navigateBack(['/exercises'],{ queryParams: { type: 'guid' }});
    }
};
SearchExercisesPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
SearchExercisesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-search-exercises",
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./search-exercises.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/search-exercises/search-exercises.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./search-exercises.page.scss */ "./src/app/search-exercises/search-exercises.page.scss")).default]
    })
], SearchExercisesPage);



/***/ }),

/***/ "./src/app/service/events.service.ts":
/*!*******************************************!*\
  !*** ./src/app/service/events.service.ts ***!
  \*******************************************/
/*! exports provided: EventsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventsService", function() { return EventsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");



let EventsService = class EventsService {
    constructor() {
        this.channels = {};
    }
    /**
     * Subscribe to a topic and provide a single handler/observer.
     * @param topic The name of the topic to subscribe to.
     * @param observer The observer or callback function to listen when changes are published.
     *
     * @returns Subscription from which you can unsubscribe to release memory resources and to prevent memory leak.
     */
    subscribe(topic, observer) {
        if (!this.channels[topic]) {
            this.channels[topic] = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        }
        return this.channels[topic].subscribe(observer);
    }
    /**
     * Publish some data to the subscribers of the given topic.
     * @param topic The name of the topic to emit data to.
     * @param data data in any format to pass on.
     */
    publish(topic, data) {
        const subject = this.channels[topic];
        if (!subject) {
            // Or you can create a new subject for future subscribers
            return;
        }
        subject.next(data);
    }
    /**
     * When you are sure that you are done with the topic and the subscribers no longer needs to listen to a particular topic, you can
     * destroy the observable of the topic using this method.
     * @param topic The name of the topic to destroy.
     */
    destroy(topic) {
        const subject = this.channels[topic];
        if (!subject) {
            return;
        }
        subject.complete();
        delete this.channels[topic];
    }
};
EventsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], EventsService);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    baseUrl: 'http://192.168.2.181/blog/public/api'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Volumes/Disk2/bodyFirst/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map