(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["abs-abs-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/abs/abs.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/abs/abs.page.html ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <div class=\"header\">\n    <ion-row>\n      <ion-col size=\"1\">\n        <ion-icon name=\"chevron-back-outline\"></ion-icon>\n      </ion-col>\n      <ion-col size=\"9\">\n        <ion-title> BACK</ion-title>\n      </ion-col>\n      <ion-col size=\"2\" text-right> </ion-col>\n    </ion-row>\n  </div>\n</ion-header>\n\n<ion-content>\n  <div class=\"abs\">\n    <img src=\"assets/images/abs.png\" />\n    <ion-icon name=\"play-circle-outline\"></ion-icon>\n  </div>\n  <div class=\"abs-content\">\n    <ion-row>\n      <ion-col>\n        <h3>ABS</h3>\n        <h6>Level: <span>Begineer</span></h6>\n      </ion-col>\n      <ion-col>\n        <ion-icon name=\"heart-outline\"></ion-icon>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col>\n        <ul>\n          <li>\n            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do\n            eiusmod tempor incidi dunt ut labore et dolore magna aliqua.\n          </li>\n          <li>\n            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do\n            eiusmod tempor incidi dunt ut labore et dolore magna aliqua.\n          </li>\n          <li>\n            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do\n            eiusmod tempor incidi dunt ut labore et dolore magna aliqua.\n          </li>\n          <li>\n            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do\n            eiusmod tempor incidi dunt ut labore et dolore magna aliqua.\n          </li>\n        </ul>\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/abs/abs-routing.module.ts":
/*!*******************************************!*\
  !*** ./src/app/abs/abs-routing.module.ts ***!
  \*******************************************/
/*! exports provided: AbsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AbsPageRoutingModule", function() { return AbsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _abs_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./abs.page */ "./src/app/abs/abs.page.ts");




const routes = [
    {
        path: '',
        component: _abs_page__WEBPACK_IMPORTED_MODULE_3__["AbsPage"]
    }
];
let AbsPageRoutingModule = class AbsPageRoutingModule {
};
AbsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AbsPageRoutingModule);



/***/ }),

/***/ "./src/app/abs/abs.module.ts":
/*!***********************************!*\
  !*** ./src/app/abs/abs.module.ts ***!
  \***********************************/
/*! exports provided: AbsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AbsPageModule", function() { return AbsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _abs_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./abs-routing.module */ "./src/app/abs/abs-routing.module.ts");
/* harmony import */ var _abs_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./abs.page */ "./src/app/abs/abs.page.ts");







let AbsPageModule = class AbsPageModule {
};
AbsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _abs_routing_module__WEBPACK_IMPORTED_MODULE_5__["AbsPageRoutingModule"]
        ],
        declarations: [_abs_page__WEBPACK_IMPORTED_MODULE_6__["AbsPage"]]
    })
], AbsPageModule);



/***/ }),

/***/ "./src/app/abs/abs.page.scss":
/*!***********************************!*\
  !*** ./src/app/abs/abs.page.scss ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header {\n  --background:#233942;\n  background: #233942;\n  color: #fff;\n  padding: 16px;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n}\n.header .search {\n  text-align: right;\n  float: right;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\n.abs {\n  position: relative;\n}\n.abs img {\n  width: 100%;\n}\n.abs ion-icon {\n  position: absolute;\n  left: 46%;\n  top: 40%;\n  font-size: 40px;\n  color: #fff;\n}\n.abs-content {\n  padding: 20px;\n}\n.abs-content h3 {\n  font-family: Rajdhani-Bold;\n  font-size: 24px;\n  margin: 0;\n}\n.abs-content h6 {\n  font-family: Rajdhani-SemiBold;\n  margin: 5px;\n  font-size: 18px;\n}\n.abs-content h6 span {\n  color: #f77e21;\n}\n.abs-content ion-icon {\n  font-size: 24px;\n  float: right;\n}\n.abs-content ul {\n  padding-left: 16px;\n}\n.abs-content ul li {\n  font-family: Rajdhani-Regular;\n  line-height: 28px;\n  margin-bottom: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL2Ficy9hYnMucGFnZS5zY3NzIiwic3JjL2FwcC9hYnMvYWJzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtBQ0NKO0FEQ0k7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtBQ0NKO0FERUk7RUFDSSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FDQVI7QURFSTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtBQ0FSO0FERUk7RUFDSSxZQUFBO0VBQ0EsY0FBQTtFQUNKLDBCQUFBO0VBQ0EsV0FBQTtBQ0FKO0FER0E7RUFDSSxrQkFBQTtBQ0FKO0FEQ0k7RUFDSSxXQUFBO0FDQ1I7QURDSTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtBQ0NSO0FERUE7RUFDSSxhQUFBO0FDQ0o7QURBSTtFQUNBLDBCQUFBO0VBQ0EsZUFBQTtFQUNBLFNBQUE7QUNFSjtBREFJO0VBQ0EsOEJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQ0VKO0FEREk7RUFDSSxjQUFBO0FDR1I7QURBSTtFQUNFLGVBQUE7RUFDQSxZQUFBO0FDRU47QURBSTtFQUNJLGtCQUFBO0FDRVI7QUREUTtFQUNKLDZCQUFBO0VBQ0YsaUJBQUE7RUFDQSxtQkFBQTtBQ0dGIiwiZmlsZSI6InNyYy9hcHAvYWJzL2Ficy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVye1xuICAgIC0tYmFja2dyb3VuZDojMjMzOTQyO1xuICAgIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gICAgY29sb3I6I2ZmZjtcbiAgICBwYWRkaW5nOiAgMTZweDtcblxuICAgIGlvbi10aXRsZXtcbiAgICBwYWRkaW5nOiAwcHg7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgICBcbiAgICB9IFxuICAgIGlvbi1pY29ue1xuICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgICAgICBjb2xvcjojZmZmO1xuICAgICAgICBmb250LXNpemU6MjBweDtcbiAgICB9XG4gICAgLnNlYXJjaHtcbiAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gICAgICAgIGZsb2F0OiByaWdodDtcbiAgICB9XG4gICAgcHtcbiAgICAgICAgZmxvYXQ6cmlnaHQ7XG4gICAgICAgIGNvbG9yOiNmNzdlMjE7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgbWFyZ2luOiAwZW07XG4gICAgfVxufVxuLmFic3tcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgaW1ne1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICB9XG4gICAgaW9uLWljb257XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgbGVmdDogNDYlO1xuICAgICAgICB0b3A6IDQwJTtcbiAgICAgICAgZm9udC1zaXplOiA0MHB4O1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICB9XG59XG4uYWJzLWNvbnRlbnR7XG4gICAgcGFkZGluZzoyMHB4O1xuICAgIGgze1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgIGZvbnQtc2l6ZToyNHB4O1xuICAgIG1hcmdpbjowO1xuICAgIH1cbiAgICBoNntcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktU2VtaUJvbGQ7XG4gICAgbWFyZ2luOjVweDtcbiAgICBmb250LXNpemU6MThweDtcbiAgICBzcGFue1xuICAgICAgICBjb2xvcjojZjc3ZTIxO1xuICAgIH1cbiAgICB9XG4gICAgaW9uLWljb257XG4gICAgICBmb250LXNpemU6MjRweDtcbiAgICAgIGZsb2F0OnJpZ2h0O1xuICAgIH1cbiAgICB1bHtcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICAgICAgICBsaXtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgbGluZS1oZWlnaHQ6MjhweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgICAgfVxuICAgIH1cbn0iLCIuaGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiMyMzM5NDI7XG4gIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIGNvbG9yOiAjZmZmO1xuICBwYWRkaW5nOiAxNnB4O1xufVxuLmhlYWRlciBpb24tdGl0bGUge1xuICBwYWRkaW5nOiAwcHg7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xufVxuLmhlYWRlciBpb24taWNvbiB7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG59XG4uaGVhZGVyIC5zZWFyY2gge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuLmhlYWRlciBwIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBjb2xvcjogI2Y3N2UyMTtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gIG1hcmdpbjogMGVtO1xufVxuXG4uYWJzIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLmFicyBpbWcge1xuICB3aWR0aDogMTAwJTtcbn1cbi5hYnMgaW9uLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDQ2JTtcbiAgdG9wOiA0MCU7XG4gIGZvbnQtc2l6ZTogNDBweDtcbiAgY29sb3I6ICNmZmY7XG59XG5cbi5hYnMtY29udGVudCB7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG4uYWJzLWNvbnRlbnQgaDMge1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgZm9udC1zaXplOiAyNHB4O1xuICBtYXJnaW46IDA7XG59XG4uYWJzLWNvbnRlbnQgaDYge1xuICBmb250LWZhbWlseTogUmFqZGhhbmktU2VtaUJvbGQ7XG4gIG1hcmdpbjogNXB4O1xuICBmb250LXNpemU6IDE4cHg7XG59XG4uYWJzLWNvbnRlbnQgaDYgc3BhbiB7XG4gIGNvbG9yOiAjZjc3ZTIxO1xufVxuLmFicy1jb250ZW50IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNHB4O1xuICBmbG9hdDogcmlnaHQ7XG59XG4uYWJzLWNvbnRlbnQgdWwge1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG59XG4uYWJzLWNvbnRlbnQgdWwgbGkge1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgbGluZS1oZWlnaHQ6IDI4cHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/abs/abs.page.ts":
/*!*********************************!*\
  !*** ./src/app/abs/abs.page.ts ***!
  \*********************************/
/*! exports provided: AbsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AbsPage", function() { return AbsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let AbsPage = class AbsPage {
    constructor() { }
    ngOnInit() {
    }
};
AbsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-abs',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./abs.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/abs/abs.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./abs.page.scss */ "./src/app/abs/abs.page.scss")).default]
    })
], AbsPage);



/***/ })

}]);
//# sourceMappingURL=abs-abs-module-es2015.js.map