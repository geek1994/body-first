function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-profile-edit-profile-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/edit-profile/edit-profile.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/edit-profile/edit-profile.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppEditProfileEditProfilePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <div class=\"header\">\n    <ion-row class=\"align-center\">\n      <ion-col size=\"1\">\n        <ion-back-button color=\"light\" text=\"\" icon=\"chevron-back-outline\" defaultHref=\"/profile\"></ion-back-button>\n      </ion-col>\n      <ion-col size=\"9\">\n        <ion-title>EDIT PROFILE</ion-title>\n      </ion-col>\n      <ion-col size=\"2\" text-right (click)=\"update()\">\n        <p>SAVE</p>\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"profileForm\">\n  <div class=\"section\">\n    <div class=\"profile\">\n      <div class=\"profile-img\">\n        <img src=\"assets/images/profile_pic.jpg\"  *ngIf=\"profile_picture== null || profile_picture == '' \"/>\n        <img src=\"{{profile_picture}}\" *ngIf=\"profile_picture!= null && profile_picture != '' \"/>\n        <ion-icon name=\"create-outline\" (click)=\"selectImage()\"></ion-icon>\n      </div>\n      <div class=\"edit-profile\">\n        <ion-item>\n          <ion-label>Name</ion-label>\n          <ion-input placeholder=\"First Name\" formControlName=\"name\" type=\"text\"></ion-input>\n        </ion-item>\n        <p class=\"error\">\n          <span *ngIf=\"profileForm.get('name').hasError('required') && profileForm.get('name').touched\">Please\n             enter name.</span>\n       </p>\n        <!-- <ion-item>\n          <ion-label>Last Name</ion-label>\n          <ion-input placeholder=\"Last Name\"></ion-input>\n        </ion-item> -->\n        <ion-item>\n          <ion-label>Gender</ion-label>\n          <ion-select placeholder=\"Gender\" formControlName=\"gender\">\n            <ion-select-option value=\"female\">Female</ion-select-option>\n            <ion-select-option value=\"male\">Male</ion-select-option>\n          </ion-select>\n        </ion-item>\n        <p class=\"error\">\n          <span *ngIf=\"profileForm.get('gender').hasError('required') && profileForm.get('gender').touched\">Please\n            select gender.</span>\n       </p>\n        <ion-item>\n          <ion-label>Age</ion-label>\n          <ion-input placeholder=\"Age\" formControlName=\"age\" type=\"number\" (keyup)=\"validateAge()\"></ion-input>\n          <!-- <ion-label>Date of Birth</ion-label>\n          <ion-datetime displayFormat=\"MM DD YY\" placeholder=\"Date of Birth\"></ion-datetime> -->\n        </ion-item>\n        <p class=\"error\">\n          <span *ngIf=\"profileForm.get('age').hasError('required') && profileForm.get('age').touched\">Please\n             enter age.</span>\n             <span *ngIf=\"!ageError.value\">{{ageError.message}}</span>\n         </p>\n        <ion-item>\n          <ion-label>Height</ion-label>\n          <ion-input placeholder=\"inches\" formControlName=\"height\" type=\"number\"></ion-input>\n        </ion-item>\n        <p class=\"error\">\n          <span *ngIf=\"profileForm.get('height').hasError('required') && profileForm.get('height').touched\">Please\n             enter height.</span>\n       </p>\n        <ion-item>\n          <ion-label>Weight</ion-label>\n          <ion-input placeholder=\"pounds\" formControlName=\"weight\" type=\"number\"></ion-input>\n        </ion-item>\n        <p class=\"error\">\n          <span *ngIf=\"profileForm.get('weight').hasError('required') && profileForm.get('weight').touched\">Please\n             enter weight.</span>\n       </p>\n      </div>\n    </div>\n    <div class=\"measurements\">\n      <h4>FIRST MEASUREMENTS</h4>\n      <ion-row>\n        <ion-col size=\"5\" text-center class=\"border-right\">\n          <img src=\"assets/images/dummy.png\" />\n        </ion-col>\n        <ion-col size=\"7\" class=\"padding-left\">           \n          <ion-row>\n            <ion-col size=\"12\">\n              <h5>FRONT</h5>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"5\">\n              <p text-left>Neck</p>\n            </ion-col>\n            <ion-col size=\"3\" class=\"ion-text-center\">\n              <p class=\"icon-m\">-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p text-right>42</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"5\">\n              <p>Shoulders</p>\n            </ion-col>\n            <ion-col size=\"3\" class=\"ion-text-center\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>17.5</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"5\">\n              <p>Arms</p>\n            </ion-col>\n            <ion-col size=\"3\" class=\"ion-text-center\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>15</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"5\">\n              <p>Chest (Male)</p>\n            </ion-col>\n            <ion-col size=\"3\" class=\"ion-text-center\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>36</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"5\">\n              <p>Waist</p>\n            </ion-col>\n            <ion-col size=\"3\" class=\"ion-text-center\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>36</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"5\">\n              <p>Hips</p>\n            </ion-col>\n            <ion-col size=\"3\" class=\"ion-text-center\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>22</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"5\">\n              <p>Thigh</p>\n            </ion-col>\n            <ion-col size=\"3\" class=\"ion-text-center\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>15</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"5\">\n              <p>Caif</p>\n            </ion-col>\n            <ion-col size=\"3\" class=\"ion-text-center\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>18</p>\n            </ion-col>\n          </ion-row>\n        </ion-col>\n      </ion-row>\n    </div>\n  </div>\n  </form>\n</ion-content>";
    /***/
  },

  /***/
  "./node_modules/util/node_modules/inherits/inherits_browser.js":
  /*!*********************************************************************!*\
    !*** ./node_modules/util/node_modules/inherits/inherits_browser.js ***!
    \*********************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesUtilNode_modulesInheritsInherits_browserJs(module, exports) {
    if (typeof Object.create === 'function') {
      // implementation from standard node.js 'util' module
      module.exports = function inherits(ctor, superCtor) {
        ctor.super_ = superCtor;
        ctor.prototype = Object.create(superCtor.prototype, {
          constructor: {
            value: ctor,
            enumerable: false,
            writable: true,
            configurable: true
          }
        });
      };
    } else {
      // old school shim for old browsers
      module.exports = function inherits(ctor, superCtor) {
        ctor.super_ = superCtor;

        var TempCtor = function TempCtor() {};

        TempCtor.prototype = superCtor.prototype;
        ctor.prototype = new TempCtor();
        ctor.prototype.constructor = ctor;
      };
    }
    /***/

  },

  /***/
  "./node_modules/util/support/isBufferBrowser.js":
  /*!******************************************************!*\
    !*** ./node_modules/util/support/isBufferBrowser.js ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function node_modulesUtilSupportIsBufferBrowserJs(module, exports) {
    module.exports = function isBuffer(arg) {
      return arg && typeof arg === 'object' && typeof arg.copy === 'function' && typeof arg.fill === 'function' && typeof arg.readUInt8 === 'function';
    };
    /***/

  },

  /***/
  "./node_modules/util/util.js":
  /*!***********************************!*\
    !*** ./node_modules/util/util.js ***!
    \***********************************/

  /*! no static exports found */

  /***/
  function node_modulesUtilUtilJs(module, exports, __webpack_require__) {
    // Copyright Joyent, Inc. and other Node contributors.
    //
    // Permission is hereby granted, free of charge, to any person obtaining a
    // copy of this software and associated documentation files (the
    // "Software"), to deal in the Software without restriction, including
    // without limitation the rights to use, copy, modify, merge, publish,
    // distribute, sublicense, and/or sell copies of the Software, and to permit
    // persons to whom the Software is furnished to do so, subject to the
    // following conditions:
    //
    // The above copyright notice and this permission notice shall be included
    // in all copies or substantial portions of the Software.
    //
    // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
    // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
    // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
    // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
    // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
    // USE OR OTHER DEALINGS IN THE SOFTWARE.
    var getOwnPropertyDescriptors = Object.getOwnPropertyDescriptors || function getOwnPropertyDescriptors(obj) {
      var keys = Object.keys(obj);
      var descriptors = {};

      for (var i = 0; i < keys.length; i++) {
        descriptors[keys[i]] = Object.getOwnPropertyDescriptor(obj, keys[i]);
      }

      return descriptors;
    };

    var formatRegExp = /%[sdj%]/g;

    exports.format = function (f) {
      if (!isString(f)) {
        var objects = [];

        for (var i = 0; i < arguments.length; i++) {
          objects.push(inspect(arguments[i]));
        }

        return objects.join(' ');
      }

      var i = 1;
      var args = arguments;
      var len = args.length;
      var str = String(f).replace(formatRegExp, function (x) {
        if (x === '%%') return '%';
        if (i >= len) return x;

        switch (x) {
          case '%s':
            return String(args[i++]);

          case '%d':
            return Number(args[i++]);

          case '%j':
            try {
              return JSON.stringify(args[i++]);
            } catch (_) {
              return '[Circular]';
            }

          default:
            return x;
        }
      });

      for (var x = args[i]; i < len; x = args[++i]) {
        if (isNull(x) || !isObject(x)) {
          str += ' ' + x;
        } else {
          str += ' ' + inspect(x);
        }
      }

      return str;
    }; // Mark that a method should not be used.
    // Returns a modified function which warns once by default.
    // If --no-deprecation is set, then it is a no-op.


    exports.deprecate = function (fn, msg) {
      if (typeof process !== 'undefined' && process.noDeprecation === true) {
        return fn;
      } // Allow for deprecating things in the process of starting up.


      if (typeof process === 'undefined') {
        return function () {
          return exports.deprecate(fn, msg).apply(this, arguments);
        };
      }

      var warned = false;

      function deprecated() {
        if (!warned) {
          if (process.throwDeprecation) {
            throw new Error(msg);
          } else if (process.traceDeprecation) {
            console.trace(msg);
          } else {
            console.error(msg);
          }

          warned = true;
        }

        return fn.apply(this, arguments);
      }

      return deprecated;
    };

    var debugs = {};
    var debugEnviron;

    exports.debuglog = function (set) {
      if (isUndefined(debugEnviron)) debugEnviron = process.env.NODE_DEBUG || '';
      set = set.toUpperCase();

      if (!debugs[set]) {
        if (new RegExp('\\b' + set + '\\b', 'i').test(debugEnviron)) {
          var pid = process.pid;

          debugs[set] = function () {
            var msg = exports.format.apply(exports, arguments);
            console.error('%s %d: %s', set, pid, msg);
          };
        } else {
          debugs[set] = function () {};
        }
      }

      return debugs[set];
    };
    /**
     * Echos the value of a value. Trys to print the value out
     * in the best way possible given the different types.
     *
     * @param {Object} obj The object to print out.
     * @param {Object} opts Optional options object that alters the output.
     */

    /* legacy: obj, showHidden, depth, colors*/


    function inspect(obj, opts) {
      // default options
      var ctx = {
        seen: [],
        stylize: stylizeNoColor
      }; // legacy...

      if (arguments.length >= 3) ctx.depth = arguments[2];
      if (arguments.length >= 4) ctx.colors = arguments[3];

      if (isBoolean(opts)) {
        // legacy...
        ctx.showHidden = opts;
      } else if (opts) {
        // got an "options" object
        exports._extend(ctx, opts);
      } // set default options


      if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
      if (isUndefined(ctx.depth)) ctx.depth = 2;
      if (isUndefined(ctx.colors)) ctx.colors = false;
      if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
      if (ctx.colors) ctx.stylize = stylizeWithColor;
      return formatValue(ctx, obj, ctx.depth);
    }

    exports.inspect = inspect; // http://en.wikipedia.org/wiki/ANSI_escape_code#graphics

    inspect.colors = {
      'bold': [1, 22],
      'italic': [3, 23],
      'underline': [4, 24],
      'inverse': [7, 27],
      'white': [37, 39],
      'grey': [90, 39],
      'black': [30, 39],
      'blue': [34, 39],
      'cyan': [36, 39],
      'green': [32, 39],
      'magenta': [35, 39],
      'red': [31, 39],
      'yellow': [33, 39]
    }; // Don't use 'blue' not visible on cmd.exe

    inspect.styles = {
      'special': 'cyan',
      'number': 'yellow',
      'boolean': 'yellow',
      'undefined': 'grey',
      'null': 'bold',
      'string': 'green',
      'date': 'magenta',
      // "name": intentionally not styling
      'regexp': 'red'
    };

    function stylizeWithColor(str, styleType) {
      var style = inspect.styles[styleType];

      if (style) {
        return "\x1B[" + inspect.colors[style][0] + 'm' + str + "\x1B[" + inspect.colors[style][1] + 'm';
      } else {
        return str;
      }
    }

    function stylizeNoColor(str, styleType) {
      return str;
    }

    function arrayToHash(array) {
      var hash = {};
      array.forEach(function (val, idx) {
        hash[val] = true;
      });
      return hash;
    }

    function formatValue(ctx, value, recurseTimes) {
      // Provide a hook for user-specified inspect functions.
      // Check that value is an object with an inspect function on it
      if (ctx.customInspect && value && isFunction(value.inspect) && // Filter out the util module, it's inspect function is special
      value.inspect !== exports.inspect && // Also filter out any prototype objects using the circular check.
      !(value.constructor && value.constructor.prototype === value)) {
        var ret = value.inspect(recurseTimes, ctx);

        if (!isString(ret)) {
          ret = formatValue(ctx, ret, recurseTimes);
        }

        return ret;
      } // Primitive types cannot have properties


      var primitive = formatPrimitive(ctx, value);

      if (primitive) {
        return primitive;
      } // Look up the keys of the object.


      var keys = Object.keys(value);
      var visibleKeys = arrayToHash(keys);

      if (ctx.showHidden) {
        keys = Object.getOwnPropertyNames(value);
      } // IE doesn't make error fields non-enumerable
      // http://msdn.microsoft.com/en-us/library/ie/dww52sbt(v=vs.94).aspx


      if (isError(value) && (keys.indexOf('message') >= 0 || keys.indexOf('description') >= 0)) {
        return formatError(value);
      } // Some type of object without properties can be shortcutted.


      if (keys.length === 0) {
        if (isFunction(value)) {
          var name = value.name ? ': ' + value.name : '';
          return ctx.stylize('[Function' + name + ']', 'special');
        }

        if (isRegExp(value)) {
          return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
        }

        if (isDate(value)) {
          return ctx.stylize(Date.prototype.toString.call(value), 'date');
        }

        if (isError(value)) {
          return formatError(value);
        }
      }

      var base = '',
          array = false,
          braces = ['{', '}']; // Make Array say that they are Array

      if (isArray(value)) {
        array = true;
        braces = ['[', ']'];
      } // Make functions say that they are functions


      if (isFunction(value)) {
        var n = value.name ? ': ' + value.name : '';
        base = ' [Function' + n + ']';
      } // Make RegExps say that they are RegExps


      if (isRegExp(value)) {
        base = ' ' + RegExp.prototype.toString.call(value);
      } // Make dates with properties first say the date


      if (isDate(value)) {
        base = ' ' + Date.prototype.toUTCString.call(value);
      } // Make error with message first say the error


      if (isError(value)) {
        base = ' ' + formatError(value);
      }

      if (keys.length === 0 && (!array || value.length == 0)) {
        return braces[0] + base + braces[1];
      }

      if (recurseTimes < 0) {
        if (isRegExp(value)) {
          return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
        } else {
          return ctx.stylize('[Object]', 'special');
        }
      }

      ctx.seen.push(value);
      var output;

      if (array) {
        output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
      } else {
        output = keys.map(function (key) {
          return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
        });
      }

      ctx.seen.pop();
      return reduceToSingleString(output, base, braces);
    }

    function formatPrimitive(ctx, value) {
      if (isUndefined(value)) return ctx.stylize('undefined', 'undefined');

      if (isString(value)) {
        var simple = '\'' + JSON.stringify(value).replace(/^"|"$/g, '').replace(/'/g, "\\'").replace(/\\"/g, '"') + '\'';
        return ctx.stylize(simple, 'string');
      }

      if (isNumber(value)) return ctx.stylize('' + value, 'number');
      if (isBoolean(value)) return ctx.stylize('' + value, 'boolean'); // For some reason typeof null is "object", so special case here.

      if (isNull(value)) return ctx.stylize('null', 'null');
    }

    function formatError(value) {
      return '[' + Error.prototype.toString.call(value) + ']';
    }

    function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
      var output = [];

      for (var i = 0, l = value.length; i < l; ++i) {
        if (hasOwnProperty(value, String(i))) {
          output.push(formatProperty(ctx, value, recurseTimes, visibleKeys, String(i), true));
        } else {
          output.push('');
        }
      }

      keys.forEach(function (key) {
        if (!key.match(/^\d+$/)) {
          output.push(formatProperty(ctx, value, recurseTimes, visibleKeys, key, true));
        }
      });
      return output;
    }

    function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
      var name, str, desc;
      desc = Object.getOwnPropertyDescriptor(value, key) || {
        value: value[key]
      };

      if (desc.get) {
        if (desc.set) {
          str = ctx.stylize('[Getter/Setter]', 'special');
        } else {
          str = ctx.stylize('[Getter]', 'special');
        }
      } else {
        if (desc.set) {
          str = ctx.stylize('[Setter]', 'special');
        }
      }

      if (!hasOwnProperty(visibleKeys, key)) {
        name = '[' + key + ']';
      }

      if (!str) {
        if (ctx.seen.indexOf(desc.value) < 0) {
          if (isNull(recurseTimes)) {
            str = formatValue(ctx, desc.value, null);
          } else {
            str = formatValue(ctx, desc.value, recurseTimes - 1);
          }

          if (str.indexOf('\n') > -1) {
            if (array) {
              str = str.split('\n').map(function (line) {
                return '  ' + line;
              }).join('\n').substr(2);
            } else {
              str = '\n' + str.split('\n').map(function (line) {
                return '   ' + line;
              }).join('\n');
            }
          }
        } else {
          str = ctx.stylize('[Circular]', 'special');
        }
      }

      if (isUndefined(name)) {
        if (array && key.match(/^\d+$/)) {
          return str;
        }

        name = JSON.stringify('' + key);

        if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
          name = name.substr(1, name.length - 2);
          name = ctx.stylize(name, 'name');
        } else {
          name = name.replace(/'/g, "\\'").replace(/\\"/g, '"').replace(/(^"|"$)/g, "'");
          name = ctx.stylize(name, 'string');
        }
      }

      return name + ': ' + str;
    }

    function reduceToSingleString(output, base, braces) {
      var numLinesEst = 0;
      var length = output.reduce(function (prev, cur) {
        numLinesEst++;
        if (cur.indexOf('\n') >= 0) numLinesEst++;
        return prev + cur.replace(/\u001b\[\d\d?m/g, '').length + 1;
      }, 0);

      if (length > 60) {
        return braces[0] + (base === '' ? '' : base + '\n ') + ' ' + output.join(',\n  ') + ' ' + braces[1];
      }

      return braces[0] + base + ' ' + output.join(', ') + ' ' + braces[1];
    } // NOTE: These type checking functions intentionally don't use `instanceof`
    // because it is fragile and can be easily faked with `Object.create()`.


    function isArray(ar) {
      return Array.isArray(ar);
    }

    exports.isArray = isArray;

    function isBoolean(arg) {
      return typeof arg === 'boolean';
    }

    exports.isBoolean = isBoolean;

    function isNull(arg) {
      return arg === null;
    }

    exports.isNull = isNull;

    function isNullOrUndefined(arg) {
      return arg == null;
    }

    exports.isNullOrUndefined = isNullOrUndefined;

    function isNumber(arg) {
      return typeof arg === 'number';
    }

    exports.isNumber = isNumber;

    function isString(arg) {
      return typeof arg === 'string';
    }

    exports.isString = isString;

    function isSymbol(arg) {
      return typeof arg === 'symbol';
    }

    exports.isSymbol = isSymbol;

    function isUndefined(arg) {
      return arg === void 0;
    }

    exports.isUndefined = isUndefined;

    function isRegExp(re) {
      return isObject(re) && objectToString(re) === '[object RegExp]';
    }

    exports.isRegExp = isRegExp;

    function isObject(arg) {
      return typeof arg === 'object' && arg !== null;
    }

    exports.isObject = isObject;

    function isDate(d) {
      return isObject(d) && objectToString(d) === '[object Date]';
    }

    exports.isDate = isDate;

    function isError(e) {
      return isObject(e) && (objectToString(e) === '[object Error]' || e instanceof Error);
    }

    exports.isError = isError;

    function isFunction(arg) {
      return typeof arg === 'function';
    }

    exports.isFunction = isFunction;

    function isPrimitive(arg) {
      return arg === null || typeof arg === 'boolean' || typeof arg === 'number' || typeof arg === 'string' || typeof arg === 'symbol' || // ES6 symbol
      typeof arg === 'undefined';
    }

    exports.isPrimitive = isPrimitive;
    exports.isBuffer = __webpack_require__(
    /*! ./support/isBuffer */
    "./node_modules/util/support/isBufferBrowser.js");

    function objectToString(o) {
      return Object.prototype.toString.call(o);
    }

    function pad(n) {
      return n < 10 ? '0' + n.toString(10) : n.toString(10);
    }

    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']; // 26 Feb 16:19:34

    function timestamp() {
      var d = new Date();
      var time = [pad(d.getHours()), pad(d.getMinutes()), pad(d.getSeconds())].join(':');
      return [d.getDate(), months[d.getMonth()], time].join(' ');
    } // log is just a thin wrapper to console.log that prepends a timestamp


    exports.log = function () {
      console.log('%s - %s', timestamp(), exports.format.apply(exports, arguments));
    };
    /**
     * Inherit the prototype methods from one constructor into another.
     *
     * The Function.prototype.inherits from lang.js rewritten as a standalone
     * function (not on Function.prototype). NOTE: If this file is to be loaded
     * during bootstrapping this function needs to be rewritten using some native
     * functions as prototype setup using normal JavaScript does not work as
     * expected during bootstrapping (see mirror.js in r114903).
     *
     * @param {function} ctor Constructor function which needs to inherit the
     *     prototype.
     * @param {function} superCtor Constructor function to inherit prototype from.
     */


    exports.inherits = __webpack_require__(
    /*! inherits */
    "./node_modules/util/node_modules/inherits/inherits_browser.js");

    exports._extend = function (origin, add) {
      // Don't do anything if add isn't an object
      if (!add || !isObject(add)) return origin;
      var keys = Object.keys(add);
      var i = keys.length;

      while (i--) {
        origin[keys[i]] = add[keys[i]];
      }

      return origin;
    };

    function hasOwnProperty(obj, prop) {
      return Object.prototype.hasOwnProperty.call(obj, prop);
    }

    var kCustomPromisifiedSymbol = typeof Symbol !== 'undefined' ? Symbol('util.promisify.custom') : undefined;

    exports.promisify = function promisify(original) {
      if (typeof original !== 'function') throw new TypeError('The "original" argument must be of type Function');

      if (kCustomPromisifiedSymbol && original[kCustomPromisifiedSymbol]) {
        var fn = original[kCustomPromisifiedSymbol];

        if (typeof fn !== 'function') {
          throw new TypeError('The "util.promisify.custom" argument must be of type Function');
        }

        Object.defineProperty(fn, kCustomPromisifiedSymbol, {
          value: fn,
          enumerable: false,
          writable: false,
          configurable: true
        });
        return fn;
      }

      function fn() {
        var promiseResolve, promiseReject;
        var promise = new Promise(function (resolve, reject) {
          promiseResolve = resolve;
          promiseReject = reject;
        });
        var args = [];

        for (var i = 0; i < arguments.length; i++) {
          args.push(arguments[i]);
        }

        args.push(function (err, value) {
          if (err) {
            promiseReject(err);
          } else {
            promiseResolve(value);
          }
        });

        try {
          original.apply(this, args);
        } catch (err) {
          promiseReject(err);
        }

        return promise;
      }

      Object.setPrototypeOf(fn, Object.getPrototypeOf(original));
      if (kCustomPromisifiedSymbol) Object.defineProperty(fn, kCustomPromisifiedSymbol, {
        value: fn,
        enumerable: false,
        writable: false,
        configurable: true
      });
      return Object.defineProperties(fn, getOwnPropertyDescriptors(original));
    };

    exports.promisify.custom = kCustomPromisifiedSymbol;

    function callbackifyOnRejected(reason, cb) {
      // `!reason` guard inspired by bluebird (Ref: https://goo.gl/t5IS6M).
      // Because `null` is a special error value in callbacks which means "no error
      // occurred", we error-wrap so the callback consumer can distinguish between
      // "the promise rejected with null" or "the promise fulfilled with undefined".
      if (!reason) {
        var newReason = new Error('Promise was rejected with a falsy value');
        newReason.reason = reason;
        reason = newReason;
      }

      return cb(reason);
    }

    function callbackify(original) {
      if (typeof original !== 'function') {
        throw new TypeError('The "original" argument must be of type Function');
      } // We DO NOT return the promise as it gives the user a false sense that
      // the promise is actually somehow related to the callback's execution
      // and that the callback throwing will reject the promise.


      function callbackified() {
        var args = [];

        for (var i = 0; i < arguments.length; i++) {
          args.push(arguments[i]);
        }

        var maybeCb = args.pop();

        if (typeof maybeCb !== 'function') {
          throw new TypeError('The last argument must be of type Function');
        }

        var self = this;

        var cb = function cb() {
          return maybeCb.apply(self, arguments);
        }; // In true node style we process the callback on `nextTick` with all the
        // implications (stack, `uncaughtException`, `async_hooks`)


        original.apply(this, args).then(function (ret) {
          process.nextTick(cb, null, ret);
        }, function (rej) {
          process.nextTick(callbackifyOnRejected, rej, cb);
        });
      }

      Object.setPrototypeOf(callbackified, Object.getPrototypeOf(original));
      Object.defineProperties(callbackified, getOwnPropertyDescriptors(original));
      return callbackified;
    }

    exports.callbackify = callbackify;
    /***/
  },

  /***/
  "./src/app/edit-profile/edit-profile-routing.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/edit-profile/edit-profile-routing.module.ts ***!
    \*************************************************************/

  /*! exports provided: EditProfilePageRoutingModule */

  /***/
  function srcAppEditProfileEditProfileRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditProfilePageRoutingModule", function () {
      return EditProfilePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _edit_profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./edit-profile.page */
    "./src/app/edit-profile/edit-profile.page.ts");

    var routes = [{
      path: '',
      component: _edit_profile_page__WEBPACK_IMPORTED_MODULE_3__["EditProfilePage"]
    }];

    var EditProfilePageRoutingModule = function EditProfilePageRoutingModule() {
      _classCallCheck(this, EditProfilePageRoutingModule);
    };

    EditProfilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], EditProfilePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/edit-profile/edit-profile.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/edit-profile/edit-profile.module.ts ***!
    \*****************************************************/

  /*! exports provided: EditProfilePageModule */

  /***/
  function srcAppEditProfileEditProfileModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditProfilePageModule", function () {
      return EditProfilePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _edit_profile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./edit-profile-routing.module */
    "./src/app/edit-profile/edit-profile-routing.module.ts");
    /* harmony import */


    var _edit_profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./edit-profile.page */
    "./src/app/edit-profile/edit-profile.page.ts");

    var EditProfilePageModule = function EditProfilePageModule() {
      _classCallCheck(this, EditProfilePageModule);
    };

    EditProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _edit_profile_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditProfilePageRoutingModule"]],
      declarations: [_edit_profile_page__WEBPACK_IMPORTED_MODULE_6__["EditProfilePage"]]
    })], EditProfilePageModule);
    /***/
  },

  /***/
  "./src/app/edit-profile/edit-profile.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/edit-profile/edit-profile.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppEditProfileEditProfilePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n}\n.header .align-center {\n  align-items: center;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  margin-left: 35px;\n}\n.header ion-back-button {\n  display: inline-block;\n  font-size: 14px;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n  margin-right: 10px;\n}\n.profile {\n  padding: 20px 20px 20px 10px;\n  background: #fff;\n}\n.profile .profile-img {\n  padding: 20px;\n  text-align: center;\n  margin: 0 auto;\n  position: relative;\n}\n.profile .profile-img img {\n  position: relative;\n  border-radius: 50%;\n  width: 100px;\n  height: 100px;\n}\n.profile .profile-img ion-icon {\n  position: absolute;\n  right: 38%;\n  color: #ffff;\n  background: #f77e21;\n  top: 10%;\n  border-radius: 100px;\n  padding: 5px;\n}\n.profile .edit-profile ion-input,\n.profile .edit-profile ion-select,\n.profile .edit-profile ion-datetime {\n  text-align: right;\n  line-height: 30px;\n  margin-bottom: 10px;\n  font-family: Rajdhani-Regular;\n}\n.profile .edit-profile ion-label {\n  font-family: Rajdhani-Regular;\n  font-weight: bold;\n}\n.section {\n  background: #f9f9f9;\n}\n.measurements {\n  padding: 20px;\n  background: #fff;\n  margin-top: 20px;\n}\n.measurements ion-col {\n  padding: 0;\n}\n.measurements ion-col.border-right {\n  border-right: 1px solid #828282;\n  padding-right: 4px;\n  margin-top: 10px;\n}\n.measurements ion-col.border-right h5 {\n  margin-top: 0;\n}\n.measurements .padding-left {\n  padding-left: 10px;\n}\n.measurements h4 {\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n}\n.measurements img {\n  text-align: center;\n  padding: 78px 28px 25px 30px;\n  margin: 0 auto;\n}\n.measurements h5 {\n  text-align: center;\n  font-family: Rajdhani-Bold;\n}\n.measurements p {\n  font-size: 18px;\n  font-family: Rajdhani-Regular;\n  margin: 3px;\n  white-space: nowrap;\n}\np.error {\n  color: red;\n  margin-left: 16px !important;\n  font-weight: 100 !important;\n  /* font-size: 16px; */\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL2VkaXQtcHJvZmlsZS9lZGl0LXByb2ZpbGUucGFnZS5zY3NzIiwic3JjL2FwcC9lZGl0LXByb2ZpbGUvZWRpdC1wcm9maWxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FDQ0Y7QURFRTtFQUNFLG1CQUFBO0FDQUo7QURHRTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtFQUNBLDZCQUFBO0VBQ0EsaUJBQUE7QUNESjtBRElFO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0FDRko7QURLRTtFQUNFLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUNISjtBRE1FO0VBQ0UsWUFBQTtFQUNBLGNBQUE7RUFDQSwwQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQ0pKO0FEUUE7RUFDRSw0QkFBQTtFQUNBLGdCQUFBO0FDTEY7QURPRTtFQUNFLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0xKO0FET0k7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNMTjtBRFFJO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsUUFBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtBQ05OO0FEWUk7OztFQUdFLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLDZCQUFBO0FDVk47QURhSTtFQUNFLDZCQUFBO0VBQ0EsaUJBQUE7QUNYTjtBRGdCQTtFQUNFLG1CQUFBO0FDYkY7QURnQkE7RUFDRSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ2JGO0FEZUU7RUFDRSxVQUFBO0FDYko7QURnQkU7RUFDRSwrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNkSjtBRGdCSTtFQUNFLGFBQUE7QUNkTjtBRGtCRTtFQUNFLGtCQUFBO0FDaEJKO0FEbUJFO0VBQ0UsY0FBQTtFQUNBLDBCQUFBO0FDakJKO0FEb0JFO0VBQ0Usa0JBQUE7RUFDQSw0QkFBQTtFQUNBLGNBQUE7QUNsQko7QURxQkU7RUFDRSxrQkFBQTtFQUNBLDBCQUFBO0FDbkJKO0FEc0JFO0VBQ0UsZUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0FDcEJKO0FEdUJBO0VBQ0UsVUFBQTtFQUNBLDRCQUFBO0VBQ0EsMkJBQUE7RUFDQSxxQkFBQTtBQ3BCRiIsImZpbGUiOiJzcmMvYXBwL2VkaXQtcHJvZmlsZS9lZGl0LXByb2ZpbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG5cbiAgLy8gcGFkZGluZzogMTZweDtcbiAgLmFsaWduLWNlbnRlciB7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgfVxuXG4gIGlvbi10aXRsZSB7XG4gICAgcGFkZGluZzogMHB4O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgbWFyZ2luLWxlZnQ6IDM1cHg7XG4gIH1cblxuICBpb24tYmFjay1idXR0b24ge1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICBmb250LXNpemU6IDE0cHg7XG4gIH1cblxuICBpb24taWNvbiB7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gIH1cblxuICBwIHtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgY29sb3I6ICNmNzdlMjE7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgbWFyZ2luOiAwZW07XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICB9XG59XG5cbi5wcm9maWxlIHtcbiAgcGFkZGluZzogMjBweCAyMHB4IDIwcHggMTBweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcblxuICAucHJvZmlsZS1pbWcge1xuICAgIHBhZGRpbmc6IDIwcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbjogMCBhdXRvO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgIGltZyB7XG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICB3aWR0aDogMTAwcHg7XG4gICAgICBoZWlnaHQ6IDEwMHB4O1xuICAgIH1cblxuICAgIGlvbi1pY29uIHtcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIHJpZ2h0OiAzOCU7XG4gICAgICBjb2xvcjogI2ZmZmY7XG4gICAgICBiYWNrZ3JvdW5kOiAjZjc3ZTIxO1xuICAgICAgdG9wOiAxMCU7XG4gICAgICBib3JkZXItcmFkaXVzOiAxMDBweDtcbiAgICAgIHBhZGRpbmc6IDVweDtcbiAgICB9XG4gIH1cblxuICAuZWRpdC1wcm9maWxlIHtcblxuICAgIGlvbi1pbnB1dCxcbiAgICBpb24tc2VsZWN0LFxuICAgIGlvbi1kYXRldGltZSB7XG4gICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAzMHB4O1xuICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgIH1cblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIH1cbiAgfVxufVxuXG4uc2VjdGlvbiB7XG4gIGJhY2tncm91bmQ6ICNmOWY5Zjk7XG59XG5cbi5tZWFzdXJlbWVudHMge1xuICBwYWRkaW5nOiAyMHB4O1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBtYXJnaW4tdG9wOiAyMHB4O1xuXG4gIGlvbi1jb2wge1xuICAgIHBhZGRpbmc6IDA7XG4gIH1cblxuICBpb24tY29sLmJvcmRlci1yaWdodCB7XG4gICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgIzgyODI4MjtcbiAgICBwYWRkaW5nLXJpZ2h0OiA0cHg7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcblxuICAgIGg1IHtcbiAgICAgIG1hcmdpbi10b3A6IDA7XG4gICAgfVxuICB9XG5cbiAgLnBhZGRpbmctbGVmdCB7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICB9XG5cbiAgaDQge1xuICAgIGNvbG9yOiAjZjc3ZTIxO1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICB9XG5cbiAgaW1nIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcGFkZGluZzogNzhweCAyOHB4IDI1cHggMzBweDtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgfVxuXG4gIGg1IHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gIH1cblxuICBwIHtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgbWFyZ2luOiAzcHg7XG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgfVxufVxucC5lcnJvciB7XG4gIGNvbG9yOiByZWQ7XG4gIG1hcmdpbi1sZWZ0OiAxNnB4ICFpbXBvcnRhbnQ7XG4gIGZvbnQtd2VpZ2h0OiAxMDAgIWltcG9ydGFudDtcbiAgLyogZm9udC1zaXplOiAxNnB4OyAqL1xufSIsIi5oZWFkZXIge1xuICAtLWJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIGNvbG9yOiAjZmZmO1xufVxuLmhlYWRlciAuYWxpZ24tY2VudGVyIHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbi5oZWFkZXIgaW9uLXRpdGxlIHtcbiAgcGFkZGluZzogMHB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgbWFyZ2luLWxlZnQ6IDM1cHg7XG59XG4uaGVhZGVyIGlvbi1iYWNrLWJ1dHRvbiB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuLmhlYWRlciBpb24taWNvbiB7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG59XG4uaGVhZGVyIHAge1xuICBmbG9hdDogcmlnaHQ7XG4gIGNvbG9yOiAjZjc3ZTIxO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgbWFyZ2luOiAwZW07XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cblxuLnByb2ZpbGUge1xuICBwYWRkaW5nOiAyMHB4IDIwcHggMjBweCAxMHB4O1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuLnByb2ZpbGUgLnByb2ZpbGUtaW1nIHtcbiAgcGFkZGluZzogMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDAgYXV0bztcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLnByb2ZpbGUgLnByb2ZpbGUtaW1nIGltZyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICB3aWR0aDogMTAwcHg7XG4gIGhlaWdodDogMTAwcHg7XG59XG4ucHJvZmlsZSAucHJvZmlsZS1pbWcgaW9uLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAzOCU7XG4gIGNvbG9yOiAjZmZmZjtcbiAgYmFja2dyb3VuZDogI2Y3N2UyMTtcbiAgdG9wOiAxMCU7XG4gIGJvcmRlci1yYWRpdXM6IDEwMHB4O1xuICBwYWRkaW5nOiA1cHg7XG59XG4ucHJvZmlsZSAuZWRpdC1wcm9maWxlIGlvbi1pbnB1dCxcbi5wcm9maWxlIC5lZGl0LXByb2ZpbGUgaW9uLXNlbGVjdCxcbi5wcm9maWxlIC5lZGl0LXByb2ZpbGUgaW9uLWRhdGV0aW1lIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbn1cbi5wcm9maWxlIC5lZGl0LXByb2ZpbGUgaW9uLWxhYmVsIHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4uc2VjdGlvbiB7XG4gIGJhY2tncm91bmQ6ICNmOWY5Zjk7XG59XG5cbi5tZWFzdXJlbWVudHMge1xuICBwYWRkaW5nOiAyMHB4O1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuLm1lYXN1cmVtZW50cyBpb24tY29sIHtcbiAgcGFkZGluZzogMDtcbn1cbi5tZWFzdXJlbWVudHMgaW9uLWNvbC5ib3JkZXItcmlnaHQge1xuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjODI4MjgyO1xuICBwYWRkaW5nLXJpZ2h0OiA0cHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG4ubWVhc3VyZW1lbnRzIGlvbi1jb2wuYm9yZGVyLXJpZ2h0IGg1IHtcbiAgbWFyZ2luLXRvcDogMDtcbn1cbi5tZWFzdXJlbWVudHMgLnBhZGRpbmctbGVmdCB7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbn1cbi5tZWFzdXJlbWVudHMgaDQge1xuICBjb2xvcjogI2Y3N2UyMTtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG59XG4ubWVhc3VyZW1lbnRzIGltZyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogNzhweCAyOHB4IDI1cHggMzBweDtcbiAgbWFyZ2luOiAwIGF1dG87XG59XG4ubWVhc3VyZW1lbnRzIGg1IHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbn1cbi5tZWFzdXJlbWVudHMgcCB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIG1hcmdpbjogM3B4O1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xufVxuXG5wLmVycm9yIHtcbiAgY29sb3I6IHJlZDtcbiAgbWFyZ2luLWxlZnQ6IDE2cHggIWltcG9ydGFudDtcbiAgZm9udC13ZWlnaHQ6IDEwMCAhaW1wb3J0YW50O1xuICAvKiBmb250LXNpemU6IDE2cHg7ICovXG59Il19 */";
    /***/
  },

  /***/
  "./src/app/edit-profile/edit-profile.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/edit-profile/edit-profile.page.ts ***!
    \***************************************************/

  /*! exports provided: EditProfilePage */

  /***/
  function srcAppEditProfileEditProfilePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditProfilePage", function () {
      return EditProfilePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _service_component_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../service/component.service */
    "./src/app/service/component.service.ts");
    /* harmony import */


    var _service_events_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../service/events.service */
    "./src/app/service/events.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/camera/ngx */
    "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var util__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! util */
    "./node_modules/util/util.js");
    /* harmony import */


    var util__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_7__);

    var EditProfilePage = /*#__PURE__*/function () {
      function EditProfilePage(actionSheetController, formBuilder, events, componentService, navCtrl, camera) {
        var _this = this;

        _classCallCheck(this, EditProfilePage);

        this.actionSheetController = actionSheetController;
        this.formBuilder = formBuilder;
        this.events = events;
        this.componentService = componentService;
        this.navCtrl = navCtrl;
        this.camera = camera;
        this.profile_picture = '';
        this.imageUpload = '';
        this.ageError = {};
        this.userData = JSON.parse(localStorage.getItem('userData'));
        console.log(this.userData, "userdata");
        this.profile_picture = this.userData.picture;
        this.profileForm = this.formBuilder.group({
          email: [''],
          name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
          gender: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
          measuement: [''],
          age: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
          height: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
          weight: ['GBP', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])]
        });
        this.events.subscribe('user:created', function (data) {
          _this.userData = JSON.parse(localStorage.getItem('userData'));
        });
      }

      _createClass(EditProfilePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.profileForm.patchValue({
            name: this.userData.name,
            email: this.userData.email,
            gender: this.userData.gender,
            weight: this.userData.weight,
            height: this.userData.height,
            age: this.userData.age
          });
        }
      }, {
        key: "update",
        value: function update() {
          if (!this.profileForm.valid) {
            return false;
          } else {
            this.profileForm.patchValue({
              name: this.profileForm.value.name.trim()
            }); //  localStorage.setItem('userData', JSON.stringify(this.profileForm.value))

            localStorage.setItem('userData', JSON.stringify({
              'name': this.profileForm.value.name,
              'weight': this.profileForm.value.weight,
              'height': this.profileForm.value.height,
              'age': this.profileForm.value.age,
              'measuement': this.profileForm.value.measuement,
              'gender': this.profileForm.value.gender,
              'email': this.userData.email,
              'picture': this.userData.picture,
              'id': this.userData.id,
              'goal': this.userData.goal
            }));
            this.events.publish('user:created', {
              user: JSON.stringify(this.profileForm.value)
            });
            this.componentService.presentToast('success', 'User updated successfully!');
            this.navCtrl.navigateBack("/profile");
          }
        }
      }, {
        key: "selectImage",
        value: function selectImage() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this2 = this;

            var actionSheet;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.actionSheetController.create({
                      header: "Select Image source",
                      buttons: [{
                        text: 'Load from Library',
                        handler: function handler() {
                          _this2.openCamera(_this2.camera.PictureSourceType.PHOTOLIBRARY);
                        }
                      }, {
                        text: 'Use Camera',
                        handler: function handler() {
                          _this2.openCamera(_this2.camera.PictureSourceType.CAMERA);
                        }
                      }, {
                        text: 'Cancel',
                        role: 'cancel'
                      }]
                    });

                  case 2:
                    actionSheet = _context.sent;
                    _context.next = 5;
                    return actionSheet.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "openCamera",
        value: function openCamera(sourceType) {
          var _this3 = this;

          // this.picture = '';
          var options = {
            quality: 40,
            sourceType: sourceType,
            destinationType: this.camera.DestinationType.DATA_URL,
            // targetWidth: 300,
            // targetHeight: 300,
            mediaType: this.camera.MediaType.PICTURE,
            correctOrientation: true
          };
          this.camera.getPicture(options).then(function (imageData) {
            _this3.profile_picture = 'data:image/jpeg;base64,' + imageData;
            console.log(_this3.userData, _this3.imageUpload);
            localStorage.setItem('userData', JSON.stringify({
              'name': _this3.profileForm.value.name,
              'weight': _this3.profileForm.value.weight,
              'height': _this3.profileForm.value.height,
              'age': _this3.profileForm.value.age,
              'measuement': _this3.profileForm.value.measuement,
              'gender': _this3.profileForm.value.gender,
              'email': _this3.userData.email,
              'picture': _this3.profile_picture,
              'id': _this3.userData.id
            }));

            _this3.componentService.presentToast('success', 'Profile picture updated successfully');

            _this3.events.publish('user:created', {
              user: JSON.stringify(_this3.profileForm.value)
            });
          }, function (err) {
            // Handle error
            alert(JSON.stringify(err));
          });
        }
      }, {
        key: "validateAge",
        value: function validateAge() {
          this.ageError['value'] = true;
          console.log(this.profileForm.value.age);
          console.log(Object(util__WEBPACK_IMPORTED_MODULE_7__["isNumber"])(this.profileForm.value.age));

          if (Object(util__WEBPACK_IMPORTED_MODULE_7__["isNumber"])(this.profileForm.value.age) == false) {
            this.ageError['message'] = "Invalid Age.";
            this.ageError['value'] = false;
          } else if (this.profileForm.value.age < 18) {
            this.ageError['message'] = "too young";
            this.ageError['value'] = false;
          } else if (this.profileForm.value.age > 120) {
            this.ageError['message'] = "not realistic";
            this.ageError['value'] = false;
          } else {
            this.ageError['value'] = true;
          }
        }
      }]);

      return EditProfilePage;
    }();

    EditProfilePage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ActionSheetController"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _service_events_service__WEBPACK_IMPORTED_MODULE_4__["EventsService"]
      }, {
        type: _service_component_service__WEBPACK_IMPORTED_MODULE_3__["ComponentService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]
      }, {
        type: undefined,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"],
          args: [_ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__["Camera"]]
        }]
      }];
    };

    EditProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-edit-profile',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./edit-profile.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/edit-profile/edit-profile.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./edit-profile.page.scss */
      "./src/app/edit-profile/edit-profile.page.scss"))["default"]]
    }), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(5, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__["Camera"]))], EditProfilePage);
    /***/
  }
}]);
//# sourceMappingURL=edit-profile-edit-profile-module-es5.js.map