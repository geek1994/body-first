function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["spirit-spirit-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/spirit/spirit.page.html":
  /*!*******************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/spirit/spirit.page.html ***!
    \*******************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSpiritSpiritPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>SPIRIT</ion-title>\n    <ion-buttons slot=\"end\">\n      <!-- <ion-icon name=\"search-outline\" class=\"setting\" (click)=\"search()\"></ion-icon> -->\n    </ion-buttons>\n    <!--<ion-buttons slot=\"end\">\n      <ion-icon name=\"search-outline\" class=\"search\"></ion-icon>\n    </ion-buttons>-->\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"mindset\">\n    <div class=\"mindset-guid\" *ngIf=\"type=='guid'\">\n      <img src=\"assets/images/spirit-top-banner.jpg\" />\n      <div class=\"mindset-guid-head\">\n        <h4>SPIRIT PRINCIPLE</h4>\n      </div>\n      <div class=\"image-s\">\n        <img src=\"assets/images/spirit-overview.png\" />\n      </div>\n      <div class=\"mindset-data\">\n        <div class=\"mindset-principle\">\n          <h5>Overview</h5>\n          <p>\n            The spirit principle tends to be most overlooked of the Core 4\n            Principles. However, it produces the highest outcome. Learning how\n            to elevate your consciousness and connect with something ‘greater’\n            than yourself gives you a sense of meaning and improves your quality\n            of life. Spiritual practices equate to better health and overall\n            wellbeing. Within this guide I will highlight a few ways to\n            strengthen your spiritual connection. Practicing these steps will\n            develop the foundation for life changing results.\n          </p>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>Recognize Your Creator</h5>\n          <div>\n            <p>\n              Quiet time alone will help you develop more peace, patience and\n              joy in your life.\n            </p>\n            <ul>\n              <li>\n                Recognize there is a power in the universe greater than\n                yourself, however you define it.\n              </li>\n              <li>Invest time in thought and prayer.</li>\n              <li>\n                Explore your beliefs and values (these are the core of who you\n                are).\n              </li>\n            </ul>\n          </div>\n          <div>\n            <p>\n              Questions to ask:\n            </p>\n            <ul>\n              <li>\n                Who am I?\n              </li>\n              <li>What is my purpose?</li>\n              <li>\n                What are my values and beliefs?\n              </li>\n            </ul>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>Meditate</h5>\n          <div>\n            <p>\n              By calming your mind through meditation you can become more aware\n              of your thoughts and emotions. Practicing meditation helps you\n              know yourself on a deeper level lowering stress and anxiety while\n              creating a clear path of direction.\n            </p>\n            <ul>\n              <li>\n                Schedule time daily to meditate and pray.\n              </li>\n              <li>Find a quiet space where you can be enriched.</li>\n              <li>\n                Use resources like an accountability calendar or an app.\n              </li>\n            </ul>\n          </div>\n          <div>\n            <p>\n              Questions to ask:\n            </p>\n            <ul>\n              <li>\n                Who or what inspires me?\n              </li>\n              <li>What qualities do I desire to possess more of?</li>\n              <li>\n                Who am I at my most authentic self?\n              </li>\n            </ul>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>Gratitude Journal</h5>\n          <div>\n            <p>\n              Gratitude allows you to be more purposeful and humble showing more\n              love to others. It helps you live in the now and appreciate what\n              you have.\n            </p>\n            <ul>\n              <li>\n                Write down 3 things that you are grateful for at the start and\n                end of your day.\n              </li>\n              <li>Show your gratitude by serving others.</li>\n              <li>\n                Use resources like a gratitude journal.\n              </li>\n            </ul>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>\n            Goal Setting (Refer to the Getting Started Guide for Goal Setting\n            Instructions)\n          </h5>\n          <p>\n            Set 1 to 3 goals to strengthen your mindset (example: meditate,\n            pray, journal daily)\n          </p>\n          <p class=\"goal-input\">1. <input type=\"text\" /></p>\n          <p class=\"goal-input\">2. <input type=\"text\" /></p>\n          <p class=\"goal-input\">3. <input type=\"text\" /></p>\n        </div>\n      </div>\n    </div>\n    <div *ngIf=\"type=='connect' && spiritData.length>0\" >\n      <div class=\"content\" *ngFor=\"let spirit_data of spiritData\">\n        <ng-controller (click)=\"detail(spirit_data, 'spirit')\">\n          <div class=\"img-box\" >\n            <img src=\"{{spirit_data?.image}}\" />\n            <ion-icon name=\"eye-outline\"></ion-icon>\n          </div>\n          <h5>{{spirit_data?.title}}:</h5>\n          <p>\n          {{spirit_data?.description}}\n          </p>\n        </ng-controller>      \n      </div>\n      <div *ngIf=\"spiritData.length==0\">\n      <p text-center>No Spirit Found!</p>\n      </div>\n      <!-- <div class=\"content\">\n        <div class=\"img-box\">\n          <img src=\"assets/images/s2.png\" />\n          <ion-icon name=\"eye-outline\"></ion-icon>\n        </div>\n        <h5>BICEPS:</h5>\n        <p>\n          Neque porro quisquam est qui dolorem ipsum quia dolor sit amet,\n          consectetur, adipisci velit. Neque porro quisquam est qui dolorem\n          ipsum quia dolor sit amet, consectetur, adipisci velit.\n        </p>\n      </div> -->\n    </div>\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/spirit/spirit-routing.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/spirit/spirit-routing.module.ts ***!
    \*************************************************/

  /*! exports provided: SpiritPageRoutingModule */

  /***/
  function srcAppSpiritSpiritRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SpiritPageRoutingModule", function () {
      return SpiritPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _spirit_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./spirit.page */
    "./src/app/spirit/spirit.page.ts");

    var routes = [{
      path: '',
      component: _spirit_page__WEBPACK_IMPORTED_MODULE_3__["SpiritPage"]
    }];

    var SpiritPageRoutingModule = function SpiritPageRoutingModule() {
      _classCallCheck(this, SpiritPageRoutingModule);
    };

    SpiritPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], SpiritPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/spirit/spirit.module.ts":
  /*!*****************************************!*\
    !*** ./src/app/spirit/spirit.module.ts ***!
    \*****************************************/

  /*! exports provided: SpiritPageModule */

  /***/
  function srcAppSpiritSpiritModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SpiritPageModule", function () {
      return SpiritPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _spirit_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./spirit-routing.module */
    "./src/app/spirit/spirit-routing.module.ts");
    /* harmony import */


    var _spirit_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./spirit.page */
    "./src/app/spirit/spirit.page.ts");

    var SpiritPageModule = function SpiritPageModule() {
      _classCallCheck(this, SpiritPageModule);
    };

    SpiritPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _spirit_routing_module__WEBPACK_IMPORTED_MODULE_5__["SpiritPageRoutingModule"]],
      declarations: [_spirit_page__WEBPACK_IMPORTED_MODULE_6__["SpiritPage"]]
    })], SpiritPageModule);
    /***/
  },

  /***/
  "./src/app/spirit/spirit.page.scss":
  /*!*****************************************!*\
    !*** ./src/app/spirit/spirit.page.scss ***!
    \*****************************************/

  /*! exports provided: default */

  /***/
  function srcAppSpiritSpiritPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 50px;\n  letter-spacing: 1px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n  margin-right: 10px;\n}\n.header .search {\n  text-align: right;\n  float: right;\n  margin-right: 10px;\n  color: #fff;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\nion-content {\n  font-family: Rajdhani-Regular;\n}\nion-content p {\n  text-align: justify;\n}\n.image-s {\n  padding: 20px;\n}\n.mindset-guid-head {\n  padding: 0px 16px;\n  color: #fff;\n  background-image: url('heading-bg.png');\n  width: 100%;\n  background-position: center;\n}\n.mindset-guid-head h4 {\n  padding: 5px 0px;\n}\n.mindset-data {\n  padding: 16px;\n}\n.mindset-data .mindset-principle h5 {\n  font-size: 20px;\n  font-weight: 600;\n  color: #e7863d;\n}\np.goal-input input {\n  width: 90%;\n  margin-left: 10px;\n  border: none;\n  outline: none;\n}\np.goal-input {\n  border-bottom: 1px solid #000;\n}\n.mindset .content {\n  padding: 20px;\n  border-bottom: 1px solid #ddd;\n}\n.mindset .content .img-box {\n  position: relative;\n  width: 100%;\n}\n.mindset .content .img-box img {\n  position: relative;\n  width: 100%;\n}\n.mindset .content .img-box ion-icon {\n  position: absolute;\n  bottom: 4px;\n  background: #f77e21bf;\n  color: #fff;\n  width: 100%;\n  left: 0;\n  right: 0;\n  padding: 5px 0;\n  border-radius: 0px 0px 10px 10px;\n}\n.mindset .content h5 {\n  font-family: Rajdhani-Bold;\n  letter-spacing: 1px;\n  font-size: 24px;\n  margin-top: 20px;\n}\n.mindset .content p {\n  margin-top: 10px;\n  font-family: Rajdhani-Regular;\n  color: #858585;\n  letter-spacing: 1px;\n  font-size: 17px;\n  line-height: 24px;\n  text-align: justify;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL3NwaXJpdC9zcGlyaXQucGFnZS5zY3NzIiwic3JjL2FwcC9zcGlyaXQvc3Bpcml0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FDQ0Y7QURFRTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0FKO0FERUU7RUFDRSxXQUFBO0FDQUo7QURFRTtFQUNFLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ0FKO0FERUU7RUFDRSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUNBSjtBREVFO0VBQ0UsWUFBQTtFQUNBLGNBQUE7RUFDQSwwQkFBQTtFQUNBLFdBQUE7QUNBSjtBRElBO0VBQ0UsNkJBQUE7QUNERjtBREVFO0VBQ0UsbUJBQUE7QUNBSjtBREdBO0VBQ0UsYUFBQTtBQ0FGO0FERUE7RUFDRSxpQkFBQTtFQUVBLFdBQUE7RUFDQSx1Q0FBQTtFQUNBLFdBQUE7RUFDQSwyQkFBQTtBQ0FGO0FEQ0U7RUFDRSxnQkFBQTtBQ0NKO0FER0E7RUFDRSxhQUFBO0FDQUY7QURHSTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNETjtBRE1BO0VBQ0UsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNIRjtBRE1BO0VBQ0UsNkJBQUE7QUNIRjtBRE9FO0VBQ0UsYUFBQTtFQUNBLDZCQUFBO0FDSko7QURLSTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtBQ0hOO0FESU07RUFDRSxrQkFBQTtFQUNBLFdBQUE7QUNGUjtBRElNO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsY0FBQTtFQUNBLGdDQUFBO0FDRlI7QURLSTtFQUNFLDBCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNITjtBREtJO0VBQ0UsZ0JBQUE7RUFDQSw2QkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FDSE4iLCJmaWxlIjoic3JjL2FwcC9zcGlyaXQvc3Bpcml0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXIge1xuICAtLWJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIGNvbG9yOiAjZmZmO1xuICAvL3BhZGRpbmc6ICAxNnB4O1xuXG4gIGlvbi10aXRsZSB7XG4gICAgcGFkZGluZzogMHB4O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgcGFkZGluZy1sZWZ0OiA1MHB4O1xuICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gIH1cbiAgaW9uLW1lbnUtYnV0dG9uIHtcbiAgICBjb2xvcjogI2ZmZjtcbiAgfVxuICBpb24taWNvbiB7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICB9XG4gIC5zZWFyY2gge1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgY29sb3I6ICNmZmY7XG4gIH1cbiAgcCB7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGNvbG9yOiAjZjc3ZTIxO1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgIG1hcmdpbjogMGVtO1xuICB9XG59XG5cbmlvbi1jb250ZW50IHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIHB7XG4gICAgdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgfVxufVxuLmltYWdlLXN7XG4gIHBhZGRpbmc6MjBweDtcbn1cbi5taW5kc2V0LWd1aWQtaGVhZCB7XG4gIHBhZGRpbmc6IDBweCAxNnB4O1xuIC8vIGJhY2tncm91bmQ6ICNlNzg2M2Q7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWltYWdlOnVybCguLi8uLi9hc3NldHMvaW1hZ2VzL2hlYWRpbmctYmcucG5nKTtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgaDQge1xuICAgIHBhZGRpbmc6IDVweCAwcHg7XG4gIH1cbn1cblxuLm1pbmRzZXQtZGF0YSB7XG4gIHBhZGRpbmc6IDE2cHg7XG5cbiAgLm1pbmRzZXQtcHJpbmNpcGxlIHtcbiAgICBoNSB7XG4gICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgY29sb3I6ICNlNzg2M2Q7XG4gICAgfVxuICB9XG59XG5cbnAuZ29hbC1pbnB1dCBpbnB1dCB7XG4gIHdpZHRoOiA5MCU7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG5cbnAuZ29hbC1pbnB1dCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMDAwO1xufVxuXG4ubWluZHNldCB7XG4gIC5jb250ZW50IHtcbiAgICBwYWRkaW5nOiAyMHB4O1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZGRkO1xuICAgIC5pbWctYm94IHtcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgaW1nIHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgIH1cbiAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBib3R0b206IDRweDtcbiAgICAgICAgYmFja2dyb3VuZDogI2Y3N2UyMWJmO1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGxlZnQ6IDA7XG4gICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICBwYWRkaW5nOiA1cHggMDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMHB4IDBweCAxMHB4IDEwcHg7XG4gICAgICB9XG4gICAgfVxuICAgIGg1IHtcbiAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgfVxuICAgIHAge1xuICAgICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgICAgY29sb3I6ICM4NTg1ODU7XG4gICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICAgICAgZm9udC1zaXplOiAxN3B4O1xuICAgICAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gICAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICAgIH1cbiAgfVxufVxuIiwiLmhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi10aXRsZSB7XG4gIHBhZGRpbmc6IDBweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIHBhZGRpbmctbGVmdDogNTBweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbn1cbi5oZWFkZXIgaW9uLW1lbnUtYnV0dG9uIHtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi1pY29uIHtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLmhlYWRlciAuc2VhcmNoIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBjb2xvcjogI2ZmZjtcbn1cbi5oZWFkZXIgcCB7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6ICNmNzdlMjE7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICBtYXJnaW46IDBlbTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbn1cbmlvbi1jb250ZW50IHAge1xuICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xufVxuXG4uaW1hZ2UtcyB7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG5cbi5taW5kc2V0LWd1aWQtaGVhZCB7XG4gIHBhZGRpbmc6IDBweCAxNnB4O1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKC4uLy4uL2Fzc2V0cy9pbWFnZXMvaGVhZGluZy1iZy5wbmcpO1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xufVxuLm1pbmRzZXQtZ3VpZC1oZWFkIGg0IHtcbiAgcGFkZGluZzogNXB4IDBweDtcbn1cblxuLm1pbmRzZXQtZGF0YSB7XG4gIHBhZGRpbmc6IDE2cHg7XG59XG4ubWluZHNldC1kYXRhIC5taW5kc2V0LXByaW5jaXBsZSBoNSB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICNlNzg2M2Q7XG59XG5cbnAuZ29hbC1pbnB1dCBpbnB1dCB7XG4gIHdpZHRoOiA5MCU7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG5cbnAuZ29hbC1pbnB1dCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMDAwO1xufVxuXG4ubWluZHNldCAuY29udGVudCB7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZGRkO1xufVxuLm1pbmRzZXQgLmNvbnRlbnQgLmltZy1ib3gge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiAxMDAlO1xufVxuLm1pbmRzZXQgLmNvbnRlbnQgLmltZy1ib3ggaW1nIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogMTAwJTtcbn1cbi5taW5kc2V0IC5jb250ZW50IC5pbWctYm94IGlvbi1pY29uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDRweDtcbiAgYmFja2dyb3VuZDogI2Y3N2UyMWJmO1xuICBjb2xvcjogI2ZmZjtcbiAgd2lkdGg6IDEwMCU7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICBwYWRkaW5nOiA1cHggMDtcbiAgYm9yZGVyLXJhZGl1czogMHB4IDBweCAxMHB4IDEwcHg7XG59XG4ubWluZHNldCAuY29udGVudCBoNSB7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICBmb250LXNpemU6IDI0cHg7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG4ubWluZHNldCAuY29udGVudCBwIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIGNvbG9yOiAjODU4NTg1O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICBmb250LXNpemU6IDE3cHg7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/spirit/spirit.page.ts":
  /*!***************************************!*\
    !*** ./src/app/spirit/spirit.page.ts ***!
    \***************************************/

  /*! exports provided: SpiritPage */

  /***/
  function srcAppSpiritSpiritPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SpiritPage", function () {
      return SpiritPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _search_exercises_search_exercises_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../search-exercises/search-exercises.page */
    "./src/app/search-exercises/search-exercises.page.ts");
    /* harmony import */


    var _detailspirit_detailspirit_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../detailspirit/detailspirit.page */
    "./src/app/detailspirit/detailspirit.page.ts");

    var SpiritPage = /*#__PURE__*/function () {
      function SpiritPage(modalController, navCtrl, router, route) {
        var _this = this;

        _classCallCheck(this, SpiritPage);

        this.modalController = modalController;
        this.navCtrl = navCtrl;
        this.router = router;
        this.route = route;
        this.type = 'guid';
        this.spiritData = [];
        this.route.queryParams.subscribe(function (params) {
          if (params && params.type) {
            _this.type = params.type;
            console.log(_this.type);

            if (_this.type == 'connect') {
              _this.spiritData = [{
                'id': 1,
                'title': 'Chest',
                'image': 'assets/images/s1.png',
                'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
              }, {
                'id': 2,
                'title': 'Biceps',
                'image': 'assets/images/s2.png',
                'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
              }];
              console.log(_this.spiritData);
            }
          }
        });
      }

      _createClass(SpiritPage, [{
        key: "search",
        value: function search() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var modal;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.modalController.create({
                      component: _search_exercises_search_exercises_page__WEBPACK_IMPORTED_MODULE_4__["SearchExercisesPage"]
                    });

                  case 2:
                    modal = _context.sent;
                    _context.next = 5;
                    return modal.present();

                  case 5:
                    return _context.abrupt("return", _context.sent);

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "detail",
        value: function detail(data, type) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var modal;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.modalController.create({
                      component: _detailspirit_detailspirit_page__WEBPACK_IMPORTED_MODULE_5__["DetailspiritPage"],
                      componentProps: {
                        data: data,
                        type: type
                      }
                    });

                  case 2:
                    modal = _context2.sent;
                    _context2.next = 5;
                    return modal.present();

                  case 5:
                    return _context2.abrupt("return", _context2.sent);

                  case 6:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return SpiritPage;
    }();

    SpiritPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }];
    };

    SpiritPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-spirit',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./spirit.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/spirit/spirit.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./spirit.page.scss */
      "./src/app/spirit/spirit.page.scss"))["default"]]
    })], SpiritPage);
    /***/
  }
}]);
//# sourceMappingURL=spirit-spirit-module-es5.js.map