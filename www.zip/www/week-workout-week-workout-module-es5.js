function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["week-workout-week-workout-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/week-workout/week-workout.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/week-workout/week-workout.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppWeekWorkoutWeekWorkoutPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <!-- <div class=\"header\">\n    <ion-row>\n      <ion-col size=\"1\">\n        <ion-icon name=\"menu-outline\"></ion-icon>\n        <ion-buttons slot=\"start\">\n          <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n      </ion-col>\n      <ion-col size=\"9\">\n        <ion-title> THIS WEEK WORKOUT</ion-title>\n      </ion-col>\n      <ion-col size=\"2\" text-right>\n        <ion-icon name=\"settings-outline\" class=\"setting\"></ion-icon>\n      </ion-col>\n    </ion-row>\n  </div> -->\n    <ion-toolbar class=\"header\">\n      <ion-buttons slot=\"start\">\n        <ion-menu-button></ion-menu-button>\n      </ion-buttons>\n      <ion-title>THIS WEEK WORKOUT</ion-title>\n      <ion-buttons slot=\"end\">\n        <ion-icon name=\"settings-outline\" (click)=\"settings()\" class=\"setting\"></ion-icon>\n      </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"workout\">\n    <!-- <ion-row  > -->\n      <div class=\"video-icons\" *ngFor=\"let weekdata of week_list; let i =index\"  >\n        <!-- <video *ngIf=\"weekdata.url!= null \" controls=\"controls\" preload=\"metadata\"  webkit-playsinline=\"webkit-playsinline\" class=\"videoPlayer\">\n          <source src=\"{{weekdata.url}}\"  type=\"video/mp4\"/>\n      </video> -->\n      <iframe  *ngIf=\"weekdata.url!= null \" style= \"z-index:999\" height=\"200px\" width=\"100%\" preload=\"none\" target=\"_parent\"  [src]=\"weekdata.trustedVideoUrl\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\n\n        <!-- <img src=\"assets/images/workout.png\" />\n        <div class=\"video-icon\">\n           <img src=\"assets/images/video.png\" />\n\n          </div> -->\n        </div>\n      <!-- <ion-col size=\"6\">\n        <div class=\"video-icons\">\n        <img src=\"assets/images/workout.png\" />\n        <div class=\"video-icon\">\n           <img src=\"assets/images/video.png\" />\n\n          </div>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n             <img src=\"assets/images/video.png\" />\n  \n            </div>\n          </div>\n      </ion-col> -->\n    <!-- </ion-row> -->\n    <!-- <ion-row>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n             <img src=\"assets/images/video.png\" />\n  \n            </div>\n          </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n             <img src=\"assets/images/video.png\" />\n  \n            </div>\n          </div>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n             <img src=\"assets/images/video.png\" />\n  \n            </div>\n          </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n             <img src=\"assets/images/video.png\" />\n  \n            </div>\n          </div>\n      </ion-col>\n    </ion-row> -->\n\n    <div class=\"divider\"></div>\n\n    <h3>Liked Exercises</h3>\n\n    <ion-row>\n      <ion-col size=\"6\">\n        <div class=\"work-out-box\">\n          <img src=\"assets/images/workout.png\" />\n          <h4>ABS</h4>\n        </div>\n      </ion-col>  \n      <ion-col size=\"6\">\n        <div class=\"work-out-box\">\n          <img src=\"assets/images/workout.png\" />\n          <h4>SHOULDER</h4>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"6\">\n        <div class=\"work-out-box\">\n          <img src=\"assets/images/workout.png\" />\n          <H4>BICEPS</H4>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"work-out-box\">\n          <img src=\"assets/images/workout.png\" />\n          <H4>BICEPS</H4>\n        </div>\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/week-workout/week-workout-routing.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/week-workout/week-workout-routing.module.ts ***!
    \*************************************************************/

  /*! exports provided: WeekWorkoutPageRoutingModule */

  /***/
  function srcAppWeekWorkoutWeekWorkoutRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "WeekWorkoutPageRoutingModule", function () {
      return WeekWorkoutPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _week_workout_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./week-workout.page */
    "./src/app/week-workout/week-workout.page.ts");

    var routes = [{
      path: '',
      component: _week_workout_page__WEBPACK_IMPORTED_MODULE_3__["WeekWorkoutPage"]
    }];

    var WeekWorkoutPageRoutingModule = function WeekWorkoutPageRoutingModule() {
      _classCallCheck(this, WeekWorkoutPageRoutingModule);
    };

    WeekWorkoutPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], WeekWorkoutPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/week-workout/week-workout.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/week-workout/week-workout.module.ts ***!
    \*****************************************************/

  /*! exports provided: WeekWorkoutPageModule */

  /***/
  function srcAppWeekWorkoutWeekWorkoutModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "WeekWorkoutPageModule", function () {
      return WeekWorkoutPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _week_workout_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./week-workout-routing.module */
    "./src/app/week-workout/week-workout-routing.module.ts");
    /* harmony import */


    var _week_workout_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./week-workout.page */
    "./src/app/week-workout/week-workout.page.ts");

    var WeekWorkoutPageModule = function WeekWorkoutPageModule() {
      _classCallCheck(this, WeekWorkoutPageModule);
    };

    WeekWorkoutPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _week_workout_routing_module__WEBPACK_IMPORTED_MODULE_5__["WeekWorkoutPageRoutingModule"]],
      declarations: [_week_workout_page__WEBPACK_IMPORTED_MODULE_6__["WeekWorkoutPage"]]
    })], WeekWorkoutPageModule);
    /***/
  },

  /***/
  "./src/app/week-workout/week-workout.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/week-workout/week-workout.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppWeekWorkoutWeekWorkoutPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".header {\n  --background:#233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 16px;\n  text-align: left;\n  padding-left: 50px;\n  letter-spacing: 1px;\n  font-family: Rajdhani-Regular;\n  line-height: 14px;\n  display: block;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header .setting {\n  float: right;\n  margin-right: 10px;\n  color: #fff;\n}\n.workout {\n  padding: 20px;\n  text-align: center;\n  position: relative;\n}\n.workout h3 {\n  font-size: 24px;\n  font-family: Rajdhani-Regular;\n  text-align: left;\n}\n.workout .video-icons {\n  width: 49%;\n  float: left;\n  margin-right: 3px;\n}\n.workout .divider {\n  border-top: 1px solid #a9a6a6;\n  margin-top: 20px;\n  margin-bottom: 20px;\n}\n.workout img {\n  position: relative;\n  width: 100%;\n}\n.workout ion-icon {\n  position: absolute;\n  text-align: center;\n  left: 32%;\n  color: #fff;\n  top: 27%;\n  font-size: 40px;\n  padding: 10px;\n  border-radius: 100px;\n}\n.workout .work-out-box {\n  position: relative;\n  overflow: hidden;\n}\n.workout .work-out-box h4 {\n  position: absolute;\n  bottom: 0px;\n  color: #fff;\n  text-align: center;\n  font-size: 16px;\n  background: #f77e21;\n  width: 100%;\n  padding: 5px;\n  margin: 0;\n  border-radius: 0 0 8px 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL3dlZWstd29ya291dC93ZWVrLXdvcmtvdXQucGFnZS5zY3NzIiwic3JjL2FwcC93ZWVrLXdvcmtvdXQvd2Vlay13b3Jrb3V0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FDQ0o7QURBSTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSw2QkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQ0VKO0FEQUk7RUFDSSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FDRVI7QURBSTtFQUNJLFdBQUE7QUNFUjtBREFJO0VBQ0ksWUFBQTtFQUNBLGtCQUFBO0VBQ0osV0FBQTtBQ0VKO0FEQ0E7RUFDSSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQ0VKO0FEREk7RUFDSSxlQUFBO0VBQ0EsNkJBQUE7RUFDQSxnQkFBQTtBQ0dSO0FEREk7RUFFSSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0FDRVI7QURZSTtFQUNJLDZCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQ1ZSO0FEWUk7RUFDSSxrQkFBQTtFQUNBLFdBQUE7QUNWUjtBRFlJO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7QUNWUjtBRFlJO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtBQ1ZSO0FEV0k7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7RUFDSiwwQkFBQTtBQ1RKIiwiZmlsZSI6InNyYy9hcHAvd2Vlay13b3Jrb3V0L3dlZWstd29ya291dC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVye1xuICAgIC0tYmFja2dyb3VuZDojMjMzOTQyO1xuICAgIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gICAgY29sb3I6I2ZmZjtcbiAgICBpb24tdGl0bGV7XG4gICAgcGFkZGluZzogMTZweDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIHBhZGRpbmctbGVmdDogNTBweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgIGxpbmUtaGVpZ2h0OiAxNHB4O1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cbiAgICBpb24taWNvbntcbiAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICAgICAgY29sb3I6I2ZmZjtcbiAgICAgICAgZm9udC1zaXplOjIwcHg7XG4gICAgfVxuICAgIGlvbi1tZW51LWJ1dHRvbntcbiAgICAgICAgY29sb3I6I2ZmZjtcbiAgICB9XG4gICAgLnNldHRpbmd7XG4gICAgICAgIGZsb2F0OnJpZ2h0O1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgfVxufVxuLndvcmtvdXR7XG4gICAgcGFkZGluZzogMjBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIGgze1xuICAgICAgICBmb250LXNpemU6IDI0cHg7XG4gICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIH1cbiAgICAudmlkZW8taWNvbnN7XG4gICAgICAgIC8vIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgd2lkdGg6IDQ5JTtcbiAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgIG1hcmdpbi1yaWdodDogM3B4O1xuICAgICAgICAvLyAudmlkZW8taWNvbntcbiAgICAgICAgLy8gICAgIG1hcmdpbjogMCBhdXRvO1xuICAgICAgICAvLyAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAvLyAgICAgdG9wOiAzNCU7XG4gICAgICAgIC8vICAgICByaWdodDogMDtcbiAgICAgICAgLy8gICAgIGxlZnQ6IDA7XG4gICAgICAgIC8vICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIC8vICAgICBpbWd7XG4gICAgICAgIC8vICAgICAgICAgd2lkdGg6YXV0bztcbiAgICAgICAgLy8gICAgIH1cbiAgICAgICAgLy8gfVxuICAgIH1cbiAgICBcbiAgICAuZGl2aWRlcntcbiAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNhOWE2YTY7XG4gICAgICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gICAgfVxuICAgIGltZ3tcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICB9XG4gICAgaW9uLWljb257XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICBsZWZ0OiAzMiU7XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICB0b3A6IDI3JTtcbiAgICAgICAgZm9udC1zaXplOiA0MHB4O1xuICAgICAgICBwYWRkaW5nOiAxMHB4O1xuICAgICAgICBib3JkZXItcmFkaXVzOiAxMDBweDtcbiAgICB9XG4gICAgLndvcmstb3V0LWJveHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIGg0IHtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBib3R0b206IDBweDtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgICBiYWNrZ3JvdW5kOiAjZjc3ZTIxO1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgcGFkZGluZzogNXB4O1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgYm9yZGVyLXJhZGl1czogMCAwIDhweCA4cHg7XG4gICAgfVxufVxufVxuIiwiLmhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDojMjMzOTQyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbn1cbi5oZWFkZXIgaW9uLXRpdGxlIHtcbiAgcGFkZGluZzogMTZweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgcGFkZGluZy1sZWZ0OiA1MHB4O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgbGluZS1oZWlnaHQ6IDE0cHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuLmhlYWRlciBpb24taWNvbiB7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG59XG4uaGVhZGVyIGlvbi1tZW51LWJ1dHRvbiB7XG4gIGNvbG9yOiAjZmZmO1xufVxuLmhlYWRlciAuc2V0dGluZyB7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLndvcmtvdXQge1xuICBwYWRkaW5nOiAyMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi53b3Jrb3V0IGgzIHtcbiAgZm9udC1zaXplOiAyNHB4O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cbi53b3Jrb3V0IC52aWRlby1pY29ucyB7XG4gIHdpZHRoOiA0OSU7XG4gIGZsb2F0OiBsZWZ0O1xuICBtYXJnaW4tcmlnaHQ6IDNweDtcbn1cbi53b3Jrb3V0IC5kaXZpZGVyIHtcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNhOWE2YTY7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG4ud29ya291dCBpbWcge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiAxMDAlO1xufVxuLndvcmtvdXQgaW9uLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbGVmdDogMzIlO1xuICBjb2xvcjogI2ZmZjtcbiAgdG9wOiAyNyU7XG4gIGZvbnQtc2l6ZTogNDBweDtcbiAgcGFkZGluZzogMTBweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwcHg7XG59XG4ud29ya291dCAud29yay1vdXQtYm94IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLndvcmtvdXQgLndvcmstb3V0LWJveCBoNCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAwcHg7XG4gIGNvbG9yOiAjZmZmO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgYmFja2dyb3VuZDogI2Y3N2UyMTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDVweDtcbiAgbWFyZ2luOiAwO1xuICBib3JkZXItcmFkaXVzOiAwIDAgOHB4IDhweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/week-workout/week-workout.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/week-workout/week-workout.page.ts ***!
    \***************************************************/

  /*! exports provided: WeekWorkoutPage */

  /***/
  function srcAppWeekWorkoutWeekWorkoutPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "WeekWorkoutPage", function () {
      return WeekWorkoutPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");

    var WeekWorkoutPage = /*#__PURE__*/function () {
      function WeekWorkoutPage(navCtrl, sanitizer) {
        var _this = this;

        _classCallCheck(this, WeekWorkoutPage);

        this.navCtrl = navCtrl;
        this.sanitizer = sanitizer;
        this.weekData = [{
          'id': 1,
          'url': 'https://www.youtube.com/watch?v=z3MiUVxXx8Q'
        }, {
          'id': 2,
          'url': 'https://www.youtube.com/watch?v=HagVnWAeGcM'
        }, {
          'id': 3,
          'url': 'https://www.youtube.com/watch?v=z3MiUVxXx8Q'
        }, {
          'id': 4,
          'url': 'https://www.youtube.com/watch?v=HagVnWAeGcM'
        }, {
          'id': 5,
          'url': 'https://www.youtube.com/watch?v=z3MiUVxXx8Q'
        }, {
          'id': 6,
          'url': 'https://www.youtube.com/watch?v=HagVnWAeGcM'
        }];
        this.week_list = [];
        console.log(this.weekData, "weeekdata");
        var that = this;
        this.weekData.forEach(function (element) {
          if (element.url != null) {
            var url = that.validateYouTubeUrl(element.url);
            console.log('url:- ', url);
            var pos = element.url.indexOf('watch');
            console.log(pos);

            if (pos !== -1) {
              element.url = element.url.replace('watch?v=', 'embed/');
            } else {
              var _pos = element.url.indexOf('youtu.be'); // 0


              if (_pos !== -1) {
                element.url.replace('youtu.be', 'www.youtube.com/embed/' + url.vidId);
              } else {
                element.url;
              }
            }

            console.log('element:-----', element.url);
            element['trustedVideoUrl'] = _this.sanitizer.bypassSecurityTrustResourceUrl(element.url);
            console.log('ooooo', element);
          }

          _this.week_list.push(element); // this.postlist = data.data.data;


          console.log(_this.week_list);
        });
      }

      _createClass(WeekWorkoutPage, [{
        key: "validateYouTubeUrl",
        value: function validateYouTubeUrl(element) {
          if (element !== undefined || element !== '') {
            console.log('URL-->', element);
            var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|\?v=)([^#\&\?]*).*/;
            var match = element.match(regExp);

            if (match && match[2].length === 11) {
              console.log('MATCH YOUTUBE', match[2]);
              return {
                type: 'youtube',
                vidId: match[2]
              };
            } else {
              return {
                type: 'video'
              };
            }
          }
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "settings",
        value: function settings() {
          this.navCtrl.navigateForward("/settings");
        }
      }]);

      return WeekWorkoutPage;
    }();

    WeekWorkoutPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"]
      }];
    };

    WeekWorkoutPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: "app-week-workout",
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./week-workout.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/week-workout/week-workout.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./week-workout.page.scss */
      "./src/app/week-workout/week-workout.page.scss"))["default"]]
    })], WeekWorkoutPage);
    /***/
  }
}]);
//# sourceMappingURL=week-workout-week-workout-module-es5.js.map