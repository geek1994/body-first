function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["nutrition-nutrition-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/nutrition/nutrition.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/nutrition/nutrition.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppNutritionNutritionPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>NUTRITION</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-icon\n      *ngIf=\"type =='videos'\"\n        name=\"search-outline\"\n        class=\"setting\"\n        (click)=\"showDefaultBar()\"\n      ></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div>\n    <ion-searchbar\n    *ngIf=\"toggled && type =='videos'\"\n    placeholder=\"Search\"\n    inputmode=\"text\" type=\"text\"\n    [(ngModel)]=\"searchTerm\" mode=\"ios\"\n    (ionChange)=\"onSearchChange($event)\"\n    (ionCancel)=\"clearData()\"\n    (ionBlur)=\"showDefaultBar()\"\n    showCancelButton=\"always\"\n    [debounce]=\"250\"\n    animated=\"true\">\n  </ion-searchbar>\n  </div>\n  <div class=\"mindset\">\n    <div class=\"mindset-guid\" *ngIf=\"type=='mens-guid'\">\n      <img src=\"assets/images/mensnutrtion.png\" />\n      <div class=\"mindset-guid-head\">\n        <h4>MEN’S NUTRITION PRINCIPLE</h4>\n      </div>\n      <div class=\"m-image\">\n        <img src=\"assets/images/mnutrition.png\" />\n      </div>\n      <div class=\"mindset-data\">\n        <div class=\"mindset-principle\">\n          <h5>Overview</h5>\n          <p>\n            Nutrition is the key component to your fitness. It is difficult to\n            train your way out of poor nutrition. Following a balanced diet is\n            essential to your success. This is a simple guide to help you\n            achieve your goals while supporting your nutritional needs for\n            health and fitness. It is important to choose foods that are\n            nutrient rich and whole, not processed and full of sugar. Nutrient\n            rich foods give your body the fuel and energy it requires to\n            accomplish your daily tasks. <br />In this guide, I provide you with\n            simple philosophies and sample meal plans to get you started. Not a\n            lecture, I empower you to use this information and start making\n            educated choices about your fuel intake.\n          </p>\n          <p>\n            Remember this guide should be used as a reference for healthy eating\n            and it is recommended to consult your doctor before starting a new\n            diet. Seeing a good functional medicine health practitioner to get a\n            comprehensive assessment of micronutrients, vitamins, minerals plus\n            hormone and thyroid levels is essential to your specific health\n            needs. The more you know the better you can plan. When setting your\n            body composition goal you must first have a clear understanding of\n            where you are starting. I recommend using an impedance scale to\n            determine your body composition baseline. Regardless of the type of\n            scale you decide to use, be sure to use the same scale to keep the\n            measurement consistent.\n          </p>\n          <!-- <p><b>Here are a few ways to change your mindset:</b></p> -->\n        </div>\n        <div class=\"mindset-principle\">\n          <h5>Outline</h5>\n          <p><b>1. Understanding the ‘Nutrition Basics’.</b></p>\n          <p><b>2. Defining High and Low Days</b></p>\n          <p><b>3. Healthy Foods List</b></p>\n          <p><b>4. Foods to avoid</b></p>\n          <p><b>5. Portion Sizes / Sample Meal Plan</b></p>\n        </div>\n        <div class=\"mindset-principle\">\n          <h5>1. Nutrition Basics</h5>\n          <b>Understanding Macronutrients (Macros)</b>\n          <p>\n            <b>Proteins - </b> are essential for growth, tissue repair and is a\n            good source of energy. Protein supplies your body with amino acids\n            that are the building blocks for your cells. It has a metabolic\n            advantage and takes more energy to metabolize. It is recommended\n            that your daily consumption of protein be roughy 1 gram per pound of\n            body weight. (If you are 50 or more pounds overweight use your lean\n            body mass instead of your total bodyweight to calculate your total\n            daily protein). Found in meat, eggs, dairy, and fish.\n          </p>\n\n          <p>\n            <b>Carbohydrates (Carbs) - </b> are essential as they are the\n            preferred energy source for the body, every cell in the body can use\n            glucose (which is the breakdown form of starches and sugars) for\n            energy. Found in fruits, vegetables and grains.\n          </p>\n\n          <p>\n            <b>Fats - </b> are essential for brain function, optimal hormone\n            balance, cell growth and play an important role in metabolism. Fat\n            supplies more than twice the calories per gram of protein or carbs\n            and helps with the absorption of fat soluble vitamins throughout the\n            body plus providing energy. Nuts, seeds, oils and fish offer a\n            healthier version of monounsaturated, polyunsaturated and a few\n            saturated fats. It is best to get a wide variety of healthy fats.<br />\n            <i\n              >*A key rule is to always include a protein source with each meal\n              and adjust your fats and carbs depending on the day.</i\n            >\n          </p>\n          <b>Understanding Micronutrients (Micro’s)</b>\n          <p>\n            Vitamins, minerals, and phytonutrients are small-molecule food\n            components you need in order to support your health. Eating a well\n            balanced diet helps to insure you have all the nutrients required\n            for good health. However, our bodies are still lacking some of the\n            most important nutrients regardless of our diet. For your longevity\n            it is essential to supplement your diet with vitamins and minerals.\n          </p>\n          <p>\n            <b><i>Key Tips:</i></b>\n          </p>\n          <p>Prioritize protein with every meal</p>\n          <p>Prioritize macronutrients and micronutrients more than calories</p>\n          <p>Planning ahead is key to your success</p>\n          <p>\n            Focus on nutrient-packed vegetables, fruits, whole grains, lean\n            meats, and healthy fats\n          </p>\n          <p>Avoid high sugar and processed foods</p>\n\n          <p>\n            <b><i>Water / Hydration:</i></b>\n          </p>\n          <p>\n            Water is the most important of all nutrients for your body. It\n            assists in maintaining normal body temperature, cushions and\n            lubricates joints, protects your spinal cord, removes wastes, makes\n            up 75% of your muscles and makes up 83% of your blood. You must\n            replace the water your body loses daily through normal everyday\n            functions and when you are working out you need to replace even more\n            water that is lost during the workout through sweat.\n          </p>\n\n          <ion-row>\n            <ion-col size=\"8\">\n              <p>\n                <b><i>Key Tips:</i></b>\n              </p>\n              <p>\n                A good goal is to drink roughly 1 oz. per pound of lean body\n                weight.\n              </p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <div class=\"image-water\">\n                <img src=\"assets/images/water.png\" />\n              </div>\n            </ion-col>\n          </ion-row>\n          <p>\n            Start your morning with 8oz of distilled or spring water with 3-5\n            grams of pink himalayan salt and ½ squeezed lemon.\n          </p>\n          <p>\n            Teas and diet sodas do not count towards your hydration goal.\n          </p>\n          <p>\n            Limit your drinking when eating. Drinking too much during meals can\n            lead to inefficient digestion by diluting gastric acids and enzymes.\n          </p>\n          <p>\n            Keeping track of your water consumption will really help you stay on\n            track of your hydration goals.\n          </p>\n          <p>\n            Stay hydrated!\n          </p>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>\n            2. Defining High and Low Days\n            <img\n              src=\"assets/images/arrow.png\"\n              style=\"width: 40px; margin-left: 20px;\"\n            />\n          </h5>\n          <p>\n            High and Low Days refer to the amount of calories and carbs the day\n            will have.\n          </p>\n          <p>High Day = BMR +20%.</p>\n          <p>Low Day = BMR -20%.</p>\n          <p>Refer to body assessment for BMR.</p>\n          <p>\n            One thing consistent on a High and Low Day is the amount of protein\n            and veggies that you eat. On High Days with your lean protein and\n            veggies, you will have carbs and low to no fat. On your Low Days\n            with your protein and veggies, you will have fat with low to no\n            carbs. The most important thing to remember is NO two High Days in a\n            row. Starting your week with a plan is crucial for your success.\n          </p>\n          <b>See chart below:</b>\n          <ion-row class=\"chart\">\n            <ion-col size=\"6\">Monday</ion-col>\n            <ion-col size=\"6\">High Day</ion-col>\n            <ion-col size=\"6\">Tuesday</ion-col>\n            <ion-col size=\"6\">Low Day</ion-col>\n            <ion-col size=\"6\">Wednesday</ion-col>\n            <ion-col size=\"6\">High Day</ion-col>\n            <ion-col size=\"6\">Thursday</ion-col>\n            <ion-col size=\"6\">Low Day</ion-col>\n            <ion-col size=\"6\">Friday</ion-col>\n            <ion-col size=\"6\">High Day</ion-col>\n            <ion-col size=\"6\">Saturday</ion-col>\n            <ion-col size=\"6\">Low Day</ion-col>\n            <ion-col size=\"6\">Sunday</ion-col>\n            <ion-col size=\"6\">High Day</ion-col>\n          </ion-row>\n          <p>\n            <b>General rule of thumb:</b> Keep your fats and carbs separated.<br /><i\n              >High Carbs - Low to No Fat. High Fat - Low to No Carbs.</i\n            >\n          </p>\n          <p><b>High Day:</b></p>\n          <p>\n            Current BMR (refer to assessment) plus 20% = amount of caloric\n            intake on High days\n          </p>\n          <ion-row>\n            <ion-col>\n              <br />\n              <p><b>(Meal 1) - protein, carb & low fat</b></p>\n              <p><b>(Meal 2 - Meal 4) - protein, carb & veggie</b></p>\n              <p><b>(Meal 5) - protein, veggie & fat</b></p>\n              <br />\n              <p><b>Macros:</b></p>\n              <p>\n                Protein: 30%<br />\n                Carb: 50%<br />\n                Fat: 20%<br />\n              </p>\n            </ion-col>\n            <ion-col>\n              <div class=\"image-veg\">\n                <img src=\"assets/images/veg.png\" />\n              </div>\n            </ion-col>\n          </ion-row>\n\n          <p><b>Low Day:</b></p>\n          <p>Current BMR minus 20% = amount of caloric intake on Low days</p>\n          <br />\n          <p><b>(Meal 1 - Meal 5) protein, veggie & fat</b></p>\n          <p><b>Macros:</b></p>\n          <p>\n            Protein: 30%<br />\n            Carb: 50%<br />\n            Fat: 20%<br />\n          </p>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>3. Healthy Foods List: (optimal foods)</h5>\n          <p>\n            Good sources of Protein (High & Low Day):\n          </p>\n          <br />\n\n          <p>\n            <b>Dairy:</b> kefir, goats milk, undenatured grass-fed whey protein\n          </p>\n          <p>\n            <b>Poultry:</b> chicken breast, chicken thighs, ostrich breast, duck\n            breast, turkey breast, lean ground turkey\n          </p>\n          <p>\n            <b>Red Meat:</b> beef, buffalo, elk, venison, veal (always choose\n            those lean cuts)\n          </p>\n          <p>\n            <b>Seafood:</b> wild salmon, oysters, mussels, scallops, sardines\n          </p>\n          <p><b>Vegan:</b> pea protein, rice protein, hemp protein, vegan</p>\n          <p><b>Other:</b> collagen protein, bone broth protein, whole eggs</p>\n          <br />\n          <p><b>Good food sources (Low Day):</b></p>\n          <p>\n            <b>Vegetables: </b>(grown above ground are low carb and can be eaten\n            freely - no root vegetables) spinach, lettuce, asparagus, cucumber,\n            zucchini, egg plant, olive, tomatoes, cabbage, cauliflower,\n            broccoli, kale, green bean, brussel sprout and bell pepper (red,\n            green , yellow), mushroom, celery, radish, artichokes, carrots,\n            squash, turnip greens\n          </p>\n          <p>\n            <b>Fats:</b>avocado oil, coconut oil, ghee, grass fed butter, almond\n            oil, macadamia oil, olive oil, sesame oil, palm oil, walnut oil,\n            almonds, brazil nuts, chia seeds, flax seeds, hemp seeds, hazelnuts,\n            pine nuts, pistachios, pumpkin seeds, sesame seeds, walnuts\n          </p>\n          <p><b>Sweeteners:</b> stevia in the raw, xylitol, erythritol</p>\n          <p>\n            <b>Breakfast Only:</b> granola, old-fashioned oatmeal, steel cut\n            oatmeal, cream of rice, ezekiel bread, sourdough muffins, brown rice\n            tortillas, sprouted bread, apple, grapefruit, cherries, papaya,\n            pineapple, pears, plums, pomegranate, mango, orange, blackberries,\n            blueberries, cranberries, goji berries, raspberries, strawberries,\n            acai, acerola.\n          </p>\n          <br />\n          <p><b>Good food sources: (High Day):</b></p>\n          <p>\n            <b>Bread: </b>ezekiel bread, sourdough muffins, brown rice\n            tortillas, sprouted bread\n          </p>\n          <p>\n            <b>Breakfast Cereal: </b>granola, old-fashioned oatmeal, steel cut\n            oatmeal, cream of rice\n          </p>\n          <p>\n            <b>Fruit:</b>apple, grapefruit, cherries, papaya, pineapple, pears,\n            plums, pomegranates, mango, oranges, blackberries, blueberries,\n            cranberries, goji berries, raspberries, strawberries, acai, acerola\n          </p>\n          <p>\n            <b\n              >Vegetables (grown below ground contain more carbs so be more\n              aware):</b\n            >carrots, potatoes, sweet potatoes, parsnips, rutabaga, beet root,\n            onion, spinach, lettuce, arugula, asparagus, cucumber, zucchini,\n            eggplant, olives, tomatoes, cabbage, cauliflower, broccoli, kale,\n            green bean, brussel sprout, bell pepper (red, green , yellow),\n            mushrooms, celery, radish, artichokes, carrots, squash, turnip\n            greens, bok choy, watercress, wheat grass.\n          </p>\n          <p>\n            <b>Grain:</b>couscous, quinoa, long-grain brown rice, wild rice,\n            popcorn, black rice\n          </p>\n          <p><b>Pasta:</b>brown rice pasta, whole-grain pasta</p>\n          <p><b>Legumes:</b>hummus, beans, lentils, pea</p>\n          <p>\n            <b>Fats:</b>avocado oil, coconut oil, ghee, grass fed butter, almond\n            oil, macadamia oil, olive oil, sesame oil, palm oil, walnut oil,\n            almonds, brazil nuts, chia seeds, flax seeds, hemp seeds, hazelnuts,\n            pine nuts, pistachios, pumpkin seeds, sesame seeds, walnuts,\n            macadamia, pecans, nut butters, seed butters\n          </p>\n          <p>\n            <b>Sweeteners:</b>stevia in the raw, xylitol, erythritol, raw honey,\n            monkfruit, organic coconut sugar\n          </p>\n        </div>\n        <div class=\"mindset-principle\">\n          <h5>\n            4. Foods to Avoid:\n            <img\n              src=\"assets/images/avoid.png\"\n              style=\"width: 30px; margin-left: 20px;\"\n            />\n          </h5>\n          <p>\n            <b>Avoid sugar </b>(especially added sugar and high fructose corn\n            syrup - HFCS) and artificial sweeteners (other than a natural\n            sweetener like stevia).\n          </p>\n          <p>\n            <b>Highly processed foods - </b>any food in a can or package. Any\n            GMO foods (all soy and corn).\n          </p>\n          <p>\n            <b>Refined Carbohydrates -</b>white bread, pastries, white flour,\n            white sugar, HFSC, white pasta, cane sugar, evaporated cane juice,\n            chips, snack crackers, snack cookies, etc...\n          </p>\n          <p>\n            <b>Fried Foods - </b> fried meats, chips, french fries, onion rings,\n            tempura, etc...\n          </p>\n          <p>\n            <b>Processed Meats - </b>hotdogs, packaged sausage, packaged lunch\n            meats, pork, jerky, etc…\n          </p>\n          <p>\n            <b>Seafood - </b>tuna, swordfish, shellfish, crawfish, tilapia (all\n            farm raised fish) (most restaurants are typically farm raised)\n          </p>\n          <p>\n            <b>Unhealthy Oils and Fats -</b>hydrogenated oils (trans fats),\n            soybean oil, canola oil, peanuts\n          </p>\n          <p>\n            <b>Sugary Drinks - </b>sodas, juices with high fructose corn syrup.\n          </p>\n        </div>\n        <!--  -->\n        <div class=\"mindset-principle\">\n          <h5>\n            5. Portion Sizes / Sample Meal Plan\n          </h5>\n          <p><b>Portion Sizes</b></p>\n          <div class=\"portion-size-outer\">\n            <div class=\"portion-size-container\">\n              <div class=\"portion-image-container\">\n                <img src=\"assets/images/hand.png\" />\n              </div>\n              <div class=\"portion-text-container\">\n                <p><b>Palm - </b> (3-4 oz) protein (meats, fish, eggs etc)</p>\n              </div>\n            </div>\n\n            <div class=\"portion-size-container\">\n              <div class=\"portion-image-container\">\n                <img src=\"assets/images/fist1.png\" />\n              </div>\n              <div class=\"portion-text-container\">\n                <p><b>Fist - </b> (1 cup) vegetable</p>\n              </div>\n            </div>\n\n            <div class=\"portion-size-container\">\n              <div class=\"portion-image-container\">\n                <img src=\"assets/images/cupped.png\" />\n              </div>\n              <div class=\"portion-text-container\">\n                <p>\n                  <b>Cupped hand - </b> (½ cup) carbs (grains, starches and\n                  fruits)\n                </p>\n              </div>\n            </div>\n\n            <div class=\"portion-size-container\">\n              <div class=\"portion-image-container\">\n                <img src=\"assets/images/thumb-hand.png\" />\n              </div>\n              <div class=\"portion-text-container\">\n                <p>\n                  <b>Thumb - </b> (1-2 TBSP or ⅛ cup) fats (nut butter, nuts,\n                  oils, cheese)\n                </p>\n              </div>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <div class=\"sample-size-container\">\n            <div class=\"sample-text-container\">\n              <p><b>Sample Meal Plan 1 </b></p>\n            </div>\n            <div class=\"sample-image-container\">\n              <img src=\"assets/images/sample-meal-1.png\" />\n            </div>\n          </div>\n          <div>\n            <p>\n              <b><i>Men’s Sample High Day</i></b>\n            </p>\n\n            <div>\n              <p><b>Meal 1 -</b></p>\n              <p>2 palms egg whites & lean turkey sausage (36-42 grams)</p>\n              <p>2 fists spinach</p>\n              <p>2 cupped hands blueberries</p>\n              <p>2 cupped hands oatmeal</p>\n            </div>\n\n            <div>\n              <p><b>Meal 2 -</b></p>\n              <p>1 Protein Shake (36-42 grams)</p>\n              <p>2 cupped hand Old Fashioned Oats</p>\n              <p>2 cupped hand banana</p>\n              <p>16 oz unsweetened vanilla almond milk or water</p>\n            </div>\n\n            <div>\n              <p><b>Meal 3 -</b></p>\n              <p>2 palms chicken breast (36-42 grams)</p>\n              <p>3 cupped hands sweet potato (or) 3 cupped hands wild rice</p>\n              <p>2 fists mixed salad with lots of veggies and berries</p>\n            </div>\n\n            <div>\n              <p><b>Meal 4 -</b></p>\n              <p>1 Protein Shake (36-42 grams)</p>\n              <p>2 cupped hand Old Fashioned Oats</p>\n              <p>2 cupped hand mixed berries</p>\n              <p>16 oz unsweetened vanilla almond milk or water</p>\n            </div>\n\n            <div>\n              <p><b>Meal 5 -</b></p>\n              <p>2 palms Salmon (36-42 grams)</p>\n              <p>2 fists green veggies (broccoli)</p>\n              <p>1 thumb grass fed butter</p>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <div class=\"sample-size-container\">\n            <div class=\"sample-text-container\">\n              <p><b>Sample Meal Plan 2 </b></p>\n            </div>\n            <div class=\"sample-image-container\">\n              <img src=\"assets/images/sample-meal-2.png\" />\n            </div>\n          </div>\n          <div>\n            <p>\n              <b><i>Men’s Sample Low Day</i></b>\n            </p>\n\n            <div>\n              <p><b>Meal 1 -</b></p>\n              <p>\n                2 palms egg whites & lean turkey sausage (36-42 grams of\n                protein)\n              </p>\n              <p>2 fists spinach</p>\n              <p>1 cupped hands blueberries</p>\n              <p>1 cupped hands oatmeal</p>\n            </div>\n\n            <div>\n              <p><b>Meal 2 -</b></p>\n              <p>1 Protein Shake (36-42 grams)</p>\n              <p>2 thumbs almond butter</p>\n              <p>16 oz unsweetened vanilla almond milk or water</p>\n            </div>\n\n            <div>\n              <p><b>Meal 3 -</b></p>\n              <p>2 palms chicken breast (36-42 grams)</p>\n              <p>2 fists of mixed veggies</p>\n              <p>2 thumbs sunflower seeds</p>\n              <p>1 thumb avocado</p>\n            </div>\n\n            <div>\n              <p><b>Meal 4 -</b></p>\n              <p>1 Protein Shake (36-42 grams)</p>\n              <p>2 thumbs almond butter</p>\n              <p>16 oz unsweetened vanilla almond milk or water</p>\n              <p><b>OR</b></p>\n              <p>2 palms chicken breast</p>\n              <p>2 fists of mixed veggies</p>\n              <p>2 thumbs sunflower seeds</p>\n              <p>1 thumb avocado</p>\n            </div>\n\n            <div>\n              <p><b>Meal 5 -</b></p>\n              <p>2 palms chicken (36-42 grams)</p>\n              <p>1 fists asparagus</p>\n              <p>1 thumbs avocado</p>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>Helpful Tips:</h5>\n          <div>\n            <p>\n              <b\n                >Update your assessment (bi-weekly) and measurements (every 30\n                days) and see how you are progressing then make adjustments\n                where you need to.</b\n              >\n            </p>\n            <p>\n              <b\n                >Commit to following the plan for 2 weeks before making\n                adjustments. Stay connected consciously and aware of how you are\n                feeling.</b\n              >\n            </p>\n            <p>\n              <b\n                >Cravings are typically created from nutrient deficiencies (ie.\n                calorie toxicity) so eat foods that are high in micronutrients.\n                Eat lots of green vegetables and dark fruits (high in\n                antioxidants).</b\n              >\n            </p>\n            <p><b>Remember one day at a time and keep it simple.</b></p>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>\n            Goal Setting (Refer to the Getting Started Guide for Goal Setting\n            Instructions)\n          </h5>\n          <p>\n            Set 1 to 3 goals to strengthen your mindset (example: commit,\n            hydrate, journal daily)\n          </p>\n          <p class=\"goal-input\">1. <input type=\"text\" /></p>\n          <p class=\"goal-input\">2. <input type=\"text\" /></p>\n          <p class=\"goal-input\">3. <input type=\"text\" /></p>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"mindset-guid\" *ngIf=\"type=='womens-guid'\">\n      <img src=\"assets/images/wnutrition.png\" />\n      <div class=\"mindset-guid-head\">\n        <h4>WOMEN’S NUTRITION PRINCIPLE</h4>\n      </div>\n      <div class=\"m-image\">\n        <img src=\"assets/images/mnutrition.png\" />\n        <!--<img src=\"assets/images/wnutrition.png\"/>-->\n      </div>\n      <div class=\"mindset-data\">\n        <div class=\"mindset-principle\">\n          <h5>Overview</h5>\n          <p>\n            Nutrition is the key component to your fitness. It is difficult to\n            train your way out of poor nutrition. Following a balanced diet is\n            essential to your success. This is a simple guide to help you\n            achieve your goals while supporting your nutritional needs for\n            health and fitness. It is important to choose foods that are\n            nutrient rich and whole, not processed and full of sugar. Nutrient\n            rich foods give your body the fuel and energy it requires to\n            accomplish your daily tasks.\n            <br />In this guide, I provide you with simple philosophies and\n            sample meal plans to get you started. Not a lecture, I empower you\n            to use this information and start making educated choices about your\n            fuel intake.\n          </p>\n          <p>\n            Remember this guide should be used as a reference for healthy eating\n            and it is recommended to consult your doctor before starting a new\n            diet. Seeing a good functional medicine health practitioner to get a\n            comprehensive assessment of micronutrients, vitamins, minerals plus\n            hormone and thyroid levels is essential to your specific health\n            needs. The more you know the better you can plan. When setting your\n            body composition goal you must first have a clear understanding of\n            where you are starting. I recommend using an impedance scale to\n            determine your body composition baseline. Regardless of the type of\n            scale you decide to use, be sure to use the same scale to keep the\n            measurement consistent.\n          </p>\n          <!-- <p><b>Here are a few ways to change your mindset:</b></p> -->\n        </div>\n        <div class=\"mindset-principle\">\n          <h5>Outline</h5>\n          <p><b>1. Understanding the ‘Nutrition Basics’.</b></p>\n          <p><b>2. Defining High and Low Days</b></p>\n          <p><b>3. Healthy Foods List</b></p>\n          <p><b>4. Foods to avoid</b></p>\n          <p><b>5. Portion Sizes / Sample Meal Plan</b></p>\n        </div>\n        <div class=\"mindset-principle\">\n          <h5>1. Nutrition Basics</h5>\n          <b>Understanding Macronutrients (Macros)</b>\n          <p>\n            <b>Proteins - </b> are essential for growth, tissue repair and is a\n            good source of energy. Protein supplies your body with amino acids\n            that are the building blocks for your cells. It has a metabolic\n            advantage and takes more energy to metabolize. It is recommended\n            that your daily consumption of protein be roughy 1 gram per pound of\n            body weight. (If you are 50 or more pounds overweight use your lean\n            body mass instead of your total bodyweight to calculate your total\n            daily protein). Found in meat, eggs, dairy, and fish.\n          </p>\n\n          <p>\n            <b>Carbohydrates (Carbs) - </b> are essential as they are the\n            preferred energy source for the body, every cell in the body can use\n            glucose (which is the breakdown form of starches and sugars) for\n            energy. Found in fruits, vegetables and grains.\n          </p>\n\n          <p>\n            <b>Fats - </b> are essential for brain function, optimal hormone\n            balance, cell growth and play an important role in metabolism. Fat\n            supplies more than twice the calories per gram of protein or carbs\n            and helps with the absorption of fat soluble vitamins throughout the\n            body plus providing energy. Nuts, seeds, oils and fish offer a\n            healthier version of monounsaturated, polyunsaturated and a few\n            saturated fats. It is best to get a wide variety of healthy fats.<br />\n            <i\n              >*A key rule is to always include a protein source with each meal\n              and adjust your fats and carbs depending on the day.</i\n            >\n          </p>\n          <b>Understanding Micronutrients (Micro’s)</b>\n          <p>\n            Vitamins, minerals, and phytonutrients are small-molecule food\n            components you need in order to support your health. Eating a well\n            balanced diet helps to insure you have all the nutrients required\n            for good health. However, our bodies are still lacking some of the\n            most important nutrients regardless of our diet. For your longevity\n            it is essential to supplement your diet with vitamins and minerals.\n          </p>\n          <p>\n            <b><i>Key Tips:</i></b>\n          </p>\n          <p>Prioritize protein with every meal</p>\n          <p>Prioritize macronutrients and micronutrients more than calories</p>\n          <p>Planning ahead is key to your success</p>\n          <p>\n            Focus on nutrient-packed vegetables, fruits, whole grains, lean\n            meats, and healthy fats\n          </p>\n          <p>Avoid high sugar and processed foods</p>\n\n          <p>\n            <b><i>Water / Hydration:</i></b>\n          </p>\n          <p>\n            Water is the most important of all nutrients for your body. It\n            assists in maintaining normal body temperature, cushions and\n            lubricates joints, protects your spinal cord, removes wastes, makes\n            up 75% of your muscles and makes up 83% of your blood. You must\n            replace the water your body loses daily through normal everyday\n            functions and when you are working out you need to replace even more\n            water that is lost during the workout through sweat.\n          </p>\n          <ion-row>\n            <ion-col>\n              <p>\n                <b><i>Key Tips:</i></b>\n              </p>\n              <p>\n                A good goal is to drink roughly 1 oz. per pound of lean body\n                weight.\n              </p>\n            </ion-col>\n            <ion-col>\n              <div class=\"water-img\">\n                <img src=\"assets/images/water.png\" />\n              </div>\n            </ion-col>\n          </ion-row>\n\n          <p>\n            Start your morning with 8oz of distilled or spring water with 3-5\n            grams of pink himalayan salt and ½ squeezed lemon.\n          </p>\n          <p>\n            Teas and diet sodas do not count towards your hydration goal.\n          </p>\n          <p>\n            Limit your drinking when eating. Drinking too much during meals can\n            lead to inefficient digestion by diluting gastric acids and enzymes.\n          </p>\n          <p>\n            Keeping track of your water consumption will really help you stay on\n            track of your hydration goals.\n          </p>\n          <p>\n            Stay hydrated!\n          </p>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>\n            2. Defining High and Low Days\n            <img\n              src=\"assets/images/arrow.png\"\n              style=\"width: 40px; margin-left: 20px;\"\n            />\n          </h5>\n          <p>\n            High and Low Days refer to the amount of calories and carbs the day\n            will have.\n          </p>\n          <p>High Day = BMR +20%.</p>\n          <p>Low Day = BMR -20%.</p>\n          <p>Refer to body assessment for BMR.</p>\n          <p>\n            One thing consistent on a High and Low Day is the amount of protein\n            and veggies that you eat. On High Days with your lean protein and\n            veggies, you will have carbs and low to no fat. On your Low Days\n            with your protein and veggies, you will have fat with low to no\n            carbs. The most important thing to remember is NO two High Days in a\n            row. Starting your week with a plan is crucial for your success.\n          </p>\n          <b>See chart below:</b>\n          <ion-row class=\"chart\">\n            <ion-col size=\"6\">Monday</ion-col>\n            <ion-col size=\"6\">High Day</ion-col>\n            <ion-col size=\"6\">Tuesday</ion-col>\n            <ion-col size=\"6\">Low Day</ion-col>\n            <ion-col size=\"6\">Wednesday</ion-col>\n            <ion-col size=\"6\">High Day</ion-col>\n            <ion-col size=\"6\">Thursday</ion-col>\n            <ion-col size=\"6\">Low Day</ion-col>\n            <ion-col size=\"6\">Friday</ion-col>\n            <ion-col size=\"6\">High Day</ion-col>\n            <ion-col size=\"6\">Saturday</ion-col>\n            <ion-col size=\"6\">Low Day</ion-col>\n            <ion-col size=\"6\">Sunday</ion-col>\n            <ion-col size=\"6\">Low Day</ion-col>\n          </ion-row>\n          <p>\n            <b>General rule of thumb:</b> Keep your fats and carbs separated.<br /><i\n              >High Carbs - Low to No Fat. High Fat - Low to No Carbs.</i\n            >\n          </p>\n          <p><b>High Day:</b></p>\n          <p>\n            Current BMR (refer to assessment) plus 20% = amount of caloric\n            intake on High days\n          </p>\n          <br />\n          <ion-row>\n            <ion-col size=\"8\">\n              <p><b>(Meal 1) - protein, carb & low fat</b></p>\n              <p><b>(Meal 2 - Meal 4) - protein, carb & veggie</b></p>\n              <p><b>(Meal 5) - protein, veggie & fat</b></p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <div _ngcontent-nhk-c134=\"\" class=\"image-veg\">\n                <img _ngcontent-nhk-c134=\"\" src=\"assets/images/veg.png\" />\n              </div>\n            </ion-col>\n          </ion-row>\n\n          <br />\n          <p><b>Macros:</b></p>\n          <p>\n            Protein: 30%<br />\n            Carb: 50%<br />\n            Fat: 20%<br />\n          </p>\n\n          <p><b>Low Day:</b></p>\n          <p>Current BMR minus 20% = amount of caloric intake on Low days</p>\n          <br />\n          <p><b>(Meal 1 - Meal 5) protein, veggie & fat</b></p>\n          <p><b>Macros:</b></p>\n          <p>\n            Protein: 45%<br />\n            Carb: 20%<br />\n            Fat: 35%<br />\n          </p>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>3. Healthy Foods List: (optimal foods)</h5>\n          <p>\n            Good sources of Protein (High & Low Day):\n          </p>\n          <br />\n\n          <p>\n            <b>Dairy:</b> kefir, goats milk, undenatured grass-fed whey protein\n          </p>\n          <p>\n            <b>Poultry:</b> chicken breast, chicken thighs, ostrich breast, duck\n            breast, turkey breast, lean ground turkey\n          </p>\n          <p>\n            <b>Red Meat:</b> beef, buffalo, elk, venison, veal (always choose\n            those lean cuts)\n          </p>\n          <p>\n            <b>Seafood:</b> wild salmon, oysters, mussels, scallops, sardines\n          </p>\n          <p><b>Vegan:</b> pea protein, rice protein, hemp protein, vegan</p>\n          <p><b>Other:</b> collagen protein, bone broth protein, whole eggs</p>\n          <br />\n          <p><b>Good food sources (Low Day):</b></p>\n          <p>\n            <b>Vegetables: </b>(grown above ground are low carb and can be eaten\n            freely - no root vegetables) spinach, lettuce, asparagus, cucumber,\n            zucchini, egg plant, olive, tomatoes, cabbage, cauliflower,\n            broccoli, kale, green bean, brussel sprout and bell pepper (red,\n            green , yellow), mushroom, celery, radish, artichokes, carrots,\n            squash, turnip greens\n          </p>\n          <p>\n            <b>Fats:</b>avocado oil, coconut oil, ghee, grass fed butter, almond\n            oil, macadamia oil, olive oil, sesame oil, palm oil, walnut oil,\n            almonds, brazil nuts, chia seeds, flax seeds, hemp seeds, hazelnuts,\n            pine nuts, pistachios, pumpkin seeds, sesame seeds, walnuts\n          </p>\n          <p><b>Sweeteners:</b> stevia in the raw, xylitol, erythritol</p>\n          <p>\n            <b>Breakfast Only:</b> granola, old-fashioned oatmeal, steel cut\n            oatmeal, cream of rice, ezekiel bread, sourdough muffins, brown rice\n            tortillas, sprouted bread, apple, grapefruit, cherries, papaya,\n            pineapple, pears, plums, pomegranate, mango, orange, blackberries,\n            blueberries, cranberries, goji berries, raspberries, strawberries,\n            acai, acerola.\n          </p>\n          <br />\n          <p><b>Good food sources: (High Day):</b></p>\n          <p>\n            <b>Bread: </b>ezekiel bread, sourdough muffins, brown rice\n            tortillas, sprouted bread\n          </p>\n          <p>\n            <b>Breakfast Cereal: </b>granola, old-fashioned oatmeal, steel cut\n            oatmeal, cream of rice\n          </p>\n          <p>\n            <b>Fruit:</b>apple, grapefruit, cherries, papaya, pineapple, pears,\n            plums, pomegranates, mango, oranges, blackberries, blueberries,\n            cranberries, goji berries, raspberries, strawberries, acai, acerola\n          </p>\n          <p>\n            <b\n              >Vegetables (grown below ground contain more carbs so be more\n              aware):</b\n            >carrots, potatoes, sweet potatoes, parsnips, rutabaga, beet root,\n            onion, spinach, lettuce, arugula, asparagus, cucumber, zucchini,\n            eggplant, olives, tomatoes, cabbage, cauliflower, broccoli, kale,\n            green bean, brussel sprout, bell pepper (red, green , yellow),\n            mushrooms, celery, radish, artichokes, carrots, squash, turnip\n            greens, bok choy, watercress, wheat grass.\n          </p>\n          <p>\n            <b>Grain:</b>couscous, quinoa, long-grain brown rice, wild rice,\n            popcorn, black rice\n          </p>\n          <p><b>Pasta:</b>brown rice pasta, whole-grain pasta</p>\n          <p><b>Legumes:</b>hummus, beans, lentils, pea</p>\n          <p>\n            <b>Fats:</b>avocado oil, coconut oil, ghee, grass fed butter, almond\n            oil, macadamia oil, olive oil, sesame oil, palm oil, walnut oil,\n            almonds, brazil nuts, chia seeds, flax seeds, hemp seeds, hazelnuts,\n            pine nuts, pistachios, pumpkin seeds, sesame seeds, walnuts,\n            macadamia, pecans, nut butters, seed butters\n          </p>\n          <p>\n            <b>Sweeteners:</b>stevia in the raw, xylitol, erythritol, raw honey,\n            monkfruit, organic coconut sugar\n          </p>\n        </div>\n        <div class=\"mindset-principle\">\n          <h5>\n            4. Foods to Avoid:\n            <img\n              src=\"assets/images/avoid.png\"\n              style=\"width: 30px; margin-left: 20px;\"\n            />\n          </h5>\n          <p>\n            <b>Avoid sugar </b>(especially added sugar and high fructose corn\n            syrup - HFCS) and artificial sweeteners (other than a natural\n            sweetener like stevia).\n          </p>\n          <p>\n            <b>Highly processed foods - </b>any food in a can or package. Any\n            GMO foods (all soy and corn).\n          </p>\n          <p>\n            <b>Refined Carbohydrates -</b>white bread, pastries, white flour,\n            white sugar, HFSC, white pasta, cane sugar, evaporated cane juice,\n            chips, snack crackers, snack cookies, etc...\n          </p>\n          <p>\n            <b>Fried Foods - </b> fried meats, chips, french fries, onion rings,\n            tempura, etc...\n          </p>\n          <p>\n            <b>Processed Meats - </b>hotdogs, packaged sausage, packaged lunch\n            meats, pork, jerky, etc…\n          </p>\n          <p>\n            <b>Seafood - </b>tuna, swordfish, shellfish, crawfish, tilapia (all\n            farm raised fish) (most restaurants are typically farm raised)\n          </p>\n          <p>\n            <b>Unhealthy Oils and Fats -</b>hydrogenated oils (trans fats),\n            soybean oil, canola oil, peanuts\n          </p>\n          <p>\n            <b>Sugary Drinks - </b>sodas, juices with high fructose corn syrup.\n          </p>\n        </div>\n        <!--  -->\n        <div class=\"mindset-principle\">\n          <h5>\n            5. Portion Sizes / Sample Meal Plan\n          </h5>\n          <p><b>Portion Sizes</b></p>\n          <div class=\"portion-size-outer\">\n            <div class=\"portion-size-container\">\n              <div class=\"portion-image-container\">\n                <img src=\"assets/images/hand.png\" />\n              </div>\n              <div class=\"portion-text-container\">\n                <p><b>Palm - </b> (3-4 oz) protein (meats, fish, eggs etc)</p>\n              </div>\n            </div>\n\n            <div class=\"portion-size-container\">\n              <div class=\"portion-image-container\">\n                <img src=\"assets/images/fist1.png\" />\n              </div>\n              <div class=\"portion-text-container\">\n                <p><b>Fist - </b> (1 cup) vegetable</p>\n              </div>\n            </div>\n\n            <div class=\"portion-size-container\">\n              <div class=\"portion-image-container\">\n                <img src=\"assets/images/cupped.png\" />\n              </div>\n              <div class=\"portion-text-container\">\n                <p>\n                  <b>Cupped hand - </b> (½ cup) carbs (grains, starches and\n                  fruits)\n                </p>\n              </div>\n            </div>\n\n            <div class=\"portion-size-container\">\n              <div class=\"portion-image-container\">\n                <img src=\"assets/images/thumb-hand.png\" />\n              </div>\n              <div class=\"portion-text-container\">\n                <p>\n                  <b>Thumb - </b> (1-2 TBSP or ⅛ cup) fats (nut butter, nuts,\n                  oils, cheese)\n                </p>\n              </div>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <div class=\"sample-size-container\">\n            <div class=\"sample-text-container\">\n              <p><b>Sample Meal Plan 1 </b></p>\n            </div>\n            <div class=\"sample-image-container\">\n              <img src=\"assets/images/sample-meal-1.png\" />\n            </div>\n          </div>\n          <div>\n            <p>\n              <b><i>Women’s Sample High Day</i></b>\n            </p>\n\n            <div>\n              <p><b>Meal 1 -</b></p>\n              <p>1 palm eggs & lean turkey sausage (18-24 gram)</p>\n              <p>1 fists spinach</p>\n              <p>1 cupped hands blueberries</p>\n              <p>2 cupped hands oatmeal</p>\n            </div>\n\n            <div>\n              <p><b>Meal 2 -</b></p>\n              <p>1 Protein Shake (18-24 grams)</p>\n              <p>1 cupped hand Old Fashioned Oats or mixed berries</p>\n              <p>8 oz unsweetened vanilla almond milk or water</p>\n            </div>\n\n            <div>\n              <p><b>Meal 3 -</b></p>\n              <p>1 palm chicken breast (18-24 grams)</p>\n              <p>2 cupped hand Sweet Potato</p>\n              <p>fist Mixed Salad with lots of veggies</p>\n            </div>\n\n            <div>\n              <p><b>Meal 4 -</b></p>\n              <p>1 Protein Shake (18-24 grams)</p>\n              <p>1 cupped hand Old Fashioned Oats or mixed berries</p>\n              <p>8 oz unsweetened vanilla almond milk or water</p>\n            </div>\n\n            <div>\n              <p><b>Meal 5 -</b></p>\n              <p>1 palm turkey meatloaf (18-24 gram)</p>\n              <p>1 fist green veggies</p>\n              <p>1 thumb avocado</p>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <div class=\"sample-size-container\">\n            <div class=\"sample-text-container\">\n              <p><b>Sample Meal Plan 2 </b></p>\n            </div>\n            <div class=\"sample-image-container\">\n              <img src=\"assets/images/sample-meal-2.png\" />\n            </div>\n          </div>\n          <div>\n            <p>\n              <b><i>Women’s Sample Low Day</i></b>\n            </p>\n\n            <div>\n              <p><b>Meal 1 -</b></p>\n              <p>\n                1 palm eggs & lean turkey sausage (18-24 gram)\n              </p>\n              <p>1 cupped hand mixed fruit</p>\n              <p>1 cupped hand oatmeal</p>\n            </div>\n\n            <div>\n              <p><b>Meal 2 -</b></p>\n              <p>1 Protein Shake (18-24 gram)</p>\n              <p>8 oz unsweetened vanilla almond milk or water</p>\n              <p><b>OR</b></p>\n              <p>1 palm eggs & bacon (18-24 gram)</p>\n              <p>1 fist asparagus</p>\n              <p>1 thumb avocado</p>\n            </div>\n\n            <div>\n              <p><b>Meal 3 -</b></p>\n              <p>1 palm chicken breast (18-24 gram)</p>\n              <p>1 fist of mixed veggies</p>\n              <p>1 thumb sunflower seeds</p>\n              <p>1 thumb olive oil</p>\n            </div>\n\n            <div>\n              <p><b>Meal 4 -</b></p>\n              <p>1 Protein Shake (18-24 gram)</p>\n              <p>1 thumb almond butter</p>\n              <p>8 oz unsweetened vanilla almond milk or water</p>\n              <p><b>OR</b></p>\n              <p>1 palm chicken breast (18-24 gram)</p>\n              <p>1 fist of mixed veggies</p>\n              <p>1 thumb sunflower seeds</p>\n              <p>1 thumb olive oil</p>\n            </div>\n\n            <div>\n              <p><b>Meal 5 -</b></p>\n              <p>1 palm turkey meatloaf (18-24 gram)</p>\n              <p>1 fist green veggies</p>\n              <p>1 thumb avocado</p>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>Helpful Tips:</h5>\n          <div>\n            <p>\n              <b\n                >Update your assessment (bi-weekly) and measurements (every 30\n                days) and see how you are progressing then make adjustments\n                where you need to.</b\n              >\n            </p>\n            <p>\n              <b\n                >Commit to following the plan for 2 weeks before making\n                adjustments. Stay connected consciously and aware of how you are\n                feeling.</b\n              >\n            </p>\n            <p>\n              <b\n                >Cravings are typically created from nutrient deficiencies (ie.\n                calorie toxicity) so eat foods that are high in micronutrients.\n                Eat lots of green vegetables and dark fruits (high in\n                antioxidants).</b\n              >\n            </p>\n            <p><b>Remember one day at a time and keep it simple.</b></p>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>\n            Goal Setting (Refer to the Getting Started Guide for Goal Setting\n            Instructions)\n          </h5>\n          <p>\n            Set 1 to 3 goals to strengthen your mindset (example: commit,\n            hydrate, journal daily)\n          </p>\n          <p class=\"goal-input\">1. <input type=\"text\" /></p>\n          <p class=\"goal-input\">2. <input type=\"text\" /></p>\n          <p class=\"goal-input\">3. <input type=\"text\" /></p>\n        </div>\n      </div>\n    </div>\n\n    <div *ngIf=\"type=='videos' && nutritiontArray.length>0\">\n      <div class=\"content\" *ngFor=\"let nutritions of nutritiontArray\">\n        <ng-controller (click)=\"detail(nutritions, 'nutrition')\">\n        <div class=\"img-box\">\n          <iframe  *ngIf=\"nutritions?.trustedVideoUrl!= null \" style= \"z-index:999\" height=\"200px\" width=\"100%\" preload=\"none\" target=\"_parent\"  [src]=\"nutritions?.trustedVideoUrl\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\n\n          <!-- <img src=\"assets/images/n1.png\" /> -->\n          <ion-icon name=\"eye-outline\"></ion-icon>\n        </div>\n        <h5>{{nutritions.title}}:</h5>\n        <p>\n         {{nutritions.description}}\n        </p>\n        </ng-controller>\n      </div>\n      <!-- <div class=\"content\">\n        <div class=\"img-box\">\n          <img src=\"assets/images/n1.png\" />\n          <ion-icon name=\"eye-outline\"></ion-icon>\n        </div>\n        <h5>SPEED RECOVERY:</h5>\n        <p>\n          Neque porro quisquam est qui dolorem ipsum quia dolor sit amet,\n          consectetur, adipisci velit. Neque porro quisquam est qui dolorem\n          ipsum quia dolor sit amet, consectetur, adipisci velit.\n        </p>\n      </div> -->\n    </div>\n    <div *ngIf=\"nutritiontArray.length == 0\">\n      <p class=\"no-data\">No Record Found</p>  \n      </div>\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/nutrition/nutrition-routing.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/nutrition/nutrition-routing.module.ts ***!
    \*******************************************************/

  /*! exports provided: NutritionPageRoutingModule */

  /***/
  function srcAppNutritionNutritionRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NutritionPageRoutingModule", function () {
      return NutritionPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _nutrition_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./nutrition.page */
    "./src/app/nutrition/nutrition.page.ts");

    var routes = [{
      path: '',
      component: _nutrition_page__WEBPACK_IMPORTED_MODULE_3__["NutritionPage"]
    }];

    var NutritionPageRoutingModule = function NutritionPageRoutingModule() {
      _classCallCheck(this, NutritionPageRoutingModule);
    };

    NutritionPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], NutritionPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/nutrition/nutrition.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/nutrition/nutrition.module.ts ***!
    \***********************************************/

  /*! exports provided: NutritionPageModule */

  /***/
  function srcAppNutritionNutritionModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NutritionPageModule", function () {
      return NutritionPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _nutrition_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./nutrition-routing.module */
    "./src/app/nutrition/nutrition-routing.module.ts");
    /* harmony import */


    var _nutrition_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./nutrition.page */
    "./src/app/nutrition/nutrition.page.ts");

    var NutritionPageModule = function NutritionPageModule() {
      _classCallCheck(this, NutritionPageModule);
    };

    NutritionPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _nutrition_routing_module__WEBPACK_IMPORTED_MODULE_5__["NutritionPageRoutingModule"]],
      declarations: [_nutrition_page__WEBPACK_IMPORTED_MODULE_6__["NutritionPage"]]
    })], NutritionPageModule);
    /***/
  },

  /***/
  "./src/app/nutrition/nutrition.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/nutrition/nutrition.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppNutritionNutritionPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 50px;\n  letter-spacing: 1px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n  margin-right: 10px;\n}\n.header .search {\n  text-align: right;\n  float: right;\n  color: #fff;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\nion-content {\n  font-family: Rajdhani-Regular;\n}\nion-content p {\n  text-align: justify;\n}\n.mindset-guid-head {\n  padding: 0px 16px;\n  background: #e7863d;\n  color: #fff;\n  background-image: url('heading-bg.png');\n  width: 100%;\n  background-position: center;\n}\n.mindset-guid-head h4 {\n  padding: 5px 0px;\n}\n.m-image {\n  padding: 20px;\n}\n.mindset-data {\n  padding: 16px;\n}\n.mindset-data .mindset-principle h5 {\n  font-size: 20px;\n  font-weight: 600;\n  color: #e7863d;\n}\np.goal-input input {\n  width: 90%;\n  margin-left: 10px;\n  border: none;\n  outline: none;\n}\np.goal-input {\n  border-bottom: 1px solid #000;\n}\n.chart {\n  border-bottom: 1px solid #000;\n}\n.chart ion-col:nth-child(even) {\n  border-top: 1px solid #000;\n  border-right: 1px solid #000;\n}\n.chart ion-col:nth-child(odd) {\n  border-top: 1px solid #000;\n  border-right: 1px solid #000;\n  border-left: 1px solid #000;\n}\n.portion-image-container {\n  width: 20%;\n  display: inline-block;\n}\n.portion-text-container {\n  width: 75%;\n  display: inline-block;\n  margin-left: 10px;\n  vertical-align: top;\n}\n.sample-size-container {\n  background: #eb9a5d;\n  color: #fff;\n  height: 100px;\n}\n.sample-text-container {\n  width: 40%;\n  display: inline-block;\n  height: 100px;\n  vertical-align: middle;\n  padding: 0px 10px;\n}\n.sample-text-container p {\n  margin: 0px;\n}\n.sample-image-container {\n  width: 60%;\n  display: inline-block;\n  height: 100px;\n}\n.sample-image-container img {\n  width: 100%;\n  height: 100px;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n/* ****************************** */\n.mindset .content {\n  padding: 20px;\n  border-bottom: 1px solid #ddd;\n}\n.mindset .content .img-box {\n  position: relative;\n  width: 100%;\n}\n.mindset .content .img-box img {\n  position: relative;\n  width: 100%;\n}\n.mindset .content .img-box ion-icon {\n  position: absolute;\n  bottom: 4px;\n  background: #f77e21bf;\n  color: #fff;\n  width: 100%;\n  left: 0;\n  right: 0;\n  padding: 5px 0;\n  border-radius: 0px 0px 10px 10px;\n}\n.mindset .content h5 {\n  font-family: Rajdhani-Bold;\n  letter-spacing: 1px;\n  font-size: 24px;\n  margin-top: 10px;\n}\n.mindset .content p {\n  font-family: Rajdhani-Regular;\n  color: #858585;\n  letter-spacing: 1px;\n  font-size: 17px;\n  line-height: 24px;\n  margin-top: 10px;\n  text-align: justify;\n}\n.mindset .no-data {\n  text-align: center;\n  font-size: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL251dHJpdGlvbi9udXRyaXRpb24ucGFnZS5zY3NzIiwic3JjL2FwcC9udXRyaXRpb24vbnV0cml0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FDQ0Y7QURFRTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0FKO0FERUU7RUFDRSxXQUFBO0FDQUo7QURFRTtFQUNFLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ0FKO0FERUU7RUFDRSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FDQUo7QURFRTtFQUNFLFlBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxXQUFBO0FDQUo7QURJQTtFQUNFLDZCQUFBO0FDREY7QURFRTtFQUNFLG1CQUFBO0FDQUo7QURJQTtFQUNFLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsdUNBQUE7RUFDQSxXQUFBO0VBQ0EsMkJBQUE7QUNERjtBREVFO0VBQ0UsZ0JBQUE7QUNBSjtBREdBO0VBQ0UsYUFBQTtBQ0FGO0FERUE7RUFDRSxhQUFBO0FDQ0Y7QURFSTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNBTjtBREtBO0VBQ0UsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNGRjtBREtBO0VBQ0UsNkJBQUE7QUNGRjtBRElBO0VBQ0ksNkJBQUE7QUNESjtBREVJO0VBQ0ksMEJBQUE7RUFDQSw0QkFBQTtBQ0FSO0FER0k7RUFDSSwwQkFBQTtFQUNBLDRCQUFBO0VBQ0EsMkJBQUE7QUNEUjtBREtBO0VBQ0ksVUFBQTtFQUNBLHFCQUFBO0FDRko7QURLQTtFQUNJLFVBQUE7RUFDQSxxQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUNGSjtBREtBO0VBQ0UsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtBQ0ZGO0FETUE7RUFDSSxVQUFBO0VBQ0EscUJBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtBQ0hKO0FESUk7RUFDRSxXQUFBO0FDRk47QURNQTtFQUNJLFVBQUE7RUFDQSxxQkFBQTtFQUNBLGFBQUE7QUNISjtBRElJO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FDRk47QURNQSxtQ0FBQTtBQUlFO0VBQ0UsYUFBQTtFQUNBLDZCQUFBO0FDTko7QURPSTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtBQ0xOO0FETU07RUFDRSxrQkFBQTtFQUNBLFdBQUE7QUNKUjtBRE1NO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsY0FBQTtFQUNBLGdDQUFBO0FDSlI7QURPSTtFQUNFLDBCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNMTjtBRE9JO0VBQ0UsNkJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDTE47QURRRTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtBQ05KIiwiZmlsZSI6InNyYy9hcHAvbnV0cml0aW9uL251dHJpdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbiAgLy9wYWRkaW5nOiAgMTZweDtcblxuICBpb24tdGl0bGUge1xuICAgIHBhZGRpbmc6IDBweDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgIHBhZGRpbmctbGVmdDogNTBweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICB9XG4gIGlvbi1tZW51LWJ1dHRvbiB7XG4gICAgY29sb3I6ICNmZmY7XG4gIH1cbiAgaW9uLWljb24ge1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgfVxuICAuc2VhcmNoIHtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgY29sb3I6ICNmZmY7XG4gIH1cbiAgcCB7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGNvbG9yOiAjZjc3ZTIxO1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgIG1hcmdpbjogMGVtO1xuICB9XG59XG5cbmlvbi1jb250ZW50IHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIHB7XG4gICAgdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgfVxufVxuXG4ubWluZHNldC1ndWlkLWhlYWQge1xuICBwYWRkaW5nOiAwcHggMTZweDtcbiAgYmFja2dyb3VuZDogI2U3ODYzZDtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtaW1hZ2U6dXJsKC4uLy4uL2Fzc2V0cy9pbWFnZXMvaGVhZGluZy1iZy5wbmcpO1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBoNCB7XG4gICAgcGFkZGluZzogNXB4IDBweDtcbiAgfVxufVxuLm0taW1hZ2V7XG4gIHBhZGRpbmc6MjBweDtcbn1cbi5taW5kc2V0LWRhdGEge1xuICBwYWRkaW5nOiAxNnB4O1xuXG4gIC5taW5kc2V0LXByaW5jaXBsZSB7XG4gICAgaDUge1xuICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgIGNvbG9yOiAjZTc4NjNkO1xuICAgIH1cbiAgfVxufVxuXG5wLmdvYWwtaW5wdXQgaW5wdXQge1xuICB3aWR0aDogOTAlO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG5wLmdvYWwtaW5wdXQge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzAwMDtcbn1cbi5jaGFydCB7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMwMDA7XG4gICAgaW9uLWNvbDpudGgtY2hpbGQoZXZlbikge1xuICAgICAgICBib3JkZXItdG9wOiAxcHggc29saWQgIzAwMDtcbiAgICAgICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgIzAwMDtcbiAgICB9XG5cbiAgICBpb24tY29sOm50aC1jaGlsZChvZGQpIHtcbiAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICMwMDA7XG4gICAgICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICMwMDA7XG4gICAgICAgIGJvcmRlci1sZWZ0OiAxcHggc29saWQgIzAwMDtcbiAgICB9XG59XG5cbi5wb3J0aW9uLWltYWdlLWNvbnRhaW5lciB7XG4gICAgd2lkdGg6IDIwJTtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG5cbi5wb3J0aW9uLXRleHQtY29udGFpbmVyIHtcbiAgICB3aWR0aDogNzUlO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xufVxuXG4uc2FtcGxlLXNpemUtY29udGFpbmVyIHtcbiAgYmFja2dyb3VuZDogI2ViOWE1ZDtcbiAgY29sb3I6ICNmZmY7XG4gIGhlaWdodDogMTAwcHg7XG59XG5cblxuLnNhbXBsZS10ZXh0LWNvbnRhaW5lciB7XG4gICAgd2lkdGg6IDQwJTtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgIHBhZGRpbmc6IDBweCAxMHB4O1xuICAgIHAge1xuICAgICAgbWFyZ2luOiAwcHg7XG4gICAgfVxufVxuXG4uc2FtcGxlLWltYWdlLWNvbnRhaW5lciB7XG4gICAgd2lkdGg6IDYwJTtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgICBpbWcge1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICBoZWlnaHQ6IDEwMHB4O1xuICAgICAgb2JqZWN0LWZpdDogY292ZXI7XG4gICAgfVxufVxuXG4vKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogKi9cblxuXG4ubWluZHNldCB7XG4gIC5jb250ZW50IHtcbiAgICBwYWRkaW5nOiAyMHB4O1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZGRkO1xuICAgIC5pbWctYm94IHtcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgaW1nIHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgIH1cbiAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBib3R0b206IDRweDtcbiAgICAgICAgYmFja2dyb3VuZDogI2Y3N2UyMWJmO1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGxlZnQ6IDA7XG4gICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICBwYWRkaW5nOiA1cHggMDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMHB4IDBweCAxMHB4IDEwcHg7XG4gICAgICB9XG4gICAgfVxuICAgIGg1IHtcbiAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgfVxuICAgIHAge1xuICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgICBjb2xvcjogIzg1ODU4NTtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gICAgICBmb250LXNpemU6IDE3cHg7XG4gICAgICBsaW5lLWhlaWdodDogMjRweDtcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICAgIH1cbiAgfVxuICAubm8tZGF0YXtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAyMHB4O1xufVxufVxuIiwiLmhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi10aXRsZSB7XG4gIHBhZGRpbmc6IDBweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIHBhZGRpbmctbGVmdDogNTBweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbn1cbi5oZWFkZXIgaW9uLW1lbnUtYnV0dG9uIHtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi1pY29uIHtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLmhlYWRlciAuc2VhcmNoIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIHAge1xuICBmbG9hdDogcmlnaHQ7XG4gIGNvbG9yOiAjZjc3ZTIxO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgbWFyZ2luOiAwZW07XG59XG5cbmlvbi1jb250ZW50IHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG59XG5pb24tY29udGVudCBwIHtcbiAgdGV4dC1hbGlnbjoganVzdGlmeTtcbn1cblxuLm1pbmRzZXQtZ3VpZC1oZWFkIHtcbiAgcGFkZGluZzogMHB4IDE2cHg7XG4gIGJhY2tncm91bmQ6ICNlNzg2M2Q7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vLi4vYXNzZXRzL2ltYWdlcy9oZWFkaW5nLWJnLnBuZyk7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG59XG4ubWluZHNldC1ndWlkLWhlYWQgaDQge1xuICBwYWRkaW5nOiA1cHggMHB4O1xufVxuXG4ubS1pbWFnZSB7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG5cbi5taW5kc2V0LWRhdGEge1xuICBwYWRkaW5nOiAxNnB4O1xufVxuLm1pbmRzZXQtZGF0YSAubWluZHNldC1wcmluY2lwbGUgaDUge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGNvbG9yOiAjZTc4NjNkO1xufVxuXG5wLmdvYWwtaW5wdXQgaW5wdXQge1xuICB3aWR0aDogOTAlO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG5wLmdvYWwtaW5wdXQge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzAwMDtcbn1cblxuLmNoYXJ0IHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMwMDA7XG59XG4uY2hhcnQgaW9uLWNvbDpudGgtY2hpbGQoZXZlbikge1xuICBib3JkZXItdG9wOiAxcHggc29saWQgIzAwMDtcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgIzAwMDtcbn1cbi5jaGFydCBpb24tY29sOm50aC1jaGlsZChvZGQpIHtcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICMwMDA7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICMwMDA7XG4gIGJvcmRlci1sZWZ0OiAxcHggc29saWQgIzAwMDtcbn1cblxuLnBvcnRpb24taW1hZ2UtY29udGFpbmVyIHtcbiAgd2lkdGg6IDIwJTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4ucG9ydGlvbi10ZXh0LWNvbnRhaW5lciB7XG4gIHdpZHRoOiA3NSU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIHZlcnRpY2FsLWFsaWduOiB0b3A7XG59XG5cbi5zYW1wbGUtc2l6ZS1jb250YWluZXIge1xuICBiYWNrZ3JvdW5kOiAjZWI5YTVkO1xuICBjb2xvcjogI2ZmZjtcbiAgaGVpZ2h0OiAxMDBweDtcbn1cblxuLnNhbXBsZS10ZXh0LWNvbnRhaW5lciB7XG4gIHdpZHRoOiA0MCU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgaGVpZ2h0OiAxMDBweDtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgcGFkZGluZzogMHB4IDEwcHg7XG59XG4uc2FtcGxlLXRleHQtY29udGFpbmVyIHAge1xuICBtYXJnaW46IDBweDtcbn1cblxuLnNhbXBsZS1pbWFnZS1jb250YWluZXIge1xuICB3aWR0aDogNjAlO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGhlaWdodDogMTAwcHg7XG59XG4uc2FtcGxlLWltYWdlLWNvbnRhaW5lciBpbWcge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG59XG5cbi8qICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xuLm1pbmRzZXQgLmNvbnRlbnQge1xuICBwYWRkaW5nOiAyMHB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2RkZDtcbn1cbi5taW5kc2V0IC5jb250ZW50IC5pbWctYm94IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogMTAwJTtcbn1cbi5taW5kc2V0IC5jb250ZW50IC5pbWctYm94IGltZyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgd2lkdGg6IDEwMCU7XG59XG4ubWluZHNldCAuY29udGVudCAuaW1nLWJveCBpb24taWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiA0cHg7XG4gIGJhY2tncm91bmQ6ICNmNzdlMjFiZjtcbiAgY29sb3I6ICNmZmY7XG4gIHdpZHRoOiAxMDAlO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgcGFkZGluZzogNXB4IDA7XG4gIGJvcmRlci1yYWRpdXM6IDBweCAwcHggMTBweCAxMHB4O1xufVxuLm1pbmRzZXQgLmNvbnRlbnQgaDUge1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgZm9udC1zaXplOiAyNHB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuLm1pbmRzZXQgLmNvbnRlbnQgcCB7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBjb2xvcjogIzg1ODU4NTtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBsaW5lLWhlaWdodDogMjRweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgdGV4dC1hbGlnbjoganVzdGlmeTtcbn1cbi5taW5kc2V0IC5uby1kYXRhIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDIwcHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/nutrition/nutrition.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/nutrition/nutrition.page.ts ***!
    \*********************************************/

  /*! exports provided: NutritionPage */

  /***/
  function srcAppNutritionNutritionPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NutritionPage", function () {
      return NutritionPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _search_exercises_search_exercises_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ..//search-exercises/search-exercises.page */
    "./src/app/search-exercises/search-exercises.page.ts");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
    /* harmony import */


    var _detailspirit_detailspirit_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../detailspirit/detailspirit.page */
    "./src/app/detailspirit/detailspirit.page.ts");

    var NutritionPage = /*#__PURE__*/function () {
      function NutritionPage(modalController, sanitizer, navCtrl, router, route) {
        var _this = this;

        _classCallCheck(this, NutritionPage);

        this.modalController = modalController;
        this.sanitizer = sanitizer;
        this.navCtrl = navCtrl;
        this.router = router;
        this.route = route;
        this.nutritiontData = [];
        this.nutritiontArray = [];
        this.type = 'mens-guid';
        this.toggled = false;
        this.searchTerm = '';
        this.route.queryParams.subscribe(function (params) {
          _this.type = params["type"];

          if (_this.type == 'videos') {
            _this.nutritiontData = [{
              'id': 1,
              'title': 'Endurance Atheletes',
              url: "https://www.youtube.com/watch?v=mUns8O4YL5M",
              'image': 'assets/images/n1.png',
              'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
            }, {
              'id': 2,
              'title': 'Speed Recovery',
              url: "https://www.youtube.com/watch?v=jZK1m2G1nyQ",
              'image': 'assets/images/n1.png',
              'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
            }];
            var that = _this;
            _this.nutritiontArray = [];

            _this.nutritiontData.forEach(function (element) {
              if (element.url != null) {
                var url = that.validateYouTubeUrl(element.url);
                console.log("url:- ", url);
                var pos = element.url.indexOf("watch");
                console.log(pos);

                if (pos !== -1) {
                  element.url = element.url.replace("watch?v=", "embed/");
                } else {
                  var _pos = element.url.indexOf("youtu.be"); // 0


                  if (_pos !== -1) {
                    element.url.replace("youtu.be", "www.youtube.com/embed/" + url.vidId);
                  } else {
                    element.url;
                  }
                }

                console.log("element:-----", element.url);
                element["trustedVideoUrl"] = _this.sanitizer.bypassSecurityTrustResourceUrl(element.url);
                console.log("ooooo", element);
              }

              _this.nutritiontArray.push(element);

              console.log(_this.nutritiontArray);
            });
          }
        });
      }

      _createClass(NutritionPage, [{
        key: "search",
        value: function search() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var modal;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.modalController.create({
                      component: _search_exercises_search_exercises_page__WEBPACK_IMPORTED_MODULE_4__["SearchExercisesPage"]
                    });

                  case 2:
                    modal = _context.sent;
                    _context.next = 5;
                    return modal.present();

                  case 5:
                    return _context.abrupt("return", _context.sent);

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "showDefaultBar",
        value: function showDefaultBar() {
          if (this.toggled) {
            this.toggled = false;
          } else {
            this.toggled = true;
          }
        }
      }, {
        key: "clearData",
        value: function clearData() {
          this.searchTerm = '';
        }
      }, {
        key: "validateYouTubeUrl",
        value: function validateYouTubeUrl(element) {
          if (element !== undefined || element !== "") {
            console.log("URL-->", element);
            var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|\?v=)([^#\&\?]*).*/;
            var match = element.match(regExp);

            if (match && match[2].length === 11) {
              console.log("MATCH YOUTUBE", match[2]);
              return {
                type: "youtube",
                vidId: match[2]
              };
            } else {
              return {
                type: "video"
              };
            }
          }
        }
      }, {
        key: "detail",
        value: function detail(data, type) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var value_type, modal;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    if (!type) {
                      value_type = '';
                    } else {
                      value_type = type;
                    }

                    _context2.next = 3;
                    return this.modalController.create({
                      component: _detailspirit_detailspirit_page__WEBPACK_IMPORTED_MODULE_6__["DetailspiritPage"],
                      componentProps: {
                        data: data,
                        type: value_type
                      }
                    });

                  case 3:
                    modal = _context2.sent;
                    _context2.next = 6;
                    return modal.present();

                  case 6:
                    return _context2.abrupt("return", _context2.sent);

                  case 7:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "onSearchChange",
        value: function onSearchChange() {
          var _this2 = this;

          this.nutritiontArray = [];
          console.log(this.searchTerm);
          this.nutritiontData.filter(function (element, key) {
            if (element.title && _this2.searchTerm != '') {
              console.log(element.title.toLowerCase().indexOf(_this2.searchTerm.toLowerCase())); // return (element.title.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);

              if (element.title.toLowerCase().indexOf(_this2.searchTerm.toLowerCase()) > -1) {
                _this2.nutritiontArray.push(element);
              }
            }
          });
          console.log(this.nutritiontArray);

          if (this.searchTerm == '') {
            this.nutritiontData = [{
              'id': 1,
              'title': 'Endurance Atheletes',
              url: "https://www.youtube.com/watch?v=mUns8O4YL5M",
              'image': 'assets/images/n1.png',
              'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
            }, {
              'id': 2,
              'title': 'Speed Recovery',
              url: "https://www.youtube.com/watch?v=jZK1m2G1nyQ",
              'image': 'assets/images/n1.png',
              'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
            }];
            var that = this;
            this.nutritiontArray = [];
            this.nutritiontData.forEach(function (element) {
              if (element.url != null) {
                var url = that.validateYouTubeUrl(element.url);
                console.log("url:- ", url);
                var pos = element.url.indexOf("watch");
                console.log(pos);

                if (pos !== -1) {
                  element.url = element.url.replace("watch?v=", "embed/");
                } else {
                  var _pos2 = element.url.indexOf("youtu.be"); // 0


                  if (_pos2 !== -1) {
                    element.url.replace("youtu.be", "www.youtube.com/embed/" + url.vidId);
                  } else {
                    element.url;
                  }
                }

                console.log("element:-----", element.url);
                element["trustedVideoUrl"] = _this2.sanitizer.bypassSecurityTrustResourceUrl(element.url);
                console.log("ooooo", element);
              }

              _this2.nutritiontArray.push(element);

              console.log(_this2.nutritiontArray);
            });
          }
        }
      }]);

      return NutritionPage;
    }();

    NutritionPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["DomSanitizer"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }];
    };

    NutritionPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-nutrition',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./nutrition.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/nutrition/nutrition.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./nutrition.page.scss */
      "./src/app/nutrition/nutrition.page.scss"))["default"]]
    })], NutritionPage);
    /***/
  }
}]);
//# sourceMappingURL=nutrition-nutrition-module-es5.js.map