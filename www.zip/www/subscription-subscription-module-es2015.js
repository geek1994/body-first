(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["subscription-subscription-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/subscription/subscription.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/subscription/subscription.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\" text=\"\" icon=\"chevron-back-outline\" ></ion-back-button>\n    </ion-buttons>\n    <ion-title>SUBSCRIPTION</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"plan\">\n    <div class=\"plan-video\">\n      <img src=\"assets/images/plan.png\">\n    </div>\n  </div>\n  <div class=\"tabs\">\n    <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck1\" checked>\n      <label class=\"tab-label\" for=\"chck1\">Apple Pay</label>\n      <div class=\"tab-content\">\n        <ion-row>\n          <ion-col size=\"2\">\n            <img src=\"assets/images/profile-img.png\"/>\n          </ion-col>\n          <ion-col size=\"6\">\n            <h4>1 Month Premium</h4>\n            <p>BODYFIRST </p>\n            <P>Fitness Coach Plans</P>\n          </ion-col>\n          <ion-col size=\"4\">\n            <h5>₹ 600.00/1month</h5>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n    <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck2\" >\n      <label class=\"tab-label\" for=\"chck2\"><img src=\"assets/images/apple.png\"> Visa-5175</label>\n      <div class=\"tab-content\">\n        \n      </div>\n    </div>\n    <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck3\" checked>\n      <label class=\"tab-label\" for=\"chck3\">Cancel anytime in Subscription in Apple Pay</label>\n      <div class=\"tab-content\">\n        <p>You will be charged    600.00  automatically 1 \n          month untill you cancel. Learn how to cancel.</p>\n      </div>\n    </div>\n  </div>\n<div class=\"bottom-btn\">\n  <ion-button class=\"subscribe-btn\">SUBSCRIBE</ion-button>\n</div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/subscription/subscription-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/subscription/subscription-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: SubscriptionPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscriptionPageRoutingModule", function() { return SubscriptionPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _subscription_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./subscription.page */ "./src/app/subscription/subscription.page.ts");




const routes = [
    {
        path: '',
        component: _subscription_page__WEBPACK_IMPORTED_MODULE_3__["SubscriptionPage"]
    }
];
let SubscriptionPageRoutingModule = class SubscriptionPageRoutingModule {
};
SubscriptionPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SubscriptionPageRoutingModule);



/***/ }),

/***/ "./src/app/subscription/subscription.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/subscription/subscription.module.ts ***!
  \*****************************************************/
/*! exports provided: SubscriptionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscriptionPageModule", function() { return SubscriptionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _subscription_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./subscription-routing.module */ "./src/app/subscription/subscription-routing.module.ts");
/* harmony import */ var _subscription_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./subscription.page */ "./src/app/subscription/subscription.page.ts");







let SubscriptionPageModule = class SubscriptionPageModule {
};
SubscriptionPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _subscription_routing_module__WEBPACK_IMPORTED_MODULE_5__["SubscriptionPageRoutingModule"]
        ],
        declarations: [_subscription_page__WEBPACK_IMPORTED_MODULE_6__["SubscriptionPage"]]
    })
], SubscriptionPageModule);



/***/ }),

/***/ "./src/app/subscription/subscription.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/subscription/subscription.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@charset \"UTF-8\";\n.header {\n  --background:#233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 42px;\n  letter-spacing: 1px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n  margin: 5px;\n  margin-right: 10px;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\n.header ion-back-button {\n  font-size: 12px;\n}\n.plan-video {\n  text-align: center;\n  position: relative;\n}\n.plan-video img {\n  position: relative;\n  width: 100%;\n}\n.tabs {\n  border-radius: 8px;\n  overflow: hidden;\n}\n.tab {\n  width: 100%;\n  color: white;\n  overflow: hidden;\n  position: relative;\n}\n.tab-label {\n  display: flex;\n  border-bottom: 1px solid #dddddd;\n  justify-content: space-between;\n  background: #fff;\n  margin-bottom: 10px;\n  padding: 0.8rem;\n  font-size: 15px;\n  letter-spacing: 1px;\n  font-weight: bold;\n  cursor: pointer;\n  color: #222;\n  font-family: Rajdhani-Regular;\n  /* Icon */\n}\n.tab-label::after {\n  content: \"❯\";\n  width: 1em;\n  height: 1em;\n  text-align: center;\n  transition: all 0.35s;\n}\n.tab-content {\n  max-height: 0;\n  padding: 0 1em;\n  color: #2c3e50;\n  font-family: Rajdhani-Regular;\n  font-size: 14px;\n  background: white;\n  transition: all 0.35s;\n}\n.tab-content h4 {\n  padding-left: 0;\n  margin: 0;\n  font-size: 16px;\n  font-weight: 600;\n  font-family: Rajdhani-SemiBold;\n}\n.tab-content h5 {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 600;\n  font-family: Rajdhani-SemiBold;\n}\n.tab-content p {\n  margin: 0;\n}\n.tab-content ion-toggle {\n  float: right;\n}\n.tab-close {\n  display: flex;\n  justify-content: flex-end;\n  padding: 1em;\n  font-size: 0.75em;\n  background: #fff;\n  cursor: pointer;\n}\n.tab-close:hover {\n  background: #1a252f;\n}\ninput[type=checkbox]:checked, input[type=radio]:checked {\n  background: #f77e21;\n}\ninput:checked + .tab-label {\n  background: #fff;\n}\ninput:checked + .tab-label::after {\n  transform: rotate(90deg);\n}\ninput[type=checkbox], input[type=radio] {\n  padding: 0;\n  position: absolute;\n  left: 10px;\n  top: 14px;\n  display: none;\n}\ninput:checked ~ .tab-content {\n  max-height: 100vh;\n  padding: 0 1em;\n}\n.bottom-btn {\n  text-align: center;\n  margin: 40px auto;\n}\n.bottom-btn ion-button.subscribe-btn {\n  --background:#00a651;\n  background: #00a651;\n  --border-radius:0px;\n  border: 1px solid #00a651;\n  text-align: center;\n  color: #fff;\n  width: 200px;\n  letter-spacing: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3Vic2NyaXB0aW9uL3N1YnNjcmlwdGlvbi5wYWdlLnNjc3MiLCIvVm9sdW1lcy9EaXNrMi9ib2R5Rmlyc3Qvc3JjL2FwcC9zdWJzY3JpcHRpb24vc3Vic2NyaXB0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxnQkFBZ0I7QUNBaEI7RUFDSSxvQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBREVKO0FDQ0k7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QURDSjtBQ0NJO0VBQ0ksV0FBQTtBRENSO0FDQ0k7RUFDSSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FEQ1I7QUNDSTtFQUNJLFlBQUE7RUFDQSxjQUFBO0VBQ0osMEJBQUE7RUFDQSxXQUFBO0FEQ0o7QUNDSTtFQUNJLGVBQUE7QURDUjtBQ0dBO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtBREFKO0FDQ0k7RUFDSSxrQkFBQTtFQUNBLFdBQUE7QURDUjtBQ0VBO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtBRENKO0FDR0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QURBSjtBQ0dFO0VBRUUsYUFBQTtFQUNBLGdDQUFBO0VBRVEsOEJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNSLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSw2QkFBQTtFQUVBLFNBQUE7QURESjtBQ01FO0VBQ0UsWUFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFFQSxxQkFBQTtBREhKO0FDS0U7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSw2QkFBQTtFQUNKLGVBQUE7RUFDSSxpQkFBQTtFQUVBLHFCQUFBO0FERko7QUNHSTtFQUNJLGVBQUE7RUFDSixTQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsOEJBQUE7QURESjtBQ0lJO0VBQ0ksU0FBQTtFQUNKLGVBQUE7RUFDQSxnQkFBQTtFQUNBLDhCQUFBO0FERko7QUNJSTtFQUNJLFNBQUE7QURGUjtBQ0lJO0VBQ0ksWUFBQTtBREZSO0FDS0U7RUFFRSxhQUFBO0VBRVEseUJBQUE7RUFDUixZQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QURGSjtBQ0lFO0VBQ0UsbUJBQUE7QURESjtBQ0dFO0VBQ0ksbUJBQUE7QURBTjtBQ0VFO0VBQ0UsZ0JBQUE7QURDSjtBQ0NFO0VBRVUsd0JBQUE7QURFWjtBQ0NFO0VBQ0UsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7RUFDQSxhQUFBO0FERUo7QUNBRTtFQUNFLGlCQUFBO0VBQ0EsY0FBQTtBREdKO0FDREU7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0FESU47QUNIRTtFQUNJLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FES04iLCJmaWxlIjoic3JjL2FwcC9zdWJzY3JpcHRpb24vc3Vic2NyaXB0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBjaGFyc2V0IFwiVVRGLThcIjtcbi5oZWFkZXIge1xuICAtLWJhY2tncm91bmQ6IzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi10aXRsZSB7XG4gIHBhZGRpbmc6IDBweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIHBhZGRpbmctbGVmdDogNDJweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbn1cbi5oZWFkZXIgaW9uLW1lbnUtYnV0dG9uIHtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi1pY29uIHtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbWFyZ2luOiA1cHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5oZWFkZXIgcCB7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6ICNmNzdlMjE7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICBtYXJnaW46IDBlbTtcbn1cbi5oZWFkZXIgaW9uLWJhY2stYnV0dG9uIHtcbiAgZm9udC1zaXplOiAxMnB4O1xufVxuXG4ucGxhbi12aWRlbyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLnBsYW4tdmlkZW8gaW1nIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogMTAwJTtcbn1cblxuLnRhYnMge1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi50YWIge1xuICB3aWR0aDogMTAwJTtcbiAgY29sb3I6IHdoaXRlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi50YWItbGFiZWwge1xuICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgZGlzcGxheTogZmxleDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkZGRkZGQ7XG4gIC13ZWJraXQtYm94LXBhY2s6IGp1c3RpZnk7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgcGFkZGluZzogMC44cmVtO1xuICBmb250LXNpemU6IDE1cHg7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGNvbG9yOiAjMjIyO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgLyogSWNvbiAqL1xufVxuXG4udGFiLWxhYmVsOjphZnRlciB7XG4gIGNvbnRlbnQ6IFwi4p2vXCI7XG4gIHdpZHRoOiAxZW07XG4gIGhlaWdodDogMWVtO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xuICB0cmFuc2l0aW9uOiBhbGwgMC4zNXM7XG59XG5cbi50YWItY29udGVudCB7XG4gIG1heC1oZWlnaHQ6IDA7XG4gIHBhZGRpbmc6IDAgMWVtO1xuICBjb2xvcjogIzJjM2U1MDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xuICB0cmFuc2l0aW9uOiBhbGwgMC4zNXM7XG59XG4udGFiLWNvbnRlbnQgaDQge1xuICBwYWRkaW5nLWxlZnQ6IDA7XG4gIG1hcmdpbjogMDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktU2VtaUJvbGQ7XG59XG4udGFiLWNvbnRlbnQgaDUge1xuICBtYXJnaW46IDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVNlbWlCb2xkO1xufVxuLnRhYi1jb250ZW50IHAge1xuICBtYXJnaW46IDA7XG59XG4udGFiLWNvbnRlbnQgaW9uLXRvZ2dsZSB7XG4gIGZsb2F0OiByaWdodDtcbn1cblxuLnRhYi1jbG9zZSB7XG4gIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICBkaXNwbGF5OiBmbGV4O1xuICAtd2Via2l0LWJveC1wYWNrOiBlbmQ7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gIHBhZGRpbmc6IDFlbTtcbiAgZm9udC1zaXplOiAwLjc1ZW07XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLnRhYi1jbG9zZTpob3ZlciB7XG4gIGJhY2tncm91bmQ6ICMxYTI1MmY7XG59XG5cbmlucHV0W3R5cGU9Y2hlY2tib3hdOmNoZWNrZWQsIGlucHV0W3R5cGU9cmFkaW9dOmNoZWNrZWQge1xuICBiYWNrZ3JvdW5kOiAjZjc3ZTIxO1xufVxuXG5pbnB1dDpjaGVja2VkICsgLnRhYi1sYWJlbCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG59XG5cbmlucHV0OmNoZWNrZWQgKyAudGFiLWxhYmVsOjphZnRlciB7XG4gIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xuICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG59XG5cbmlucHV0W3R5cGU9Y2hlY2tib3hdLCBpbnB1dFt0eXBlPXJhZGlvXSB7XG4gIHBhZGRpbmc6IDA7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMTBweDtcbiAgdG9wOiAxNHB4O1xuICBkaXNwbGF5OiBub25lO1xufVxuXG5pbnB1dDpjaGVja2VkIH4gLnRhYi1jb250ZW50IHtcbiAgbWF4LWhlaWdodDogMTAwdmg7XG4gIHBhZGRpbmc6IDAgMWVtO1xufVxuXG4uYm90dG9tLWJ0biB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiA0MHB4IGF1dG87XG59XG4uYm90dG9tLWJ0biBpb24tYnV0dG9uLnN1YnNjcmliZS1idG4ge1xuICAtLWJhY2tncm91bmQ6IzAwYTY1MTtcbiAgYmFja2dyb3VuZDogIzAwYTY1MTtcbiAgLS1ib3JkZXItcmFkaXVzOjBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgIzAwYTY1MTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgd2lkdGg6IDIwMHB4O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xufSIsIi5oZWFkZXJ7XG4gICAgLS1iYWNrZ3JvdW5kOiMyMzM5NDI7XG4gICAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICBjb2xvcjojZmZmO1xuICAgIC8vcGFkZGluZzogIDVweDtcblxuICAgIGlvbi10aXRsZXtcbiAgICBwYWRkaW5nOiAwcHg7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgICBwYWRkaW5nLWxlZnQ6IDQycHg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICB9XG4gICAgaW9uLW1lbnUtYnV0dG9ue1xuICAgICAgICBjb2xvcjojZmZmO1xuICAgIH1cbiAgICBpb24taWNvbntcbiAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICAgICAgY29sb3I6I2ZmZjtcbiAgICAgICAgZm9udC1zaXplOjIwcHg7XG4gICAgICAgIG1hcmdpbjo1cHg7XG4gICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICB9XG4gICAgcHtcbiAgICAgICAgZmxvYXQ6cmlnaHQ7XG4gICAgICAgIGNvbG9yOiNmNzdlMjE7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgbWFyZ2luOiAwZW07XG4gICAgfVxuICAgIGlvbi1iYWNrLWJ1dHRvbntcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgIH1cbiAgIFxufVxuLnBsYW4tdmlkZW97XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBpbWd7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgd2lkdGg6MTAwJTtcbiAgICB9XG59XG4udGFicyB7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAvLyBib3gtc2hhZG93OiAwIDRweCA0cHggLTJweCByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gIH1cbiAgXG4gIC50YWIge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgIFxuICB9XG4gIC50YWItbGFiZWwge1xuICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkZGRkZGQ7XG4gICAgLXdlYmtpdC1ib3gtcGFjazoganVzdGlmeTtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgcGFkZGluZzowLjhyZW07XG4gICAgICAgICAgICBmb250LXNpemU6MTVweDtcbiAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIGNvbG9yOiMyMjI7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG5cbiAgICAvKiBJY29uICovXG4gIH1cbiAgLnRhYi1sYWJlbDpob3ZlciB7XG4gICAgLy9iYWNrZ3JvdW5kOiAjMWEyNTJmO1xuICB9XG4gIC50YWItbGFiZWw6OmFmdGVyIHtcbiAgICBjb250ZW50OiBcIlxcMjc2RlwiO1xuICAgIHdpZHRoOiAxZW07XG4gICAgaGVpZ2h0OiAxZW07XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4zNXM7XG4gICAgdHJhbnNpdGlvbjogYWxsIC4zNXM7XG4gIH1cbiAgLnRhYi1jb250ZW50IHtcbiAgICBtYXgtaGVpZ2h0OiAwO1xuICAgIHBhZGRpbmc6IDAgMWVtO1xuICAgIGNvbG9yOiAjMmMzZTUwO1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuZm9udC1zaXplOjE0cHg7XG4gICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjM1cztcbiAgICB0cmFuc2l0aW9uOiBhbGwgLjM1cztcbiAgICBoNHtcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAwO1xuICAgIG1hcmdpbjogMDtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktU2VtaUJvbGQ7XG5cbiAgICB9XG4gICAgaDV7XG4gICAgICAgIG1hcmdpbjogMDtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktU2VtaUJvbGQ7XG4gICAgfVxuICAgIHB7XG4gICAgICAgIG1hcmdpbjowO1xuICAgIH1cbiAgICBpb24tdG9nZ2xle1xuICAgICAgICBmbG9hdDpyaWdodDtcbiAgICB9XG4gIH1cbiAgLnRhYi1jbG9zZSB7XG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICAtd2Via2l0LWJveC1wYWNrOiBlbmQ7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICAgIHBhZGRpbmc6IDFlbTtcbiAgICBmb250LXNpemU6IDAuNzVlbTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAudGFiLWNsb3NlOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kOiAjMWEyNTJmO1xuICB9XG4gIGlucHV0W3R5cGU9Y2hlY2tib3hdOmNoZWNrZWQsIGlucHV0W3R5cGU9cmFkaW9dOmNoZWNrZWR7XG4gICAgICBiYWNrZ3JvdW5kOiAjZjc3ZTIxO1xuICB9XG4gIGlucHV0OmNoZWNrZWQgKyAudGFiLWxhYmVsIHtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICB9XG4gIGlucHV0OmNoZWNrZWQgKyAudGFiLWxhYmVsOjphZnRlciB7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gIH1cblxuICBpbnB1dFt0eXBlPWNoZWNrYm94XSwgaW5wdXRbdHlwZT1yYWRpb10ge1xuICAgIHBhZGRpbmc6IDA7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDEwcHg7XG4gICAgdG9wOiAxNHB4O1xuICAgIGRpc3BsYXk6bm9uZTtcbn1cbiAgaW5wdXQ6Y2hlY2tlZCB+IC50YWItY29udGVudCB7XG4gICAgbWF4LWhlaWdodDogMTAwdmg7XG4gICAgcGFkZGluZzogMCAxZW07XG4gIH1cbiAgLmJvdHRvbS1idG57XG4gICAgICB0ZXh0LWFsaWduOmNlbnRlcjtcbiAgICAgIG1hcmdpbjo0MHB4IGF1dG87XG4gIGlvbi1idXR0b24uc3Vic2NyaWJlLWJ0bntcbiAgICAgIC0tYmFja2dyb3VuZDojMDBhNjUxO1xuICAgICAgYmFja2dyb3VuZDojMDBhNjUxO1xuICAgICAgLS1ib3JkZXItcmFkaXVzOjBweDtcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkICMwMGE2NTE7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICBjb2xvcjojZmZmO1xuICAgICAgd2lkdGg6MjAwcHg7XG4gICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICB9XG59Il19 */");

/***/ }),

/***/ "./src/app/subscription/subscription.page.ts":
/*!***************************************************!*\
  !*** ./src/app/subscription/subscription.page.ts ***!
  \***************************************************/
/*! exports provided: SubscriptionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscriptionPage", function() { return SubscriptionPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _service_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/api.service */ "./src/app/service/api.service.ts");



let SubscriptionPage = class SubscriptionPage {
    constructor(api) {
        this.api = api;
        this.getSuuscription();
    }
    ngOnInit() {
        this.getSuuscription();
    }
    getSuuscription() {
        console.log("gettt");
        this.api.get("/getPlans").subscribe((res) => {
            console.log(res, "data");
        });
    }
};
SubscriptionPage.ctorParameters = () => [
    { type: _service_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] }
];
SubscriptionPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-subscription",
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./subscription.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/subscription/subscription.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./subscription.page.scss */ "./src/app/subscription/subscription.page.scss")).default]
    })
], SubscriptionPage);



/***/ })

}]);
//# sourceMappingURL=subscription-subscription-module-es2015.js.map