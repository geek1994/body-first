function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mindset-mindset-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/mindset/mindset.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/mindset/mindset.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMindsetMindsetPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>MINDSET</ion-title>\n\n    <ion-buttons slot=\"end\">\n      <ion-icon\n      *ngIf=\"type=='sharping'\"\n        name=\"search-outline\"\n        class=\"search\"\n        (click)=\"showDefaultBar()\"\n      ></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div>\n    <ion-searchbar\n    *ngIf=\"toggled && type=='sharping'\"\n    placeholder=\"Search\"\n    inputmode=\"text\" type=\"text\"\n    [(ngModel)]=\"searchTerm\" mode=\"ios\"\n    (ionChange)=\"onSearchChange($event)\"\n    (ionCancel)=\"clearData()\"\n    (ionBlur)=\"showDefaultBar()\"\n    showCancelButton=\"always\"\n    [debounce]=\"250\"\n    animated=\"true\">\n  </ion-searchbar>\n  </div>\n  <div class=\"mindset\">\n    <div class=\"mindset-guid\" *ngIf=\"type=='guid'\">\n      <img src=\"assets/images/mindset-top-banner.jpg\" />\n      <div class=\"mindset-guid-head\">\n        <h4>MINDSET PRINCIPLE</h4>\n      </div>\n      <div class=\"image-m\">\n        <img src=\"assets/images/minset-banner.png\" />\n      </div>\n      <div class=\"mindset-data\">\n        <div class=\"mindset-principle\">\n          <h5>Overview</h5>\n          <p>\n            Mindset is your general attitude and the way you think about things\n            and make decisions. Your beliefs and attitudes shape your mindset.\n            There are two types of mindsets; Fixed and Growth. Fixed is the\n            belief that you are born with a certain amount of intelligence or\n            potential and that’s it. Growth is the belief that you are capable\n            of working to increase your potential and intelligence. Your\n            commitment to developing a growth mindset will help you to take\n            control of your life. When you hear the critical voice in your head\n            telling you that you can’t do something, reply with a growth mindset\n            approach and tell yourself that you can.\n          </p>\n          <p><b>Here are a few ways to change your mindset:</b></p>\n        </div>\n        <div class=\"mindset-principle\">\n          <h5>Affirmations</h5>\n          <p>\n            These are positive specific statements that help you overcome\n            self-sabotaging, negative thoughts. Speaking your affirmations out\n            loud daily and visualizing them will help you believe in what your\n            are affirming and lead to self empowerment.\n          </p>\n          <p>\n            - Download the ‘Think Up’ app and choose the affirmations you will\n            record and say to yourself daily.\n          </p>\n          <p>- Write out your affirmations and read them out loud daily.</p>\n          <p>\n            - Make note cards of your affirmations and place them where you can\n            see them every day.\n          </p>\n        </div>\n        <img src=\"assets/images/banner-m.png\" /><br />\n        <div class=\"mindset-principle\">\n          <h5>People, Places, Things</h5>\n          <p>\n            People often make the mistake of not realizing that happiness is a\n            choice. Your choices are heavily influenced by people in your lives,\n            the places you go and the things that you do. Make adjustments in\n            your life to line up with your goals. It is important to surround\n            yourself with people who will support and encourage you along your\n            journey. Positive social connection leads to long-term happiness.\n          </p>\n          <p>\n            - Have a solid support system with people who support your mission\n            (friends, family, etc.).\n          </p>\n          <p>- Be sure the places you frequent support your goals.</p>\n          <p>- It’s important you have a hobby that supports your goals.</p>\n        </div>\n        <div class=\"mindset-principle\">\n          <h5>Meditate</h5>\n          <p>\n            Calm your mind so you can become more aware of your thoughts and\n            emotions. Practicing meditation helps you know yourself on a deeper\n            level lowering stress and anxiety while creating a clear path of\n            direction.\n          </p>\n          <p>\n            - Schedule time daily to meditate and pray (best way to start your\n            day).\n          </p>\n          <p>- Find a quiet space.</p>\n          <p>- Use resources; use an accountability calendar or an app.</p>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>\n            Goal Setting (Refer to the Getting Started Guide for Goal Setting\n            Instructions)\n          </h5>\n          <p>\n            Set 1 to 3 goals to strengthen your mindset (example: daily\n            affirmations, develop a hobby, etc.)\n          </p>\n          <p class=\"goal-input\">1. <input type=\"text\" /></p>\n          <p class=\"goal-input\">2. <input type=\"text\" /></p>\n          <p class=\"goal-input\">3. <input type=\"text\" /></p>\n        </div>\n      </div>\n    </div>\n\n    <div *ngIf=\"type=='sharping' && mindsetArray.length>0\">\n      <div class=\"content\" *ngFor=\"let mindset_data of mindsetArray\">\n        <ng-controller (click)=\"detail(mindset_data, 'mindset')\">\n          <div class=\"img-box\">\n            <img src=\"{{mindset_data.image}}\" />\n            <ion-icon name=\"eye-outline\"></ion-icon>\n          </div>\n          <h5>{{mindset_data.title}}:</h5>\n          <p>\n            {{mindset_data.description}}\n          </p>\n        </ng-controller>\n      </div>\n      <!-- <div class=\"content\">\n        <div class=\"img-box\">\n          <img src=\"assets/images/mindset.png\" />\n          <ion-icon name=\"eye-outline\"></ion-icon>\n        </div>\n        <h5>TRICEPS:</h5>\n        <p>\n          Neque porro quisquam est qui dolorem ipsum quia dolor sit amet,\n          consectetur, adipisci velit. Neque porro quisquam est qui dolorem\n          ipsum quia dolor sit amet, consectetur, adipisci velit.\n        </p>\n      </div> -->\n    </div>\n    <div *ngIf=\"mindsetArray.length == 0\">\n    <p class=\"no-data\">No Record Found</p>  \n    </div>\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/mindset/mindset-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/mindset/mindset-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: MindsetPageRoutingModule */

  /***/
  function srcAppMindsetMindsetRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MindsetPageRoutingModule", function () {
      return MindsetPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _mindset_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./mindset.page */
    "./src/app/mindset/mindset.page.ts");

    var routes = [{
      path: '',
      component: _mindset_page__WEBPACK_IMPORTED_MODULE_3__["MindsetPage"]
    }];

    var MindsetPageRoutingModule = function MindsetPageRoutingModule() {
      _classCallCheck(this, MindsetPageRoutingModule);
    };

    MindsetPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MindsetPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/mindset/mindset.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/mindset/mindset.module.ts ***!
    \*******************************************/

  /*! exports provided: MindsetPageModule */

  /***/
  function srcAppMindsetMindsetModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MindsetPageModule", function () {
      return MindsetPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _mindset_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./mindset-routing.module */
    "./src/app/mindset/mindset-routing.module.ts");
    /* harmony import */


    var _mindset_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./mindset.page */
    "./src/app/mindset/mindset.page.ts");

    var MindsetPageModule = function MindsetPageModule() {
      _classCallCheck(this, MindsetPageModule);
    };

    MindsetPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _mindset_routing_module__WEBPACK_IMPORTED_MODULE_5__["MindsetPageRoutingModule"]],
      declarations: [_mindset_page__WEBPACK_IMPORTED_MODULE_6__["MindsetPage"]]
    })], MindsetPageModule);
    /***/
  },

  /***/
  "./src/app/mindset/mindset.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/mindset/mindset.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppMindsetMindsetPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".header {\n  --background:#233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  letter-spacing: 1px;\n  padding-left: 50px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\n.header .search {\n  margin-right: 10px;\n}\nion-content {\n  font-family: Rajdhani-Regular;\n}\nion-content p {\n  text-align: justify;\n}\nion-content .image-m {\n  padding: 20px;\n}\n.mindset-guid-head {\n  padding: 0px 16px;\n  color: #fff;\n  background-image: url('heading-bg.png');\n  width: 100%;\n  background-position: center;\n  color: #fff;\n}\n.mindset-guid-head h4 {\n  padding: 5px 0px;\n}\n.mindset-data .mindset-principle {\n  padding: 16px;\n}\n.mindset-data .mindset-principle h5 {\n  font-size: 20px;\n  font-weight: 600;\n  color: #e7863d;\n}\np.goal-input input {\n  width: 90%;\n  margin-left: 10px;\n  border: none;\n  outline: none;\n}\np.goal-input {\n  border-bottom: 1px solid #000;\n}\n.mindset .content {\n  padding: 20px;\n  border-bottom: 1px solid #ddd;\n}\n.mindset .content .img-box {\n  position: relative;\n  width: 100%;\n}\n.mindset .content .img-box img {\n  position: relative;\n  width: 100%;\n}\n.mindset .content .img-box ion-icon {\n  position: absolute;\n  bottom: 4px;\n  background: #f77e21bf;\n  color: #fff;\n  width: 100%;\n  left: 0;\n  right: 0;\n  padding: 5px 0;\n  border-radius: 0px 0px 10px 10px;\n}\n.mindset .content h5 {\n  font-family: Rajdhani-Bold;\n  letter-spacing: 1px;\n  font-size: 24px;\n  margin-top: 20px;\n}\n.mindset .content p {\n  font-family: Rajdhani-Regular;\n  color: #858585;\n  letter-spacing: 1px;\n  margin-top: 10px;\n  font-size: 17px;\n  line-height: 24px;\n  text-align: justify;\n}\n.mindset .no-data {\n  text-align: center;\n  font-size: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL21pbmRzZXQvbWluZHNldC5wYWdlLnNjc3MiLCJzcmMvYXBwL21pbmRzZXQvbWluZHNldC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxvQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQ0NKO0FERUk7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUNBSjtBREdJO0VBQ0ksV0FBQTtBQ0RSO0FER0k7RUFDSSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FDRFI7QURHSTtFQUNJLFlBQUE7RUFDQSxjQUFBO0VBQ0osMEJBQUE7RUFDQSxXQUFBO0FDREo7QURHSTtFQUNJLGtCQUFBO0FDRFI7QURLQTtFQUNJLDZCQUFBO0FDRko7QURHSTtFQUNJLG1CQUFBO0FDRFI7QURHSTtFQUNJLGFBQUE7QUNEUjtBREtBO0VBQ0ksaUJBQUE7RUFDQSxXQUFBO0VBQ0EsdUNBQUE7RUFDQSxXQUFBO0VBQ0EsMkJBQUE7RUFDQSxXQUFBO0FDRko7QURJSTtFQUNJLGdCQUFBO0FDRlI7QURRSTtFQUNJLGFBQUE7QUNMUjtBRE9RO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ0xaO0FEVUE7RUFDSSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQ1BKO0FEVUE7RUFDSSw2QkFBQTtBQ1BKO0FEWUk7RUFDSSxhQUFBO0VBQ0EsNkJBQUE7QUNUUjtBRFVRO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0FDUlo7QURTWTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtBQ1BoQjtBRFNZO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ1oscUJBQUE7RUFDWSxXQUFBO0VBQ0EsV0FBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsY0FBQTtFQUNBLGdDQUFBO0FDUGhCO0FEV1M7RUFDTywwQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDVGhCO0FEV1k7RUFDSSw2QkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUNUaEI7QURZSTtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtBQ1ZSIiwiZmlsZSI6InNyYy9hcHAvbWluZHNldC9taW5kc2V0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJ7XG4gICAgLS1iYWNrZ3JvdW5kOiMyMzM5NDI7XG4gICAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICBjb2xvcjojZmZmO1xuICAgIC8vcGFkZGluZzogIDE2cHg7XG5cbiAgICBpb24tdGl0bGV7XG4gICAgcGFkZGluZzogMHB4O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDUwcHg7XG4gICAgXG4gICAgfSBcbiAgICBpb24tbWVudS1idXR0b257XG4gICAgICAgIGNvbG9yOiNmZmY7XG4gICAgfVxuICAgIGlvbi1pY29ue1xuICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgICAgICBjb2xvcjojZmZmO1xuICAgICAgICBmb250LXNpemU6MjBweDtcbiAgICB9XG4gICAgcHtcbiAgICAgICAgZmxvYXQ6cmlnaHQ7XG4gICAgICAgIGNvbG9yOiNmNzdlMjE7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgbWFyZ2luOiAwZW07XG4gICAgfVxuICAgIC5zZWFyY2h7XG4gICAgICAgIG1hcmdpbi1yaWdodDoxMHB4O1xuICAgIH1cbn1cblxuaW9uLWNvbnRlbnQge1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgIHB7XG4gICAgICAgIHRleHQtYWxpZ246anVzdGlmeTtcbiAgICB9XG4gICAgLmltYWdlLW17XG4gICAgICAgIHBhZGRpbmc6MjBweDtcbiAgICB9XG59XG5cbi5taW5kc2V0LWd1aWQtaGVhZCB7XG4gICAgcGFkZGluZzogMHB4IDE2cHg7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgYmFja2dyb3VuZC1pbWFnZTp1cmwoLi4vLi4vYXNzZXRzL2ltYWdlcy9oZWFkaW5nLWJnLnBuZyk7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgIGNvbG9yOiAjZmZmO1xuXG4gICAgaDQge1xuICAgICAgICBwYWRkaW5nOiA1cHggMHB4O1xuICAgIH1cbn1cblxuLm1pbmRzZXQtZGF0YSB7XG4gICBcbiAgICAubWluZHNldC1wcmluY2lwbGUgeyBcbiAgICAgICAgcGFkZGluZzogMTZweDtcblxuICAgICAgICBoNXtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICAgICAgICBjb2xvcjogI2U3ODYzZDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxucC5nb2FsLWlucHV0IGlucHV0IHtcbiAgICB3aWR0aDogOTAlO1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIGJvcmRlcjogbm9uZTtcbiAgICBvdXRsaW5lOiBub25lO1xufVxuXG5wLmdvYWwtaW5wdXQge1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMDAwO1xufVxuXG4ubWluZHNldHtcbiAgICBcbiAgICAuY29udGVudHtcbiAgICAgICAgcGFkZGluZzoyMHB4O1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2RkZDtcbiAgICAgICAgLmltZy1ib3h7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgIGltZ3tcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICAgICAgd2lkdGg6MTAwJTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICBib3R0b206IDRweDtcbiAgICBiYWNrZ3JvdW5kOiAjZjc3ZTIxYmY7XG4gICAgICAgICAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiA1cHggMDtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDEwcHggMTBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgXG4gICAgICAgIH1cbiAgICAgICAgIGg1e1xuICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgICAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBwe1xuICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyOyAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIGNvbG9yOiAjODU4NTg1O1xuICAgICAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE3cHg7XG4gICAgICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgICAgICAgICAgIH1cbiAgICB9XG4gICAgLm5vLWRhdGF7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgIH1cbn1cbiIsIi5oZWFkZXIge1xuICAtLWJhY2tncm91bmQ6IzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi10aXRsZSB7XG4gIHBhZGRpbmc6IDBweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gIHBhZGRpbmctbGVmdDogNTBweDtcbn1cbi5oZWFkZXIgaW9uLW1lbnUtYnV0dG9uIHtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi1pY29uIHtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cbi5oZWFkZXIgcCB7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6ICNmNzdlMjE7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICBtYXJnaW46IDBlbTtcbn1cbi5oZWFkZXIgLnNlYXJjaCB7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbn1cbmlvbi1jb250ZW50IHAge1xuICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xufVxuaW9uLWNvbnRlbnQgLmltYWdlLW0ge1xuICBwYWRkaW5nOiAyMHB4O1xufVxuXG4ubWluZHNldC1ndWlkLWhlYWQge1xuICBwYWRkaW5nOiAwcHggMTZweDtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLi8uLi9hc3NldHMvaW1hZ2VzL2hlYWRpbmctYmcucG5nKTtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgY29sb3I6ICNmZmY7XG59XG4ubWluZHNldC1ndWlkLWhlYWQgaDQge1xuICBwYWRkaW5nOiA1cHggMHB4O1xufVxuXG4ubWluZHNldC1kYXRhIC5taW5kc2V0LXByaW5jaXBsZSB7XG4gIHBhZGRpbmc6IDE2cHg7XG59XG4ubWluZHNldC1kYXRhIC5taW5kc2V0LXByaW5jaXBsZSBoNSB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICNlNzg2M2Q7XG59XG5cbnAuZ29hbC1pbnB1dCBpbnB1dCB7XG4gIHdpZHRoOiA5MCU7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG5cbnAuZ29hbC1pbnB1dCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMDAwO1xufVxuXG4ubWluZHNldCAuY29udGVudCB7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZGRkO1xufVxuLm1pbmRzZXQgLmNvbnRlbnQgLmltZy1ib3gge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiAxMDAlO1xufVxuLm1pbmRzZXQgLmNvbnRlbnQgLmltZy1ib3ggaW1nIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogMTAwJTtcbn1cbi5taW5kc2V0IC5jb250ZW50IC5pbWctYm94IGlvbi1pY29uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDRweDtcbiAgYmFja2dyb3VuZDogI2Y3N2UyMWJmO1xuICBjb2xvcjogI2ZmZjtcbiAgd2lkdGg6IDEwMCU7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICBwYWRkaW5nOiA1cHggMDtcbiAgYm9yZGVyLXJhZGl1czogMHB4IDBweCAxMHB4IDEwcHg7XG59XG4ubWluZHNldCAuY29udGVudCBoNSB7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICBmb250LXNpemU6IDI0cHg7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG4ubWluZHNldCAuY29udGVudCBwIHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIGNvbG9yOiAjODU4NTg1O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBmb250LXNpemU6IDE3cHg7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xufVxuLm1pbmRzZXQgLm5vLWRhdGEge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/mindset/mindset.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/mindset/mindset.page.ts ***!
    \*****************************************/

  /*! exports provided: MindsetPage */

  /***/
  function srcAppMindsetMindsetPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MindsetPage", function () {
      return MindsetPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _search_exercises_search_exercises_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ..//search-exercises/search-exercises.page */
    "./src/app/search-exercises/search-exercises.page.ts");
    /* harmony import */


    var _detailspirit_detailspirit_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../detailspirit/detailspirit.page */
    "./src/app/detailspirit/detailspirit.page.ts");

    var MindsetPage = /*#__PURE__*/function () {
      function MindsetPage(modalController, navCtrl, router, route) {
        var _this = this;

        _classCallCheck(this, MindsetPage);

        this.modalController = modalController;
        this.navCtrl = navCtrl;
        this.router = router;
        this.route = route;
        this.mindsetData = [];
        this.type = 'guid';
        this.searchTerm = '';
        this.mindsetArray = [];
        this.toggled = false;
        this.route.queryParams.subscribe(function (params) {
          _this.type = params["type"];

          if (_this.type == 'sharping') {
            _this.mindsetData = [{
              'id': 1,
              'title': 'Jump',
              'image': 'assets/images/mindset.png',
              'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
            }, {
              'id': 2,
              'title': 'Triceps',
              'image': 'assets/images/mindset.png',
              'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
            }];
            console.log(_this.mindsetData);
            _this.mindsetArray = _this.mindsetData;
          }
        });
      }

      _createClass(MindsetPage, [{
        key: "search",
        value: function search() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var modal;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.modalController.create({
                      component: _search_exercises_search_exercises_page__WEBPACK_IMPORTED_MODULE_4__["SearchExercisesPage"]
                    });

                  case 2:
                    modal = _context.sent;
                    _context.next = 5;
                    return modal.present();

                  case 5:
                    return _context.abrupt("return", _context.sent);

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "detail",
        value: function detail(data, type) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var modal;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.modalController.create({
                      component: _detailspirit_detailspirit_page__WEBPACK_IMPORTED_MODULE_5__["DetailspiritPage"],
                      componentProps: {
                        data: data,
                        type: type
                      }
                    });

                  case 2:
                    modal = _context2.sent;
                    _context2.next = 5;
                    return modal.present();

                  case 5:
                    return _context2.abrupt("return", _context2.sent);

                  case 6:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "showDefaultBar",
        value: function showDefaultBar() {
          if (this.toggled) {
            this.toggled = false;
          } else {
            this.toggled = true;
          }
        }
      }, {
        key: "clearData",
        value: function clearData() {
          this.searchTerm = '';
          this.mindsetData = [{
            'id': 1,
            'title': 'Jump',
            'image': 'assets/images/mindset.png',
            'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
          }, {
            'id': 2,
            'title': 'Triceps',
            'image': 'assets/images/mindset.png',
            'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
          }];
          this.mindsetArray = this.mindsetData;
        }
      }, {
        key: "onSearchChange",
        value: function onSearchChange() {
          var _this2 = this;

          this.mindsetArray = [];
          console.log(this.searchTerm);
          this.mindsetData.filter(function (element, key) {
            if (element.title && _this2.searchTerm != '') {
              console.log(element.title.toLowerCase().indexOf(_this2.searchTerm.toLowerCase())); // return (element.title.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);

              if (element.title.toLowerCase().indexOf(_this2.searchTerm.toLowerCase()) > -1) {
                _this2.mindsetArray.push(element);
              }
            }
          });
          console.log(this.mindsetArray);

          if (this.searchTerm == '') {
            this.mindsetData = [{
              'id': 1,
              'title': 'Jump',
              'image': 'assets/images/mindset.png',
              'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
            }, {
              'id': 2,
              'title': 'Triceps',
              'image': 'assets/images/mindset.png',
              'description': ' Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. '
            }];
            this.mindsetArray = this.mindsetData;
          }
        }
      }]);

      return MindsetPage;
    }();

    MindsetPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }];
    };

    MindsetPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-mindset',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./mindset.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/mindset/mindset.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./mindset.page.scss */
      "./src/app/mindset/mindset.page.scss"))["default"]]
    })], MindsetPage);
    /***/
  }
}]);
//# sourceMappingURL=mindset-mindset-module-es5.js.map