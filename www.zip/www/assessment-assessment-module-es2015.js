(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["assessment-assessment-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/assessment/assessment.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/assessment/assessment.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title style=\"text-transform:uppercase;\">{{pageValue}}</ion-title>    \n        <p slot=\"end\" (click)=\"update()\">UPDATE</p>     \n  </ion-toolbar>\n  <!-- <div class=\"header\">\n    <ion-row class=\"align-center\">\n      <ion-col size=\"1\">\n        <ion-menu-button></ion-menu-button>\n      </ion-col>\n      <ion-col size=\"9\">\n        <ion-title>ASSESSMENT</ion-title>\n      </ion-col>\n      <ion-col size=\"2\" text-right (click)=\"update()\">\n        <p>UPDATE</p>\n      </ion-col>\n    </ion-row>\n  </div> -->\n</ion-header>\n\n<ion-content>\n  <div class=\"workout-section\">\n    <ion-row>\n      <ion-col size=\"12\" (click)=\"selectImage()\">\n        <div class=\"workout-image\" >\n          <img src=\"assets/images/workout-image.png\" *ngIf=\"assessmentData.image == null\" />\n          <img src=\"{{assessmentData.iamge}}\" *ngIf=\"assessmentData.image != null\" />\n          <div class=\"upload-img\">\n            <img src=\"assets/images/upload.png\" *ngIf=\"assessmentData.image == null\"/>\n            <p>Upload Image</p>\n          </div>\n          <!----<p><b>Front</b></p>-->\n        </div>\n      </ion-col>\n      <!---- <ion-col size=\"4\">\n        <div class=\"workout-image\">\n          <img src=\"assets/images/workout-image.png\" />\n          <div class=\"upload-img\">\n            <img src=\"assets/images/upload.png\" />\n            <p>Upload Image</p>\n          </div>\n          <p><b>Side</b></p>\n        </div>\n      </ion-col>\n      <ion-col size=\"4\">\n        <div class=\"workout-image\">\n          <img src=\"assets/images/workout-image.png\" />\n          <div class=\"upload-img\">\n            <img src=\"assets/images/upload.png\" />\n            <p>Upload Image</p>\n          </div>\n          <p><b>Back</b></p>\n        </div>\n      </ion-col> --->\n    </ion-row>\n    <br />\n    <!-- <div class=\"workout-image\">\n      <img src=\"assets/images/workout-image.png\" />\n      <div class=\"upload-img\">\n        <img src=\"assets/images/upload.png\" />\n        <p>Upload Image</p>\n      </div>\n    </div> -->\n    <form [formGroup]=\"assessmentForm\">\n    <div class=\"content\">\n      <h4 class=\"heading\">BI WEEKLY :</h4>\n      <ion-row>\n        <ion-col size=\"6\">\n          <ion-label>Total Body Weight</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-input placeholder=\"Total Body Weight\" type=\"number\" formControlName=\"total_weight\"></ion-input>\n        </ion-col>\n      </ion-row>\n      <p class=\"error\">\n        <span *ngIf=\"assessmentForm.get('total_weight').hasError('required') && assessmentForm.get('total_weight').touched\">Please\n           enter total weight.</span>\n     </p>\n      <ion-row>\n        <ion-col size=\"6\">\n          <ion-label>Lean Body Weight</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-input placeholder=\"Lean Body Weight\" type=\"number\" formControlName=\"lean_weight\"></ion-input>\n        </ion-col>\n      </ion-row>\n      <p class=\"error\">\n        <span *ngIf=\"assessmentForm.get('lean_weight').hasError('required') && assessmentForm.get('lean_weight').touched\">Please\n           enter lean body weight.</span>\n     </p>\n      <ion-row>\n        <ion-col size=\"6\">\n          <ion-label>Fat Body Mass</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-input placeholder=\"Fat Body Mass\" type=\"number\" formControlName=\"fat\"></ion-input>\n        </ion-col>\n      </ion-row>\n      <p class=\"error\">\n        <span *ngIf=\"assessmentForm.get('fat').hasError('required') && assessmentForm.get('fat').touched\">Please\n           enter fat body mass.</span>\n     </p>\n      <ion-row>\n        <ion-col size=\"6\">\n          <ion-label>% of Body Fat</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-input placeholder=\"% of Body Fat\" type=\"number\" formControlName=\"fat_percantage\"></ion-input>\n        </ion-col>\n      </ion-row>\n      <p class=\"error\">\n        <span *ngIf=\"assessmentForm.get('fat_percantage').hasError('required') && assessmentForm.get('fat_percantage').touched\">Please\n           enter % of body fat.</span>\n     </p>\n      <ion-row>\n        <ion-col size=\"6\">\n          <ion-label>% of Hydration</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-input placeholder=\"% of Hydration\" type=\"number\" formControlName=\"hydration_percentage\"></ion-input>\n        </ion-col>\n      </ion-row>\n      <p class=\"error\">\n        <span *ngIf=\"assessmentForm.get('hydration_percentage').hasError('required') && assessmentForm.get('hydration_percentage').touched\">Please\n           enter % of hydration.</span>\n     </p>\n    </div>\n  </form>\n    <div class=\"monthly-content\">\n      <h4>MONTHLY :</h4>\n      <br />\n      <ion-row>\n        <ion-col size=\"5\" class=\"section-img\">\n          <div class=\"front-img\">\n            <img src=\"assets/images/front.png\" />\n          </div>\n        </ion-col>\n        <ion-col size=\"7\" class=\"exs-content\">\n          <h5>FRONT</h5>\n          <br />\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Neck</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>42</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Shoulders</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>17.5</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Arms</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>15</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Chest (Male)</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>36</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Waist</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>34</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Hips</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>23</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Thigh</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>15</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Calf</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>12</p>\n            </ion-col>\n          </ion-row>\n        </ion-col>\n      </ion-row>\n      <br />\n      <hr />\n      <br />\n      <ion-row>\n        <ion-col size=\"5\" class=\"section-img\">\n          <div class=\"front-img\">\n            <img src=\"assets/images/side.png\" />\n          </div>\n        </ion-col>\n        <ion-col size=\"7\" class=\"exs-content\">\n          <h5>Side</h5>\n          <br />\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Neck</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>42</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Shoulders</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>17.5</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Arms</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>15</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Chest (Male)</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>36</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Waist</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>34</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Hips</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>23</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Thigh</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>15</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Calf</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>12</p>\n            </ion-col>\n          </ion-row>\n        </ion-col>\n      </ion-row>\n      <br />\n      <hr />\n      <br />\n      <ion-row>\n        <ion-col size=\"5\" class=\"section-img\">\n          <div class=\"front-img\">\n            <img src=\"assets/images/back.png\" />\n          </div>\n        </ion-col>\n        <ion-col size=\"7\" class=\"exs-content\">\n          <h5>Back</h5>\n          <br />\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Neck</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>42</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Shoulders</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>17.5</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Arms</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>15</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Chest (Male)</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>36</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Waist</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>34</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Hips</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>23</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Thigh</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>15</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"6\">\n              <p>Calf</p>\n            </ion-col>\n            <ion-col size=\"2\">\n              <p>-</p>\n            </ion-col>\n            <ion-col size=\"4\">\n              <p>12</p>\n            </ion-col>\n          </ion-row>\n        </ion-col>\n      </ion-row>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/assessment/assessment-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/assessment/assessment-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: AssessmentPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AssessmentPageRoutingModule", function() { return AssessmentPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _assessment_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./assessment.page */ "./src/app/assessment/assessment.page.ts");




const routes = [
    {
        path: '',
        component: _assessment_page__WEBPACK_IMPORTED_MODULE_3__["AssessmentPage"]
    }
];
let AssessmentPageRoutingModule = class AssessmentPageRoutingModule {
};
AssessmentPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AssessmentPageRoutingModule);



/***/ }),

/***/ "./src/app/assessment/assessment.module.ts":
/*!*************************************************!*\
  !*** ./src/app/assessment/assessment.module.ts ***!
  \*************************************************/
/*! exports provided: AssessmentPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AssessmentPageModule", function() { return AssessmentPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _assessment_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./assessment-routing.module */ "./src/app/assessment/assessment-routing.module.ts");
/* harmony import */ var _assessment_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./assessment.page */ "./src/app/assessment/assessment.page.ts");








let AssessmentPageModule = class AssessmentPageModule {
};
AssessmentPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _assessment_routing_module__WEBPACK_IMPORTED_MODULE_5__["AssessmentPageRoutingModule"]
        ],
        declarations: [_assessment_page__WEBPACK_IMPORTED_MODULE_6__["AssessmentPage"]]
    })
], AssessmentPageModule);



/***/ }),

/***/ "./src/app/assessment/assessment.page.scss":
/*!*************************************************!*\
  !*** ./src/app/assessment/assessment.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 42px;\n  letter-spacing: 1px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n  margin: 5px;\n  margin-right: 10px;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\n.header ion-back-button {\n  font-size: 12px;\n}\n.measurements {\n  padding: 20px;\n  background: #fff;\n  margin-top: 20px;\n}\n.measurements h4 {\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n}\n.measurements img {\n  text-align: center;\n  padding: 100px 20px;\n  margin: 0 auto;\n}\n.measurements h5 {\n  text-align: center;\n  font-family: Rajdhani-Bold;\n}\n.measurements p {\n  font-size: 18px;\n  font-family: Rajdhani-Regular;\n  margin: 3px;\n}\nhr {\n  border: 1px solid #ddd;\n}\n.workout-section {\n  /*padding: 20px;\n  background: #fff;*/\n}\n.workout-section .workout-image {\n  position: relative;\n  text-align: center;\n  margin: 0 auto;\n  background: #fff;\n}\n.workout-section .workout-image img {\n  margin-top: 15px;\n}\n.workout-section .workout-image .upload-img {\n  position: absolute;\n  width: 100%;\n  top: 10%;\n}\n.workout-section .workout-image .upload-img img {\n  width: 20%;\n}\n.workout-section .workout-image .upload-img p {\n  color: #fff;\n  font-family: Rajdhani-Regular;\n  margin: 0px;\n}\n.workout-section .workout-image p {\n  font-family: Rajdhani-Regular;\n  margin: 0px;\n}\n.workout-section .content {\n  padding: 20px;\n}\n.workout-section .content ion-row {\n  border-bottom: 1px solid #ddd;\n}\n.workout-section .content ion-label {\n  text-align: left;\n  font-size: 14px;\n  padding-top: 10px;\n  font-family: Rajdhani-Regular;\n  line-height: 38px;\n  font-weight: 600;\n}\n.workout-section .content ion-input {\n  font-size: 14px;\n  font-family: Rajdhani-Regular;\n  text-align: right;\n}\n.workout-section .content h4.heading {\n  margin-top: 0px;\n  font-size: 18px;\n  color: #f77e21;\n  text-transform: uppercase;\n  font-family: Rajdhani-Bold;\n}\n.workout-section .monthly-content {\n  padding: 20px;\n  margin-top: 10px;\n  border-top: 10px solid #ebebeb;\n}\n.workout-section .monthly-content ion-col {\n  padding: 0;\n}\n.workout-section .monthly-content ion-col.exs-content {\n  padding-left: 18px;\n}\n.workout-section .monthly-content ion-col.section-img {\n  border-right: 1px solid #828282;\n}\n.workout-section .monthly-content h4 {\n  font-size: 18px;\n  color: #f77e21;\n  text-transform: uppercase;\n  font-family: Rajdhani-Bold;\n}\n.workout-section .monthly-content h5 {\n  text-align: center;\n  font-family: Rajdhani-Bold;\n  font-size: 18px;\n  margin: 0;\n}\n.workout-section .monthly-content p {\n  color: #222;\n  font-family: Rajdhani-Regular;\n  margin: 0;\n}\n.workout-section .monthly-content .front-img {\n  text-align: center;\n}\n.header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n}\n.header .align-center {\n  align-items: center;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  margin-left: 35px;\n}\n.header ion-back-button {\n  display: inline-block;\n  font-size: 14px;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n  margin-right: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL2Fzc2Vzc21lbnQvYXNzZXNzbWVudC5wYWdlLnNjc3MiLCJzcmMvYXBwL2Fzc2Vzc21lbnQvYXNzZXNzbWVudC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQ0NGO0FERUU7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUNBSjtBREdFO0VBQ0UsV0FBQTtBQ0RKO0FESUU7RUFDRSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FDRko7QURLRTtFQUNFLFlBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxXQUFBO0FDSEo7QURNRTtFQUNFLGVBQUE7QUNKSjtBRFFBO0VBQ0UsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUNMRjtBRE9FO0VBQ0UsY0FBQTtFQUNBLDBCQUFBO0FDTEo7QURRRTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FDTko7QURTRTtFQUNFLGtCQUFBO0VBQ0EsMEJBQUE7QUNQSjtBRFVFO0VBQ0UsZUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtBQ1JKO0FEWUE7RUFDRSxzQkFBQTtBQ1RGO0FEWUE7RUFDRTtvQkFBQTtBQ1JGO0FEV0U7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDVEo7QURXSTtFQUNFLGdCQUFBO0FDVE47QURZSTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUVBLFFBQUE7QUNYTjtBRGFNO0VBQ0UsVUFBQTtBQ1hSO0FEY007RUFDRSxXQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0FDWlI7QURnQkk7RUFDRSw2QkFBQTtFQUNBLFdBQUE7QUNkTjtBRGtCRTtFQUNFLGFBQUE7QUNoQko7QURrQkk7RUFDRSw2QkFBQTtBQ2hCTjtBRG1CSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsNkJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FDakJOO0FEb0JJO0VBQ0UsZUFBQTtFQUNBLDZCQUFBO0VBQ0EsaUJBQUE7QUNsQk47QURxQkk7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSx5QkFBQTtFQUNBLDBCQUFBO0FDbkJOO0FEdUJFO0VBQ0UsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsOEJBQUE7QUNyQko7QUR1Qkk7RUFDRSxVQUFBO0FDckJOO0FEd0JJO0VBQ0Usa0JBQUE7QUN0Qk47QUR5Qkk7RUFDRSwrQkFBQTtBQ3ZCTjtBRDBCSTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7RUFDQSwwQkFBQTtBQ3hCTjtBRDJCSTtFQUNFLGtCQUFBO0VBQ0EsMEJBQUE7RUFDQSxlQUFBO0VBQ0EsU0FBQTtBQ3pCTjtBRDRCSTtFQUNFLFdBQUE7RUFDQSw2QkFBQTtFQUNBLFNBQUE7QUMxQk47QUQ2Qkk7RUFDRSxrQkFBQTtBQzNCTjtBRGtDQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FDL0JGO0FEa0NFO0VBQ0UsbUJBQUE7QUNoQ0o7QURtQ0U7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtFQUNBLGlCQUFBO0FDakNKO0FEb0NFO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0FDbENKO0FEcUNFO0VBQ0Usc0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQ25DSjtBRHNDRTtFQUNFLFlBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUNwQ0oiLCJmaWxlIjoic3JjL2FwcC9hc3Nlc3NtZW50L2Fzc2Vzc21lbnQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG4gIC8vcGFkZGluZzogIDVweDtcblxuICBpb24tdGl0bGUge1xuICAgIHBhZGRpbmc6IDBweDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgIHBhZGRpbmctbGVmdDogNDJweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICB9XG5cbiAgaW9uLW1lbnUtYnV0dG9uIHtcbiAgICBjb2xvcjogI2ZmZjtcbiAgfVxuXG4gIGlvbi1pY29uIHtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBtYXJnaW46IDVweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIH1cblxuICBwIHtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgY29sb3I6ICNmNzdlMjE7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgbWFyZ2luOiAwZW07XG4gIH1cblxuICBpb24tYmFjay1idXR0b24ge1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgfVxufVxuXG4ubWVhc3VyZW1lbnRzIHtcbiAgcGFkZGluZzogMjBweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgbWFyZ2luLXRvcDogMjBweDtcblxuICBoNCB7XG4gICAgY29sb3I6ICNmNzdlMjE7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gIH1cblxuICBpbWcge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwYWRkaW5nOiAxMDBweCAyMHB4O1xuICAgIG1hcmdpbjogMCBhdXRvO1xuICB9XG5cbiAgaDUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgfVxuXG4gIHAge1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgICBtYXJnaW46IDNweDtcbiAgfVxufVxuXG5ociB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XG59XG5cbi53b3Jrb3V0LXNlY3Rpb24ge1xuICAvKnBhZGRpbmc6IDIwcHg7XG4gIGJhY2tncm91bmQ6ICNmZmY7Ki9cblxuICAud29ya291dC1pbWFnZSB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuXG4gICAgaW1nIHtcbiAgICAgIG1hcmdpbi10b3A6IDE1cHg7XG4gICAgfVxuXG4gICAgLnVwbG9hZC1pbWcge1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAvLyAgIHRvcDogMjAlO1xuICAgICAgdG9wOiAxMCU7XG5cbiAgICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiAyMCU7XG4gICAgICB9XG5cbiAgICAgIHAge1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgICAgIG1hcmdpbjogMHB4O1xuICAgICAgfVxuICAgIH1cblxuICAgIHAge1xuICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgICBtYXJnaW46IDBweDtcbiAgICB9XG4gIH1cblxuICAuY29udGVudCB7XG4gICAgcGFkZGluZzogMjBweDtcblxuICAgIGlvbi1yb3cge1xuICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkZGQ7XG4gICAgfVxuXG4gICAgaW9uLWxhYmVsIHtcbiAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBwYWRkaW5nLXRvcDogMTBweDtcbiAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgICAgbGluZS1oZWlnaHQ6IDM4cHg7XG4gICAgICBmb250LXdlaWdodDogNjAwO1xuICAgIH1cblxuICAgIGlvbi1pbnB1dCB7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgIH1cblxuICAgIGg0LmhlYWRpbmcge1xuICAgICAgbWFyZ2luLXRvcDogMHB4O1xuICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgY29sb3I6ICNmNzdlMjE7XG4gICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgfVxuICB9XG5cbiAgLm1vbnRobHktY29udGVudCB7XG4gICAgcGFkZGluZzogMjBweDtcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgIGJvcmRlci10b3A6IDEwcHggc29saWQgI2ViZWJlYjtcblxuICAgIGlvbi1jb2wge1xuICAgICAgcGFkZGluZzogMDtcbiAgICB9XG5cbiAgICBpb24tY29sLmV4cy1jb250ZW50IHtcbiAgICAgIHBhZGRpbmctbGVmdDogMThweDtcbiAgICB9XG5cbiAgICBpb24tY29sLnNlY3Rpb24taW1nIHtcbiAgICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICM4MjgyODI7XG4gICAgfVxuXG4gICAgaDQge1xuICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgY29sb3I6ICNmNzdlMjE7XG4gICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgfVxuXG4gICAgaDUge1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICBtYXJnaW46IDA7XG4gICAgfVxuXG4gICAgcCB7XG4gICAgICBjb2xvcjogIzIyMjtcbiAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgICAgbWFyZ2luOiAwO1xuICAgIH1cblxuICAgIC5mcm9udC1pbWcge1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgLy9wYWRkaW5nLXRvcDogMzBweDtcbiAgICAgIC8vIG1hcmdpbi1yaWdodDogMThweDtcbiAgICAgIC8vIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICM4MjgyODI7XG4gICAgfVxuICB9XG59XG4uaGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcblxuICAvLyBwYWRkaW5nOiAxNnB4O1xuICAuYWxpZ24tY2VudGVyIHtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB9XG5cbiAgaW9uLXRpdGxlIHtcbiAgICBwYWRkaW5nOiAwcHg7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgICBtYXJnaW4tbGVmdDogMzVweDtcbiAgfVxuXG4gIGlvbi1iYWNrLWJ1dHRvbiB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgfVxuXG4gIGlvbi1pY29uIHtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgfVxuXG4gIHAge1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBjb2xvcjogI2Y3N2UyMTtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgICBtYXJnaW46IDBlbTtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIH1cbn0iLCIuaGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbn1cbi5oZWFkZXIgaW9uLXRpdGxlIHtcbiAgcGFkZGluZzogMHB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgcGFkZGluZy1sZWZ0OiA0MnB4O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xufVxuLmhlYWRlciBpb24tbWVudS1idXR0b24ge1xuICBjb2xvcjogI2ZmZjtcbn1cbi5oZWFkZXIgaW9uLWljb24ge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBtYXJnaW46IDVweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLmhlYWRlciBwIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBjb2xvcjogI2Y3N2UyMTtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gIG1hcmdpbjogMGVtO1xufVxuLmhlYWRlciBpb24tYmFjay1idXR0b24ge1xuICBmb250LXNpemU6IDEycHg7XG59XG5cbi5tZWFzdXJlbWVudHMge1xuICBwYWRkaW5nOiAyMHB4O1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuLm1lYXN1cmVtZW50cyBoNCB7XG4gIGNvbG9yOiAjZjc3ZTIxO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbn1cbi5tZWFzdXJlbWVudHMgaW1nIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiAxMDBweCAyMHB4O1xuICBtYXJnaW46IDAgYXV0bztcbn1cbi5tZWFzdXJlbWVudHMgaDUge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xufVxuLm1lYXN1cmVtZW50cyBwIHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgbWFyZ2luOiAzcHg7XG59XG5cbmhyIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2RkZDtcbn1cblxuLndvcmtvdXQtc2VjdGlvbiB7XG4gIC8qcGFkZGluZzogMjBweDtcbiAgYmFja2dyb3VuZDogI2ZmZjsqL1xufVxuLndvcmtvdXQtc2VjdGlvbiAud29ya291dC1pbWFnZSB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDAgYXV0bztcbiAgYmFja2dyb3VuZDogI2ZmZjtcbn1cbi53b3Jrb3V0LXNlY3Rpb24gLndvcmtvdXQtaW1hZ2UgaW1nIHtcbiAgbWFyZ2luLXRvcDogMTVweDtcbn1cbi53b3Jrb3V0LXNlY3Rpb24gLndvcmtvdXQtaW1hZ2UgLnVwbG9hZC1pbWcge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiAxMDAlO1xuICB0b3A6IDEwJTtcbn1cbi53b3Jrb3V0LXNlY3Rpb24gLndvcmtvdXQtaW1hZ2UgLnVwbG9hZC1pbWcgaW1nIHtcbiAgd2lkdGg6IDIwJTtcbn1cbi53b3Jrb3V0LXNlY3Rpb24gLndvcmtvdXQtaW1hZ2UgLnVwbG9hZC1pbWcgcCB7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgbWFyZ2luOiAwcHg7XG59XG4ud29ya291dC1zZWN0aW9uIC53b3Jrb3V0LWltYWdlIHAge1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgbWFyZ2luOiAwcHg7XG59XG4ud29ya291dC1zZWN0aW9uIC5jb250ZW50IHtcbiAgcGFkZGluZzogMjBweDtcbn1cbi53b3Jrb3V0LXNlY3Rpb24gLmNvbnRlbnQgaW9uLXJvdyB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZGRkO1xufVxuLndvcmtvdXQtc2VjdGlvbiAuY29udGVudCBpb24tbGFiZWwge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LXNpemU6IDE0cHg7XG4gIHBhZGRpbmctdG9wOiAxMHB4O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgbGluZS1oZWlnaHQ6IDM4cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG4ud29ya291dC1zZWN0aW9uIC5jb250ZW50IGlvbi1pbnB1dCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuLndvcmtvdXQtc2VjdGlvbiAuY29udGVudCBoNC5oZWFkaW5nIHtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBmb250LXNpemU6IDE4cHg7XG4gIGNvbG9yOiAjZjc3ZTIxO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbn1cbi53b3Jrb3V0LXNlY3Rpb24gLm1vbnRobHktY29udGVudCB7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGJvcmRlci10b3A6IDEwcHggc29saWQgI2ViZWJlYjtcbn1cbi53b3Jrb3V0LXNlY3Rpb24gLm1vbnRobHktY29udGVudCBpb24tY29sIHtcbiAgcGFkZGluZzogMDtcbn1cbi53b3Jrb3V0LXNlY3Rpb24gLm1vbnRobHktY29udGVudCBpb24tY29sLmV4cy1jb250ZW50IHtcbiAgcGFkZGluZy1sZWZ0OiAxOHB4O1xufVxuLndvcmtvdXQtc2VjdGlvbiAubW9udGhseS1jb250ZW50IGlvbi1jb2wuc2VjdGlvbi1pbWcge1xuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjODI4MjgyO1xufVxuLndvcmtvdXQtc2VjdGlvbiAubW9udGhseS1jb250ZW50IGg0IHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBjb2xvcjogI2Y3N2UyMTtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG59XG4ud29ya291dC1zZWN0aW9uIC5tb250aGx5LWNvbnRlbnQgaDUge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbjogMDtcbn1cbi53b3Jrb3V0LXNlY3Rpb24gLm1vbnRobHktY29udGVudCBwIHtcbiAgY29sb3I6ICMyMjI7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBtYXJnaW46IDA7XG59XG4ud29ya291dC1zZWN0aW9uIC5tb250aGx5LWNvbnRlbnQgLmZyb250LWltZyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIC5hbGlnbi1jZW50ZXIge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmhlYWRlciBpb24tdGl0bGUge1xuICBwYWRkaW5nOiAwcHg7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBtYXJnaW4tbGVmdDogMzVweDtcbn1cbi5oZWFkZXIgaW9uLWJhY2stYnV0dG9uIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBmb250LXNpemU6IDE0cHg7XG59XG4uaGVhZGVyIGlvbi1pY29uIHtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cbi5oZWFkZXIgcCB7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6ICNmNzdlMjE7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICBtYXJnaW46IDBlbTtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/assessment/assessment.page.ts":
/*!***********************************************!*\
  !*** ./src/app/assessment/assessment.page.ts ***!
  \***********************************************/
/*! exports provided: AssessmentPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AssessmentPage", function() { return AssessmentPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _service_component_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../service/component.service */ "./src/app/service/component.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _service_events_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../service/events.service */ "./src/app/service/events.service.ts");








let AssessmentPage = class AssessmentPage {
    constructor(events, actionSheetController, camera, route, formBuilder, componentService) {
        this.events = events;
        this.actionSheetController = actionSheetController;
        this.camera = camera;
        this.route = route;
        this.formBuilder = formBuilder;
        this.componentService = componentService;
        this.assessmentData = '';
        this.image = '';
        this.assessmentForm = this.formBuilder.group({
            total_weight: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])],
            lean_weight: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])],
            fat: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])],
            fat_percantage: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])],
            hydration_percentage: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])],
        });
        this.route.queryParams.subscribe(params => {
            if (params && params.type) {
                this.pageValue = params.type;
                console.log(this.pageValue);
                if (this.pageValue == 'assessment') {
                    console.log(localStorage.getItem('assessments'));
                    if (localStorage.getItem('assessments') != undefined && localStorage.getItem('assessments') != null) {
                        this.assessmentData = JSON.parse(localStorage.getItem('assessments'));
                        this.assessmentData.iamge = JSON.parse(localStorage.getItem('assessments')).image;
                    }
                    else {
                        this.assessmentData = {
                            'total_weight': 52,
                            'lean_weight': 40,
                            'fat': 50,
                            'fat_percantage': 50,
                            'hydration_percentage': 20,
                            'image': null
                        };
                    }
                    // localStorage.setItem('assessments', JSON.stringify(this.assessmentData));
                    console.log(this.assessmentData);
                }
            }
        });
        // assessment
        this.events.subscribe('assessments:created', (data) => {
            console.log(JSON.parse(localStorage.getItem('assessments')));
            this.assessmentData = JSON.parse(localStorage.getItem('assessments'));
            this.assessmentData.iamge = JSON.parse(localStorage.getItem('assessments')).image;
        });
    }
    ngOnInit() {
        if (this.pageValue == 'assessment') {
            this.assessmentForm.patchValue({
                total_weight: this.assessmentData.total_weight,
                lean_weight: this.assessmentData.lean_weight,
                fat: this.assessmentData.fat,
                fat_percantage: this.assessmentData.fat_percantage,
                hydration_percentage: this.assessmentData.hydration_percentage,
            });
        }
    }
    selectImage() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: "Select Image source",
                buttons: [{
                        text: 'Load from Library',
                        handler: () => {
                            this.openCamera(this.camera.PictureSourceType.PHOTOLIBRARY);
                        }
                    },
                    {
                        text: 'Use Camera',
                        handler: () => {
                            this.openCamera(this.camera.PictureSourceType.CAMERA);
                        }
                    },
                    {
                        text: 'Cancel',
                        role: 'cancel'
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    openCamera(sourceType) {
        // this.picture = '';
        const options = {
            quality: 40,
            sourceType: sourceType,
            destinationType: this.camera.DestinationType.DATA_URL,
            // targetWidth: 300,
            // targetHeight: 300,
            mediaType: this.camera.MediaType.PICTURE,
            correctOrientation: true
        };
        this.camera.getPicture(options).then((imageData) => {
            this.image = 'data:image/jpeg;base64,' + imageData;
            this.assessmentData = {
                'total_weight': this.assessmentForm.value.total_weight,
                'lean_weight': this.assessmentForm.value.lean_weight,
                'fat': this.assessmentForm.value.fat,
                'fat_percantage': this.assessmentForm.value.fat_percantage,
                'hydration_percentage': this.assessmentForm.value.hydration_percentage,
                'image': this.image
            };
            localStorage.setItem('assessments', JSON.stringify(this.assessmentData));
            this.events.publish('assessments:created', { user: JSON.stringify(this.assessmentData) });
        }, (err) => {
            // Handle error
            alert(JSON.stringify(err));
        });
    }
    update() {
        if (!this.assessmentForm.valid) {
            return false;
        }
        else {
            this.assessmentData = {
                'total_weight': this.assessmentForm.value.total_weight,
                'lean_weight': this.assessmentForm.value.lean_weight,
                'fat': this.assessmentForm.value.fat,
                'fat_percantage': this.assessmentForm.value.fat_percantage,
                'hydration_percentage': this.assessmentForm.value.hydration_percentage,
                'image': this.image
            };
            localStorage.setItem('assessments', JSON.stringify(this.assessmentData));
            console.log(JSON.parse(localStorage.getItem('assessments')));
            this.events.publish('assessments:created', { user: JSON.stringify(this.assessmentData) });
            this.componentService.presentToast('success', 'Assessment updated successfully!');
            //  this.navCtrl.navigateBack("/profile");
        }
    }
    ;
};
AssessmentPage.ctorParameters = () => [
    { type: _service_events_service__WEBPACK_IMPORTED_MODULE_7__["EventsService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ActionSheetController"] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__["Camera"],] }] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
    { type: _service_component_service__WEBPACK_IMPORTED_MODULE_4__["ComponentService"] }
];
AssessmentPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-assessment',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./assessment.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/assessment/assessment.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./assessment.page.scss */ "./src/app/assessment/assessment.page.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__["Camera"]))
], AssessmentPage);



/***/ })

}]);
//# sourceMappingURL=assessment-assessment-module-es2015.js.map