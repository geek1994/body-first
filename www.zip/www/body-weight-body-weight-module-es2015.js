(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["body-weight-body-weight-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/body-weight/body-weight.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/body-weight/body-weight.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <!-- <div class=\"header\">\n    <ion-row>\n      <ion-col size=\"1\">\n        <ion-icon name=\"menu-outline\"></ion-icon>\n        <ion-buttons slot=\"start\">\n          <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n      </ion-col>\n      <ion-col size=\"9\">\n        <ion-title> THIS WEEK WORKOUT</ion-title>\n      </ion-col>\n      <ion-col size=\"2\" text-right>\n        <ion-icon name=\"settings-outline\" class=\"setting\"></ion-icon>\n      </ion-col>\n    </ion-row>\n  </div> -->\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>BODY WEIGHT TRAINING</ion-title>\n    <!-- <ion-buttons slot=\"end\">\n        <ion-icon name=\"settings-outline\" (click)=\"settings()\" class=\"setting\"></ion-icon>\n      </ion-buttons> -->\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!-- <div *ngIf=\"!isSpinner\" class=\"spinner-div\">\n    <ion-spinner  name=\"bubbles\"></ion-spinner>\n  </div> -->\n \n  <div class=\"workout\">\n    <!-- <ion-row>\n      <ion-col size=\"6\"> -->\n        <div class=\"video-icons\" *ngFor=\"let bodylist of body_list\">\n          <iframe  *ngIf=\"bodylist?.url!= null \" style= \"z-index:999\" height=\"200px\" width=\"100%\" preload=\"none\" target=\"_parent\"  [src]=\"bodylist?.trustedVideoUrl\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\n        </div>\n      <!-- </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n            <img src=\"assets/images/video.png\" />\n          </div>\n        </div>\n      </ion-col>\n    </ion-row> -->\n    <!-- <ion-row>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n            <img src=\"assets/images/video.png\" />\n          </div>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n            <img src=\"assets/images/video.png\" />\n          </div>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n            <img src=\"assets/images/video.png\" />\n          </div>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n            <img src=\"assets/images/video.png\" />\n          </div>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n            <img src=\"assets/images/video.png\" />\n          </div>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n            <img src=\"assets/images/video.png\" />\n          </div>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n            <img src=\"assets/images/video.png\" />\n          </div>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n            <img src=\"assets/images/video.png\" />\n          </div>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n            <img src=\"assets/images/video.png\" />\n          </div>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"video-icons\">\n          <img src=\"assets/images/workout.png\" />\n          <div class=\"video-icon\">\n            <img src=\"assets/images/video.png\" />\n          </div>\n        </div>\n      </ion-col>\n    </ion-row> -->\n    <div class=\"divider\"></div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/body-weight/body-weight-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/body-weight/body-weight-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: BodyWeightPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BodyWeightPageRoutingModule", function() { return BodyWeightPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _body_weight_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./body-weight.page */ "./src/app/body-weight/body-weight.page.ts");




const routes = [
    {
        path: '',
        component: _body_weight_page__WEBPACK_IMPORTED_MODULE_3__["BodyWeightPage"]
    }
];
let BodyWeightPageRoutingModule = class BodyWeightPageRoutingModule {
};
BodyWeightPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], BodyWeightPageRoutingModule);



/***/ }),

/***/ "./src/app/body-weight/body-weight.module.ts":
/*!***************************************************!*\
  !*** ./src/app/body-weight/body-weight.module.ts ***!
  \***************************************************/
/*! exports provided: BodyWeightPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BodyWeightPageModule", function() { return BodyWeightPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _body_weight_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./body-weight-routing.module */ "./src/app/body-weight/body-weight-routing.module.ts");
/* harmony import */ var _body_weight_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./body-weight.page */ "./src/app/body-weight/body-weight.page.ts");







let BodyWeightPageModule = class BodyWeightPageModule {
};
BodyWeightPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _body_weight_routing_module__WEBPACK_IMPORTED_MODULE_5__["BodyWeightPageRoutingModule"]
        ],
        declarations: [_body_weight_page__WEBPACK_IMPORTED_MODULE_6__["BodyWeightPage"]]
    })
], BodyWeightPageModule);



/***/ }),

/***/ "./src/app/body-weight/body-weight.page.scss":
/*!***************************************************!*\
  !*** ./src/app/body-weight/body-weight.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 16px;\n  text-align: left;\n  padding-left: 50px;\n  letter-spacing: 1px;\n  font-family: Rajdhani-Regular;\n  line-height: 14px;\n  display: block;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header .setting {\n  float: right;\n  margin-right: 10px;\n  color: #fff;\n}\n.workout {\n  padding: 20px;\n  text-align: center;\n  position: relative;\n}\n.workout h3 {\n  font-size: 24px;\n  font-family: Rajdhani-Regular;\n  text-align: left;\n}\n.workout .video-icons {\n  width: 49%;\n  float: left;\n  margin-right: 3px;\n}\n.workout .divider {\n  border-top: 1px solid #a9a6a6;\n  margin-top: 20px;\n  margin-bottom: 20px;\n}\n.workout img {\n  position: relative;\n  width: 100%;\n}\n.workout ion-icon {\n  position: absolute;\n  text-align: center;\n  left: 32%;\n  color: #fff;\n  top: 27%;\n  font-size: 40px;\n  padding: 10px;\n  border-radius: 100px;\n}\n.workout .work-out-box {\n  position: relative;\n  overflow: hidden;\n}\n.workout .work-out-box h4 {\n  position: absolute;\n  bottom: 0px;\n  color: #fff;\n  text-align: center;\n  font-size: 16px;\n  background: #f77e21;\n  width: 100%;\n  padding: 5px;\n  margin: 0;\n  border-radius: 0 0 8px 8px;\n}\n.spinner-div {\n  text-align: center;\n  font-size: 54px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL2JvZHktd2VpZ2h0L2JvZHktd2VpZ2h0LnBhZ2Uuc2NzcyIsInNyYy9hcHAvYm9keS13ZWlnaHQvYm9keS13ZWlnaHQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7QUNDRjtBREFFO0VBQ0UsYUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLDZCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FDRUo7QURBRTtFQUNFLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUNFSjtBREFFO0VBQ0UsV0FBQTtBQ0VKO0FEQUU7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FDRUo7QURDQTtFQUNFLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDRUY7QURERTtFQUNFLGVBQUE7RUFDQSw2QkFBQTtFQUNBLGdCQUFBO0FDR0o7QURERTtFQUNFLFVBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7QUNHSjtBRFdFO0VBQ0UsNkJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDVEo7QURXRTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtBQ1RKO0FEV0U7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7RUFDQSxvQkFBQTtBQ1RKO0FEV0U7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0FDVEo7QURVSTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtFQUNBLDBCQUFBO0FDUk47QURZQTtFQUVFLGtCQUFBO0VBQ0EsZUFBQTtBQ1ZGIiwiZmlsZSI6InNyYy9hcHAvYm9keS13ZWlnaHQvYm9keS13ZWlnaHQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG4gIGlvbi10aXRsZSB7XG4gICAgcGFkZGluZzogMTZweDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIHBhZGRpbmctbGVmdDogNTBweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgIGxpbmUtaGVpZ2h0OiAxNHB4O1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICB9XG4gIGlvbi1pY29uIHtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgfVxuICBpb24tbWVudS1idXR0b24ge1xuICAgIGNvbG9yOiAjZmZmO1xuICB9XG4gIC5zZXR0aW5nIHtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIGNvbG9yOiAjZmZmO1xuICB9XG59XG4ud29ya291dCB7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBoMyB7XG4gICAgZm9udC1zaXplOiAyNHB4O1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gIH1cbiAgLnZpZGVvLWljb25zIHtcbiAgICB3aWR0aDogNDklO1xuICAgIGZsb2F0OiBsZWZ0O1xuICAgIG1hcmdpbi1yaWdodDogM3B4O1xuICAgIC8vIC52aWRlby1pY29uIHtcbiAgICAvLyAgIG1hcmdpbjogMCBhdXRvO1xuICAgIC8vICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIC8vICAgdG9wOiAzNCU7XG4gICAgLy8gICByaWdodDogMDtcbiAgICAvLyAgIGxlZnQ6IDA7XG4gICAgLy8gICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgLy8gICBpbWcge1xuICAgIC8vICAgICB3aWR0aDogYXV0bztcbiAgICAvLyAgIH1cbiAgICAvLyB9XG4gIH1cblxuICAuZGl2aWRlciB7XG4gICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNhOWE2YTY7XG4gICAgbWFyZ2luLXRvcDogMjBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICB9XG4gIGltZyB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG4gIGlvbi1pY29uIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGxlZnQ6IDMyJTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICB0b3A6IDI3JTtcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgcGFkZGluZzogMTBweDtcbiAgICBib3JkZXItcmFkaXVzOiAxMDBweDtcbiAgfVxuICAud29yay1vdXQtYm94IHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICBoNCB7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICBib3R0b206IDBweDtcbiAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgYmFja2dyb3VuZDogI2Y3N2UyMTtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgcGFkZGluZzogNXB4O1xuICAgICAgbWFyZ2luOiAwO1xuICAgICAgYm9yZGVyLXJhZGl1czogMCAwIDhweCA4cHg7XG4gICAgfVxuICB9XG59XG4uc3Bpbm5lci1kaXZ7XG5cbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDU0cHg7XG5cblxufSIsIi5oZWFkZXIge1xuICAtLWJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIGNvbG9yOiAjZmZmO1xufVxuLmhlYWRlciBpb24tdGl0bGUge1xuICBwYWRkaW5nOiAxNnB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBwYWRkaW5nLWxlZnQ6IDUwcHg7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBsaW5lLWhlaWdodDogMTRweDtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4uaGVhZGVyIGlvbi1pY29uIHtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cbi5oZWFkZXIgaW9uLW1lbnUtYnV0dG9uIHtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIC5zZXR0aW5nIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4ud29ya291dCB7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLndvcmtvdXQgaDMge1xuICBmb250LXNpemU6IDI0cHg7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuLndvcmtvdXQgLnZpZGVvLWljb25zIHtcbiAgd2lkdGg6IDQ5JTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIG1hcmdpbi1yaWdodDogM3B4O1xufVxuLndvcmtvdXQgLmRpdmlkZXIge1xuICBib3JkZXItdG9wOiAxcHggc29saWQgI2E5YTZhNjtcbiAgbWFyZ2luLXRvcDogMjBweDtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbn1cbi53b3Jrb3V0IGltZyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgd2lkdGg6IDEwMCU7XG59XG4ud29ya291dCBpb24taWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBsZWZ0OiAzMiU7XG4gIGNvbG9yOiAjZmZmO1xuICB0b3A6IDI3JTtcbiAgZm9udC1zaXplOiA0MHB4O1xuICBwYWRkaW5nOiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMDBweDtcbn1cbi53b3Jrb3V0IC53b3JrLW91dC1ib3gge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG4ud29ya291dCAud29yay1vdXQtYm94IGg0IHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDBweDtcbiAgY29sb3I6ICNmZmY7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBiYWNrZ3JvdW5kOiAjZjc3ZTIxO1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZzogNXB4O1xuICBtYXJnaW46IDA7XG4gIGJvcmRlci1yYWRpdXM6IDAgMCA4cHggOHB4O1xufVxuXG4uc3Bpbm5lci1kaXYge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogNTRweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/body-weight/body-weight.page.ts":
/*!*************************************************!*\
  !*** ./src/app/body-weight/body-weight.page.ts ***!
  \*************************************************/
/*! exports provided: BodyWeightPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BodyWeightPage", function() { return BodyWeightPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");



let BodyWeightPage = class BodyWeightPage {
    // isSpinner :boolean=false;
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
        this.weightData = [
            { id: 1, url: "https://www.youtube.com/watch?v=mUns8O4YL5M" },
            { id: 2, url: "https://www.youtube.com/watch?v=oAPCPjnU1wA" },
            { id: 3, url: "https://www.youtube.com/watch?v=dJlFmxiL11s" },
            { id: 4, url: "https://www.youtube.com/watch?v=GFus5TyIlCM" },
            { id: 5, url: "https://www.youtube.com/watch?v=zTPfzlZbtz8" },
            { id: 6, url: "https://www.youtube.com/watch?v=jZK1m2G1nyQ" },
        ];
        this.body_list = [];
        var that = this;
        // this.isSpinner = true;
        this.weightData.forEach((element) => {
            if (element.url != null) {
                const url = that.validateYouTubeUrl(element.url);
                console.log("url:- ", url);
                const pos = element.url.indexOf("watch");
                console.log(pos);
                if (pos !== -1) {
                    element.url = element.url.replace("watch?v=", "embed/");
                }
                else {
                    const pos = element.url.indexOf("youtu.be"); // 0
                    if (pos !== -1) {
                        element.url.replace("youtu.be", "www.youtube.com/embed/" + url.vidId);
                    }
                    else {
                        element.url;
                    }
                }
                console.log("element:-----", element.url);
                element["trustedVideoUrl"] = this.sanitizer.bypassSecurityTrustResourceUrl(element.url);
                console.log("ooooo", element);
            }
            this.body_list.push(element);
            // this.postlist = data.data.data;
            console.log(this.body_list);
        });
    }
    ngOnInit() { }
    validateYouTubeUrl(element) {
        if (element !== undefined || element !== "") {
            console.log("URL-->", element);
            const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|\?v=)([^#\&\?]*).*/;
            const match = element.match(regExp);
            if (match && match[2].length === 11) {
                console.log("MATCH YOUTUBE", match[2]);
                return { type: "youtube", vidId: match[2] };
            }
            else {
                return { type: "video" };
            }
        }
    }
};
BodyWeightPage.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"] }
];
BodyWeightPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-body-weight",
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./body-weight.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/body-weight/body-weight.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./body-weight.page.scss */ "./src/app/body-weight/body-weight.page.scss")).default]
    })
], BodyWeightPage);



/***/ })

}]);
//# sourceMappingURL=body-weight-body-weight-module-es2015.js.map