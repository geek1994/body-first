function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["bodyfirst-program-bodyfirst-program-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/bodyfirst-program/bodyfirst-program.page.html":
  /*!*****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/bodyfirst-program/bodyfirst-program.page.html ***!
    \*****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppBodyfirstProgramBodyfirstProgramPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\" text=\"\" icon=\"chevron-back-outline\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>BODYF1RST PROGRAM</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"program\">\n    <img src=\"assets/images/program.png\" />\n\n    <div class=\"content\">\n      <p>Take your workout to the next level!!</p>\n      <ul>\n        <li>\n          <ion-icon name=\"checkmark-circle-outline\"></ion-icon> Train any time with customized workouts each week.\n        </li>\n        <li>\n          <ion-icon name=\"checkmark-circle-outline\"></ion-icon> Meal Plan to fit your goals.\n        </li>\n        <li>\n          <ion-icon name=\"checkmark-circle-outline\"></ion-icon> Core 4 Optimization with Spirit, <br> Mindset, Nutrition\n          and\n          Exercise!\n        </li>\n      </ul>\n      <div class=\"button-center\">\n        <ion-button class=\"start-button\" (click)=\"getStarted()\">GET STARTED <ion-icon name=\"arrow-forward-outline\">\n          </ion-icon>\n        </ion-button>\n      </div>\n    </div>\n  </div>\n\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/bodyfirst-program/bodyfirst-program-routing.module.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/bodyfirst-program/bodyfirst-program-routing.module.ts ***!
    \***********************************************************************/

  /*! exports provided: BodyfirstProgramPageRoutingModule */

  /***/
  function srcAppBodyfirstProgramBodyfirstProgramRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BodyfirstProgramPageRoutingModule", function () {
      return BodyfirstProgramPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _bodyfirst_program_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./bodyfirst-program.page */
    "./src/app/bodyfirst-program/bodyfirst-program.page.ts");

    var routes = [{
      path: '',
      component: _bodyfirst_program_page__WEBPACK_IMPORTED_MODULE_3__["BodyfirstProgramPage"]
    }];

    var BodyfirstProgramPageRoutingModule = function BodyfirstProgramPageRoutingModule() {
      _classCallCheck(this, BodyfirstProgramPageRoutingModule);
    };

    BodyfirstProgramPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], BodyfirstProgramPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/bodyfirst-program/bodyfirst-program.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/bodyfirst-program/bodyfirst-program.module.ts ***!
    \***************************************************************/

  /*! exports provided: BodyfirstProgramPageModule */

  /***/
  function srcAppBodyfirstProgramBodyfirstProgramModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BodyfirstProgramPageModule", function () {
      return BodyfirstProgramPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _bodyfirst_program_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./bodyfirst-program-routing.module */
    "./src/app/bodyfirst-program/bodyfirst-program-routing.module.ts");
    /* harmony import */


    var _bodyfirst_program_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./bodyfirst-program.page */
    "./src/app/bodyfirst-program/bodyfirst-program.page.ts");

    var BodyfirstProgramPageModule = function BodyfirstProgramPageModule() {
      _classCallCheck(this, BodyfirstProgramPageModule);
    };

    BodyfirstProgramPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _bodyfirst_program_routing_module__WEBPACK_IMPORTED_MODULE_5__["BodyfirstProgramPageRoutingModule"]],
      declarations: [_bodyfirst_program_page__WEBPACK_IMPORTED_MODULE_6__["BodyfirstProgramPage"]]
    })], BodyfirstProgramPageModule);
    /***/
  },

  /***/
  "./src/app/bodyfirst-program/bodyfirst-program.page.scss":
  /*!***************************************************************!*\
    !*** ./src/app/bodyfirst-program/bodyfirst-program.page.scss ***!
    \***************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppBodyfirstProgramBodyfirstProgramPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-toolbar {\n  --background: #233942;\n  color: #fff;\n}\nion-toolbar ion-back-button {\n  font-size: 12px;\n}\nion-toolbar ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 30px;\n  letter-spacing: 1px;\n}\nion-toolbar ion-title ion-icon {\n  vertical-align: middle;\n}\n.program img {\n  width: 100%;\n}\n.program .content {\n  padding: 20px;\n}\n.program .content p {\n  font-family: Rajdhani-Bold;\n  font-size: 20px;\n}\n.program .content ul {\n  padding-left: 0;\n  list-style: none;\n}\n.program .content ul li {\n  list-style: none;\n  line-height: 24px;\n  font-family: Rajdhani-Regular;\n  font-size: 18px;\n  display: flex;\n  margin-bottom: 10px;\n  margin-left: 28px;\n}\n.program .content ul li ion-icon {\n  margin-right: 10px;\n  font-size: 22px;\n  color: #f77e21;\n  vertical-align: middle;\n  position: absolute;\n  left: 20px;\n}\n.button-center {\n  margin: 0 auto;\n  text-align: center;\n}\n.button-center ion-button {\n  --background: #233942;\n  --border-radius: 0px;\n  font-size: 15px;\n  width: 150px;\n  height: 40px;\n  font-family: Rajdhani-Regular;\n}\n.button-center ion-button ion-icon {\n  margin-left: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL2JvZHlmaXJzdC1wcm9ncmFtL2JvZHlmaXJzdC1wcm9ncmFtLnBhZ2Uuc2NzcyIsInNyYy9hcHAvYm9keWZpcnN0LXByb2dyYW0vYm9keWZpcnN0LXByb2dyYW0ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7RUFDQSxXQUFBO0FDQ0o7QURDSTtFQUNJLGVBQUE7QUNDUjtBREVJO0VBQ0ksWUFBQTtFQUNBLGdCQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDQVI7QURFUTtFQUNJLHNCQUFBO0FDQVo7QURNSTtFQUNJLFdBQUE7QUNIUjtBRE1JO0VBQ0ksYUFBQTtBQ0pSO0FETVE7RUFDSSwwQkFBQTtFQUNBLGVBQUE7QUNKWjtBRE9RO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0FDTFo7QURPWTtFQUNJLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSw2QkFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQ0xoQjtBRE9nQjtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtBQ0xwQjtBRFlBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0FDVEo7QURXSTtFQUNJLHFCQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSw2QkFBQTtBQ1RSO0FEV1E7RUFDSSxpQkFBQTtBQ1RaIiwiZmlsZSI6InNyYy9hcHAvYm9keWZpcnN0LXByb2dyYW0vYm9keWZpcnN0LXByb2dyYW0ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICBjb2xvcjogI2ZmZjtcblxuICAgIGlvbi1iYWNrLWJ1dHRvbiB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICB9XG5cbiAgICBpb24tdGl0bGUge1xuICAgICAgICBwYWRkaW5nOiAwcHg7XG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDMwcHg7XG4gICAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG5cbiAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnByb2dyYW0ge1xuICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgIH1cblxuICAgIC5jb250ZW50IHtcbiAgICAgICAgcGFkZGluZzogMjBweDtcblxuICAgICAgICBwIHtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgdWwge1xuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAwO1xuICAgICAgICAgICAgbGlzdC1zdHlsZTogbm9uZTtcblxuICAgICAgICAgICAgbGkge1xuICAgICAgICAgICAgICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG4gICAgICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMjhweDtcblxuICAgICAgICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDIycHg7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjZjc3ZTIxO1xuICAgICAgICAgICAgICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgIGxlZnQ6IDIwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG4uYnV0dG9uLWNlbnRlciB7XG4gICAgbWFyZ2luOiAwIGF1dG87XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gICAgaW9uLWJ1dHRvbiB7XG4gICAgICAgIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICAgICAgLS1ib3JkZXItcmFkaXVzOiAwcHg7XG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgICAgd2lkdGg6IDE1MHB4O1xuICAgICAgICBoZWlnaHQ6IDQwcHg7XG4gICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuXG4gICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgICAgICB9XG4gICAgfVxufSIsImlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbn1cbmlvbi10b29sYmFyIGlvbi1iYWNrLWJ1dHRvbiB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cbmlvbi10b29sYmFyIGlvbi10aXRsZSB7XG4gIHBhZGRpbmc6IDBweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIHBhZGRpbmctbGVmdDogMzBweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbn1cbmlvbi10b29sYmFyIGlvbi10aXRsZSBpb24taWNvbiB7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG59XG5cbi5wcm9ncmFtIGltZyB7XG4gIHdpZHRoOiAxMDAlO1xufVxuLnByb2dyYW0gLmNvbnRlbnQge1xuICBwYWRkaW5nOiAyMHB4O1xufVxuLnByb2dyYW0gLmNvbnRlbnQgcCB7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICBmb250LXNpemU6IDIwcHg7XG59XG4ucHJvZ3JhbSAuY29udGVudCB1bCB7XG4gIHBhZGRpbmctbGVmdDogMDtcbiAgbGlzdC1zdHlsZTogbm9uZTtcbn1cbi5wcm9ncmFtIC5jb250ZW50IHVsIGxpIHtcbiAgbGlzdC1zdHlsZTogbm9uZTtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBmb250LXNpemU6IDE4cHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAyOHB4O1xufVxuLnByb2dyYW0gLmNvbnRlbnQgdWwgbGkgaW9uLWljb24ge1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMjJweDtcbiAgY29sb3I6ICNmNzdlMjE7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMjBweDtcbn1cblxuLmJ1dHRvbi1jZW50ZXIge1xuICBtYXJnaW46IDAgYXV0bztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLmJ1dHRvbi1jZW50ZXIgaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgLS1ib3JkZXItcmFkaXVzOiAwcHg7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgd2lkdGg6IDE1MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xufVxuLmJ1dHRvbi1jZW50ZXIgaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/bodyfirst-program/bodyfirst-program.page.ts":
  /*!*************************************************************!*\
    !*** ./src/app/bodyfirst-program/bodyfirst-program.page.ts ***!
    \*************************************************************/

  /*! exports provided: BodyfirstProgramPage */

  /***/
  function srcAppBodyfirstProgramBodyfirstProgramPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BodyfirstProgramPage", function () {
      return BodyfirstProgramPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var BodyfirstProgramPage = /*#__PURE__*/function () {
      function BodyfirstProgramPage(navCtrl) {
        _classCallCheck(this, BodyfirstProgramPage);

        this.navCtrl = navCtrl;
      }

      _createClass(BodyfirstProgramPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "getStarted",
        value: function getStarted() {
          this.navCtrl.navigateForward('/survey');
        }
      }]);

      return BodyfirstProgramPage;
    }();

    BodyfirstProgramPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    BodyfirstProgramPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-bodyfirst-program',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./bodyfirst-program.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/bodyfirst-program/bodyfirst-program.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./bodyfirst-program.page.scss */
      "./src/app/bodyfirst-program/bodyfirst-program.page.scss"))["default"]]
    })], BodyfirstProgramPage);
    /***/
  }
}]);
//# sourceMappingURL=bodyfirst-program-bodyfirst-program-module-es5.js.map