(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["signup-signup-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/signup/signup.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/signup/signup.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\" text=\"\" icon=\"chevron-back-outline\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>\n      <!-- <ion-icon name=\"chevron-back-outline\"></ion-icon>  -->\n      SIGNUP</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"signupForm\">  \n    <div class=\"login-form\">\n      <ion-input placeholder=\"Name\" type=\"text\" formControlName=\"name\"></ion-input>\n      <p class=\"error\" *ngIf=\"signupForm.get('name').hasError('required') && signupForm.get('name').touched\">Enter name.</p>\n      <ion-input placeholder=\"Email\" type=\"email\" formControlName=\"email\"></ion-input>\n      <p class=\"error\" *ngIf=\"signupForm.get('email').hasError('required') && signupForm.get('email').touched\">Enter email address.</p>\n      <p class=\"error\" *ngIf=\"signupForm.get('email').hasError('pattern') && signupForm.get('email').touched\">Invalid email address.</p>\n      <ion-input placeholder=\"Password\" type=\"password\" formControlName=\"password\" (keyup)=\"vrifyConfirmpassword()\"></ion-input>\n      <p class=\"error\" *ngIf=\"signupForm.get('password').hasError('required') && signupForm.get('password').touched\">Enter password.</p>\n      <ion-input placeholder=\"Confirm Password\" type=\"password\" formControlName=\"confirmpassword\" (keyup)=\"vrifyConfirmpassword()\"></ion-input>\n      <p class=\"error\" *ngIf=\"signupForm.get('confirmpassword').hasError('required') && signupForm.get('confirmpassword').touched\">Enter confirm password.</p>\n      <p class=\"error\" *ngIf=\"passwordCheck\">Password and Confirm Password not matched.</p>\n      <!-- <ion-select placeholder=\"Select Gender\" formControlName=\"gender\">\n        <ion-select-option value=\"f\">Female</ion-select-option>\n        <ion-select-option value=\"m\">Male</ion-select-option>\n      </ion-select>\n      <p class=\"error\" *ngIf=\"signupForm.get('gender').hasError('required') && signupForm.get('gender').touched\">Choose gender.</p> -->\n\n      <div class=\"divider\"></div>\n      <div class=\"button-center\">\n        <ion-button class=\"start-button\" (click)=\"getStarted()\" [disabled]=\"!signupForm.valid\" >\n          <!-- GET STARTED  -->\n          NEXT\n          <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n        </ion-button>\n      </div>\n  \n    </div>\n  </form>\n\n  <div class=\"bottom\">\n    <p text-center (click)=\"goTo('/signIn')\">Already have an account?</p>\n    <ion-button class=\"signup-button\" (click)=\"signIn()\">SIGN IN</ion-button>\n\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/signup/signup-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/signup/signup-routing.module.ts ***!
  \*************************************************/
/*! exports provided: SignupPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPageRoutingModule", function() { return SignupPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _signup_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./signup.page */ "./src/app/signup/signup.page.ts");




const routes = [
    {
        path: '',
        component: _signup_page__WEBPACK_IMPORTED_MODULE_3__["SignupPage"]
    }
];
let SignupPageRoutingModule = class SignupPageRoutingModule {
};
SignupPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SignupPageRoutingModule);



/***/ }),

/***/ "./src/app/signup/signup.module.ts":
/*!*****************************************!*\
  !*** ./src/app/signup/signup.module.ts ***!
  \*****************************************/
/*! exports provided: SignupPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPageModule", function() { return SignupPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _signup_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./signup-routing.module */ "./src/app/signup/signup-routing.module.ts");
/* harmony import */ var _signup_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./signup.page */ "./src/app/signup/signup.page.ts");








let SignupPageModule = class SignupPageModule {
};
SignupPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _signup_routing_module__WEBPACK_IMPORTED_MODULE_5__["SignupPageRoutingModule"]
        ],
        declarations: [_signup_page__WEBPACK_IMPORTED_MODULE_6__["SignupPage"]]
    })
], SignupPageModule);



/***/ }),

/***/ "./src/app/signup/signup.page.scss":
/*!*****************************************!*\
  !*** ./src/app/signup/signup.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  --background: #233942;\n  color: #fff;\n}\nion-toolbar ion-title {\n  padding: 16px;\n  text-align: left;\n  padding-left: 30px;\n  letter-spacing: 1px;\n  text-transform: uppercase;\n  font-family: Rajdhani-Regular;\n}\nion-toolbar ion-title ion-icon {\n  vertical-align: middle;\n}\nion-toolbar ion-back-button {\n  display: block;\n  font-size: 12px;\n}\nion-content {\n  background-color: #f9f9f9;\n  --background: #f9f9f9;\n  font-family: Rajdhani-Regular;\n}\nion-content .login-form {\n  padding: 40px 20px;\n}\nion-content .login-form .divider {\n  border-top: 1px solid #a9a6a6;\n  margin-top: 40px;\n  margin-bottom: 40px;\n}\nion-content .login-form ion-input {\n  border: 1px solid #c7bbbb;\n  border-radius: 5px;\n  margin-bottom: 20px;\n  --padding-start: 10px !important;\n  font-size: 15px !important;\n  height: 45px;\n  font-family: Rajdhani-Regular;\n  background: #fff !important;\n}\nion-content .login-form .button-center {\n  margin: 0 auto;\n  text-align: center;\n}\nion-content .login-form .button-center ion-button {\n  --background: #233942;\n  --border-radius: 0px;\n  font-size: 15px;\n  width: 150px;\n  height: 40px;\n  letter-spacing: 1px;\n  font-family: Rajdhani-Regular;\n}\nion-content .login-form .button-center ion-button ion-icon {\n  margin-left: 10px;\n}\nion-content .social-login {\n  padding: 40px;\n}\nion-content .social-login .fb-button {\n  --background: #3a5997;\n  padding: 10px;\n  color: #fff;\n  font-family: Rajdhani-Regular;\n  width: 100%;\n  height: 60px;\n  position: relative;\n  --border-radius: 5px;\n}\nion-content .social-login .fb-button ion-icon {\n  color: #fff;\n  text-align: left;\n  position: absolute;\n  left: 0px;\n}\nion-content .social-login .gg-button {\n  --background: #0076fe;\n  padding: 10px;\n  color: #fff;\n  font-family: Rajdhani-Regular;\n  width: 100%;\n  height: 60px;\n  position: relative;\n  --border-radius: 5px;\n}\nion-content .social-login .gg-button ion-icon {\n  color: #fff;\n  text-align: left;\n  position: absolute;\n  left: 0px;\n}\n.bottom {\n  bottom: 20px;\n  margin: 0 auto;\n  text-align: center;\n  width: 100%;\n}\n.bottom p {\n  text-align: center;\n  color: #f77e21;\n}\n.bottom ion-button {\n  --background: #fff;\n  color: #222;\n  text-align: center;\n  text-transform: uppercase;\n  width: 90%;\n  margin: 10px 20px;\n  border-radius: 10px;\n  border: 1px solid #222;\n  font-family: Rajdhani-SemiBold;\n  overflow: hidden;\n}\nion-select {\n  border: 1px solid #c7bbbb;\n  border-radius: 5px;\n  margin-bottom: 20px;\n  --padding-start: 10px !important;\n  font-size: 15px !important;\n  height: 45px;\n  font-family: Rajdhani-Regular;\n  background: #fff !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL3NpZ251cC9zaWdudXAucGFnZS5zY3NzIiwic3JjL2FwcC9zaWdudXAvc2lnbnVwLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0VBQ0EsV0FBQTtBQ0NKO0FEQ0k7RUFDSSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSw2QkFBQTtBQ0NSO0FEQ1E7RUFDSSxzQkFBQTtBQ0NaO0FER0k7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQ0RSO0FES0E7RUFDSSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0EsNkJBQUE7QUNGSjtBRElJO0VBQ0ksa0JBQUE7QUNGUjtBRElRO0VBQ0ksNkJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDRlo7QURLUTtFQUNJLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdDQUFBO0VBQ0EsMEJBQUE7RUFDQSxZQUFBO0VBRUEsNkJBQUE7RUFDQSwyQkFBQTtBQ0paO0FET1E7RUFDSSxjQUFBO0VBQ0Esa0JBQUE7QUNMWjtBRE9ZO0VBQ0kscUJBQUE7RUFDQSxvQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsNkJBQUE7QUNMaEI7QURPZ0I7RUFDSSxpQkFBQTtBQ0xwQjtBRFdJO0VBQ0ksYUFBQTtBQ1RSO0FEV1E7RUFDSSxxQkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7QUNUWjtBRFdZO0VBQ0ksV0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0FDVGhCO0FEYVE7RUFDSSxxQkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7QUNYWjtBRGFZO0VBQ0ksV0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0FDWGhCO0FEaUJBO0VBRUksWUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUNmSjtBRGlCSTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQ2ZSO0FEa0JJO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUVBLFVBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSw4QkFBQTtFQUNBLGdCQUFBO0FDakJSO0FEb0JBO0VBQ0kseUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0NBQUE7RUFDQSwwQkFBQTtFQUNBLFlBQUE7RUFDQSw2QkFBQTtFQUNBLDJCQUFBO0FDakJKIiwiZmlsZSI6InNyYy9hcHAvc2lnbnVwL3NpZ251cC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICAgIGNvbG9yOiAjZmZmO1xuXG4gICAgaW9uLXRpdGxlIHtcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAzMHB4O1xuICAgICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcblxuICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgaW9uLWJhY2stYnV0dG9uIHtcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICB9XG59XG5cbmlvbi1jb250ZW50IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjlmOWY5O1xuICAgIC0tYmFja2dyb3VuZDogI2Y5ZjlmOTtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcblxuICAgIC5sb2dpbi1mb3JtIHtcbiAgICAgICAgcGFkZGluZzogNDBweCAyMHB4O1xuXG4gICAgICAgIC5kaXZpZGVyIHtcbiAgICAgICAgICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjYTlhNmE2O1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogNDBweDtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDQwcHg7XG4gICAgICAgIH1cblxuICAgICAgICBpb24taW5wdXQge1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2M3YmJiYjtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gICAgICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDEwcHggIWltcG9ydGFudDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweCAhaW1wb3J0YW50O1xuICAgICAgICAgICAgaGVpZ2h0OiA0NXB4O1xuICAgICAgICAgICAgLy8gdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZiAhaW1wb3J0YW50O1xuICAgICAgICB9XG5cbiAgICAgICAgLmJ1dHRvbi1jZW50ZXIge1xuICAgICAgICAgICAgbWFyZ2luOiAwIGF1dG87XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgICAgICAgICAgIGlvbi1idXR0b24ge1xuICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICAgICAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDBweDtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDE1MHB4O1xuICAgICAgICAgICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgICAgICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuXG4gICAgICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuc29jaWFsLWxvZ2luIHtcbiAgICAgICAgcGFkZGluZzogNDBweDtcblxuICAgICAgICAuZmItYnV0dG9uIHtcbiAgICAgICAgICAgIC0tYmFja2dyb3VuZDogIzNhNTk5NztcbiAgICAgICAgICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICBoZWlnaHQ6IDYwcHg7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDVweDtcblxuICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgIGxlZnQ6IDBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5nZy1idXR0b24ge1xuICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiAjMDA3NmZlO1xuICAgICAgICAgICAgcGFkZGluZzogMTBweDtcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgIGhlaWdodDogNjBweDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogNXB4O1xuXG4gICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgbGVmdDogMHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG4uYm90dG9tIHtcbiAgICAvL3Bvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBib3R0b206IDIwcHg7XG4gICAgbWFyZ2luOiAwIGF1dG87XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIC8vIG1hcmdpbi10b3A6IDQwJTtcbiAgICBwIHtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICBjb2xvcjogI2Y3N2UyMTtcbiAgICB9XG5cbiAgICBpb24tYnV0dG9uIHtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xuICAgICAgICBjb2xvcjogIzIyMjtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgICAvLy0tYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICB3aWR0aDogOTAlO1xuICAgICAgICBtYXJnaW46IDEwcHggMjBweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgIzIyMjtcbiAgICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVNlbWlCb2xkO1xuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIH1cbn1cbmlvbi1zZWxlY3R7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2M3YmJiYjtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDEwcHggIWltcG9ydGFudDtcbiAgICBmb250LXNpemU6IDE1cHggIWltcG9ydGFudDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgYmFja2dyb3VuZDogI2ZmZiAhaW1wb3J0YW50O1xufSIsImlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbn1cbmlvbi10b29sYmFyIGlvbi10aXRsZSB7XG4gIHBhZGRpbmc6IDE2cHg7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHBhZGRpbmctbGVmdDogMzBweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG59XG5pb24tdG9vbGJhciBpb24tdGl0bGUgaW9uLWljb24ge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuaW9uLXRvb2xiYXIgaW9uLWJhY2stYnV0dG9uIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjlmOWY5O1xuICAtLWJhY2tncm91bmQ6ICNmOWY5Zjk7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xufVxuaW9uLWNvbnRlbnQgLmxvZ2luLWZvcm0ge1xuICBwYWRkaW5nOiA0MHB4IDIwcHg7XG59XG5pb24tY29udGVudCAubG9naW4tZm9ybSAuZGl2aWRlciB7XG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjYTlhNmE2O1xuICBtYXJnaW4tdG9wOiA0MHB4O1xuICBtYXJnaW4tYm90dG9tOiA0MHB4O1xufVxuaW9uLWNvbnRlbnQgLmxvZ2luLWZvcm0gaW9uLWlucHV0IHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2M3YmJiYjtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAtLXBhZGRpbmctc3RhcnQ6IDEwcHggIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxNXB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogNDVweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIGJhY2tncm91bmQ6ICNmZmYgIWltcG9ydGFudDtcbn1cbmlvbi1jb250ZW50IC5sb2dpbi1mb3JtIC5idXR0b24tY2VudGVyIHtcbiAgbWFyZ2luOiAwIGF1dG87XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbmlvbi1jb250ZW50IC5sb2dpbi1mb3JtIC5idXR0b24tY2VudGVyIGlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIC0tYm9yZGVyLXJhZGl1czogMHB4O1xuICBmb250LXNpemU6IDE1cHg7XG4gIHdpZHRoOiAxNTBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbn1cbmlvbi1jb250ZW50IC5sb2dpbi1mb3JtIC5idXR0b24tY2VudGVyIGlvbi1idXR0b24gaW9uLWljb24ge1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cbmlvbi1jb250ZW50IC5zb2NpYWwtbG9naW4ge1xuICBwYWRkaW5nOiA0MHB4O1xufVxuaW9uLWNvbnRlbnQgLnNvY2lhbC1sb2dpbiAuZmItYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjM2E1OTk3O1xuICBwYWRkaW5nOiAxMHB4O1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDYwcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgLS1ib3JkZXItcmFkaXVzOiA1cHg7XG59XG5pb24tY29udGVudCAuc29jaWFsLWxvZ2luIC5mYi1idXR0b24gaW9uLWljb24ge1xuICBjb2xvcjogI2ZmZjtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwcHg7XG59XG5pb24tY29udGVudCAuc29jaWFsLWxvZ2luIC5nZy1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6ICMwMDc2ZmU7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNjBweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAtLWJvcmRlci1yYWRpdXM6IDVweDtcbn1cbmlvbi1jb250ZW50IC5zb2NpYWwtbG9naW4gLmdnLWJ1dHRvbiBpb24taWNvbiB7XG4gIGNvbG9yOiAjZmZmO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDBweDtcbn1cblxuLmJvdHRvbSB7XG4gIGJvdHRvbTogMjBweDtcbiAgbWFyZ2luOiAwIGF1dG87XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgd2lkdGg6IDEwMCU7XG59XG4uYm90dG9tIHAge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZjc3ZTIxO1xufVxuLmJvdHRvbSBpb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xuICBjb2xvcjogIzIyMjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICB3aWR0aDogOTAlO1xuICBtYXJnaW46IDEwcHggMjBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgIzIyMjtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVNlbWlCb2xkO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG5pb24tc2VsZWN0IHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2M3YmJiYjtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAtLXBhZGRpbmctc3RhcnQ6IDEwcHggIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxNXB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogNDVweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIGJhY2tncm91bmQ6ICNmZmYgIWltcG9ydGFudDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/signup/signup.page.ts":
/*!***************************************!*\
  !*** ./src/app/signup/signup.page.ts ***!
  \***************************************/
/*! exports provided: SignupPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPage", function() { return SignupPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _service_api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../service/api.service */ "./src/app/service/api.service.ts");
/* harmony import */ var _service_component_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../service/component.service */ "./src/app/service/component.service.ts");






let SignupPage = class SignupPage {
    constructor(navCtrl, menuController, formBuilder, api, componentService) {
        this.navCtrl = navCtrl;
        this.menuController = menuController;
        this.formBuilder = formBuilder;
        this.api = api;
        this.componentService = componentService;
        this.passwordCheck = false;
        this.menuController.swipeGesture(false);
        this.signupForm = this.formBuilder.group({
            name: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])],
            email: [
                "",
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$"),
                ]),
            ],
            password: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])],
            confirmpassword: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])],
        });
    }
    ngOnInit() { }
    vrifyConfirmpassword() {
        if (this.signupForm.value.confirmpassword != "") {
            console.log(this.signupForm.value.password, this.signupForm.value.confirmpassword);
            if (this.signupForm.value.password == this.signupForm.value.confirmpassword) {
                this.passwordCheck = false;
            }
            else {
                this.passwordCheck = true;
            }
        }
    }
    signIn() {
        this.navCtrl.back();
    }
    getStarted() {
        localStorage.setItem('userData', JSON.stringify(this.signupForm.value));
        this.navCtrl.navigateForward("/subscriptions");
        return false;
        // this.navCtrl.navigateRoot('/week-workout');
        // this.navCtrl.navigateForward("/subscriptions");
        this.componentService.presentLoading();
        var data = {
            name: this.signupForm.value.name,
            email: this.signupForm.value.email,
            password: this.signupForm.value.password,
        };
        console.log(data, "data");
        this.api.signup("/register", data).subscribe((res) => {
            console.log("res:- ", res);
            this.componentService.dismissLoading();
            if (res["success"]) {
                // Plugins.Storage.set({ key: 'userData', value: JSON.stringify(res['data']) });
                this.componentService.presentToast("success", res["message"]);
                this.signupForm.reset();
                // this.navCtrl.navigateForward("/survey");
                this.navCtrl.navigateForward("/subscriptions");
            }
            else {
                this.componentService.presentToast("error", res["message"]);
            }
        }, (err) => {
            this.componentService.dismissLoading();
            console.log("login error:- ", err);
        });
    }
    goTo(url) {
        this.navCtrl.back();
    }
};
SignupPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
    { type: _service_api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"] },
    { type: _service_component_service__WEBPACK_IMPORTED_MODULE_5__["ComponentService"] }
];
SignupPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-signup",
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./signup.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/signup/signup.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./signup.page.scss */ "./src/app/signup/signup.page.scss")).default]
    })
], SignupPage);



/***/ })

}]);
//# sourceMappingURL=signup-signup-module-es2015.js.map