(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["liked-exercises-liked-exercises-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/liked-exercises/liked-exercises.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/liked-exercises/liked-exercises.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>LIKED EXERCISES</ion-title>\n    <ion-buttons slot=\"end\">\n      <!-- <ion-icon name=\"close\"></ion-icon> -->\n    </ion-buttons>\n  </ion-toolbar>\n  </ion-header>\n\n<ion-content>\n <div class=\"liked\" *ngFor=\"let exercise of likedExercises let i = index;\">\n    <div class=\"exercise-box\">\n      <img src=\"{{exercise?.image}}\">\n      <!-- <ion-icon name=\"heart-outline\"></ion-icon> -->\n      <ion-icon name=\"heart\" ios=\"ios-heart\" style=\"color: #f77e21;\" (click)=\"unlike(i)\"></ion-icon>\n\n      <!-- color: #f77e21; -->\n      <h4>{{exercise?.name}}</h4>\n    </div>\n </div>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/liked-exercises/liked-exercises-routing.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/liked-exercises/liked-exercises-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: LikedExercisesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LikedExercisesPageRoutingModule", function() { return LikedExercisesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _liked_exercises_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./liked-exercises.page */ "./src/app/liked-exercises/liked-exercises.page.ts");




const routes = [
    {
        path: '',
        component: _liked_exercises_page__WEBPACK_IMPORTED_MODULE_3__["LikedExercisesPage"]
    }
];
let LikedExercisesPageRoutingModule = class LikedExercisesPageRoutingModule {
};
LikedExercisesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LikedExercisesPageRoutingModule);



/***/ }),

/***/ "./src/app/liked-exercises/liked-exercises.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/liked-exercises/liked-exercises.module.ts ***!
  \***********************************************************/
/*! exports provided: LikedExercisesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LikedExercisesPageModule", function() { return LikedExercisesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _liked_exercises_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./liked-exercises-routing.module */ "./src/app/liked-exercises/liked-exercises-routing.module.ts");
/* harmony import */ var _liked_exercises_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./liked-exercises.page */ "./src/app/liked-exercises/liked-exercises.page.ts");







let LikedExercisesPageModule = class LikedExercisesPageModule {
};
LikedExercisesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _liked_exercises_routing_module__WEBPACK_IMPORTED_MODULE_5__["LikedExercisesPageRoutingModule"]
        ],
        declarations: [_liked_exercises_page__WEBPACK_IMPORTED_MODULE_6__["LikedExercisesPage"]]
    })
], LikedExercisesPageModule);



/***/ }),

/***/ "./src/app/liked-exercises/liked-exercises.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/liked-exercises/liked-exercises.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header {\n  --background:#233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 50px;\n  letter-spacing: 1px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n  margin-right: 10px;\n}\n.header .search {\n  text-align: right;\n  float: right;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\n.header ion-icon.close {\n  float: right;\n  color: #fff;\n  font-size: 18px;\n}\n.liked {\n  padding: 20px;\n}\n.liked .exercise-box {\n  position: relative;\n}\n.liked .exercise-box ion-icon {\n  position: absolute;\n  top: 10px;\n  right: 10px;\n  color: #fff;\n  font-size: 24px;\n}\n.liked .exercise-box img {\n  width: 100%;\n}\n.liked .exercise-box h4 {\n  background: #f77e21;\n  color: #fff;\n  font-family: Rajdhani-Regular;\n  position: absolute;\n  text-align: center;\n  padding: 5px;\n  width: 100%;\n  bottom: 3px;\n  margin: 0;\n  border-radius: 0px 0px 10px 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL2xpa2VkLWV4ZXJjaXNlcy9saWtlZC1leGVyY2lzZXMucGFnZS5zY3NzIiwic3JjL2FwcC9saWtlZC1leGVyY2lzZXMvbGlrZWQtZXhlcmNpc2VzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FDQ0o7QURFSTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0FKO0FER0k7RUFDSSxXQUFBO0FDRFI7QURHSTtFQUNJLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ0RSO0FER0k7RUFDSSxpQkFBQTtFQUNBLFlBQUE7QUNEUjtBREdJO0VBQ0ksWUFBQTtFQUNBLGNBQUE7RUFDSiwwQkFBQTtFQUNBLFdBQUE7QUNESjtBRElJO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FDRlI7QURLQTtFQUNJLGFBQUE7QUNGSjtBREdJO0VBQ0ksa0JBQUE7QUNEUjtBREVRO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FDQVo7QURFUTtFQUNFLFdBQUE7QUNBVjtBREVRO0VBQ0ksbUJBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0FDQVoiLCJmaWxlIjoic3JjL2FwcC9saWtlZC1leGVyY2lzZXMvbGlrZWQtZXhlcmNpc2VzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJ7XG4gICAgLS1iYWNrZ3JvdW5kOiMyMzM5NDI7XG4gICAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICBjb2xvcjojZmZmO1xuICAgIC8vcGFkZGluZzogIDE2cHg7XG5cbiAgICBpb24tdGl0bGV7XG4gICAgcGFkZGluZzogMHB4O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgcGFkZGluZy1sZWZ0OjUwcHg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICBcbiAgICB9IFxuICAgIGlvbi1tZW51LWJ1dHRvbntcbiAgICAgICAgY29sb3I6I2ZmZjtcbiAgICB9XG4gICAgaW9uLWljb257XG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgICAgIGNvbG9yOiNmZmY7XG4gICAgICAgIGZvbnQtc2l6ZToyMHB4O1xuICAgICAgICBtYXJnaW4tcmlnaHQ6MTBweDtcbiAgICB9XG4gICAgLnNlYXJjaHtcbiAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gICAgICAgIGZsb2F0OiByaWdodDtcbiAgICB9XG4gICAgcHtcbiAgICAgICAgZmxvYXQ6cmlnaHQ7XG4gICAgICAgIGNvbG9yOiNmNzdlMjE7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgbWFyZ2luOiAwZW07XG4gICAgfSBcblxuICAgIGlvbi1pY29uLmNsb3Nle1xuICAgICAgICBmbG9hdDpyaWdodDtcbiAgICAgICAgY29sb3I6I2ZmZjtcbiAgICAgICAgZm9udC1zaXplOjE4cHg7XG4gICAgfVxufVxuLmxpa2Vke1xuICAgIHBhZGRpbmc6MjBweDtcbiAgICAuZXhlcmNpc2UtYm94e1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgdG9wOiAxMHB4O1xuICAgICAgICAgICAgcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICAgICAgfVxuICAgICAgICBpbWd7XG4gICAgICAgICAgd2lkdGg6MTAwJTtcbiAgICAgICAgfVxuICAgICAgICBoNHtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmNzdlMjE7XG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAgICAgcGFkZGluZzogNXB4O1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICBib3R0b206IDNweDtcbiAgICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDBweCAwcHggMTBweCAxMHB4O1xuICAgICAgICB9XG4gICAgfVxufSIsIi5oZWFkZXIge1xuICAtLWJhY2tncm91bmQ6IzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi10aXRsZSB7XG4gIHBhZGRpbmc6IDBweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIHBhZGRpbmctbGVmdDogNTBweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbn1cbi5oZWFkZXIgaW9uLW1lbnUtYnV0dG9uIHtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi1pY29uIHtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLmhlYWRlciAuc2VhcmNoIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGZsb2F0OiByaWdodDtcbn1cbi5oZWFkZXIgcCB7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6ICNmNzdlMjE7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICBtYXJnaW46IDBlbTtcbn1cbi5oZWFkZXIgaW9uLWljb24uY2xvc2Uge1xuICBmbG9hdDogcmlnaHQ7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDE4cHg7XG59XG5cbi5saWtlZCB7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG4ubGlrZWQgLmV4ZXJjaXNlLWJveCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5saWtlZCAuZXhlcmNpc2UtYm94IGlvbi1pY29uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDEwcHg7XG4gIHJpZ2h0OiAxMHB4O1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyNHB4O1xufVxuLmxpa2VkIC5leGVyY2lzZS1ib3ggaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG59XG4ubGlrZWQgLmV4ZXJjaXNlLWJveCBoNCB7XG4gIGJhY2tncm91bmQ6ICNmNzdlMjE7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDVweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvdHRvbTogM3B4O1xuICBtYXJnaW46IDA7XG4gIGJvcmRlci1yYWRpdXM6IDBweCAwcHggMTBweCAxMHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/liked-exercises/liked-exercises.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/liked-exercises/liked-exercises.page.ts ***!
  \*********************************************************/
/*! exports provided: LikedExercisesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LikedExercisesPage", function() { return LikedExercisesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _service_component_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/component.service */ "./src/app/service/component.service.ts");



let LikedExercisesPage = class LikedExercisesPage {
    constructor(componentService) {
        this.componentService = componentService;
        this.likedExercises = [
            { 'id': 1, 'name': 'Shoulder', 'image': 'assets/images/liked.png' },
            { 'id': 2, 'name': 'Hand', 'image': 'assets/images/ExerciseScreen.jpg' },
            { 'id': 3, 'name': 'Abs', 'image': 'assets/images/abs.png' },
        ];
    }
    ngOnInit() {
    }
    unlike(index) {
        this.componentService.presentToast('success', "Unliked successfully");
        this.likedExercises.splice(index, 1);
    }
};
LikedExercisesPage.ctorParameters = () => [
    { type: _service_component_service__WEBPACK_IMPORTED_MODULE_2__["ComponentService"] }
];
LikedExercisesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-liked-exercises',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./liked-exercises.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/liked-exercises/liked-exercises.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./liked-exercises.page.scss */ "./src/app/liked-exercises/liked-exercises.page.scss")).default]
    })
], LikedExercisesPage);



/***/ })

}]);
//# sourceMappingURL=liked-exercises-liked-exercises-module-es2015.js.map