(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["subscriptions-subscriptions-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/subscriptions/subscriptions.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/subscriptions/subscriptions.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\" text=\"\" icon=\"chevron-back-outline\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>SUBSCRIPTION</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"plan\">\n    <div class=\"plan-video\">\n      <img src=\"assets/images/program.png\" />\n      <div class=\"plan-heading\">\n        <h1>Get your 7 Day trial risk free with any plan!</h1>\n      </div>\n    </div>\n  </div>\n  <div class=\"plan-body\">\n    <h3 class=\"plan-body-heading\">HOW COMMITTED ARE YOU?</h3>\n    <div class=\"plan-list-div\" *ngIf=\"subscriptionData.length>0\">\n\n      <div class=\"plan-list-plan\" (click)=\"purchasePlan()\" *ngFor=\"let data of subscriptionData\">\n        <div class=\"plan-right\">\n          <span class=\"plan-heading\">{{data.trial_name}}</span>\n          <br />\n          <span class=\"plan-description\">{{data.trial_payment}}</span>\n        </div>\n        <div class=\"plan-left\">\n          <span class=\"plan-price\">{{data.trial_type}}<ion-icon name=\"chevron-forward-outline\"></ion-icon></span>\n        </div>\n      </div>\n<!-- \n      <div class=\"plan-list-plan\" (click)=\"purchasePlan()\">\n        <span class=\"save-plan-badge\">\n          Save 20%\n        </span>\n        <div class=\"plan-right\">\n          <span class=\"plan-heading\">See Results</span>\n          <br />\n          <span class=\"plan-description\">3 Months</span>\n        </div>\n        <div class=\"plan-left\">\n          <span class=\"plan-price\">$ 44.99 <ion-icon name=\"chevron-forward-outline\"></ion-icon></span>\n        </div>\n      </div>\n\n      <div class=\"plan-list-plan\" (click)=\"purchasePlan()\">\n        <span class=\"save-plan-badge\">\n          Save 50%\n        </span>\n        <div class=\"plan-right\">\n          <span class=\"plan-heading\">Keep Results</span>\n          <br />\n          <span class=\"plan-description\">12 Months</span>\n        </div>\n        <div class=\"plan-left\">\n          <span class=\"plan-price\">$ 119.99 <ion-icon name=\"chevron-forward-outline\"></ion-icon></span>\n        </div>\n      </div> -->\n\n    </div>\n    <div class=\"plan-list-div\" *ngIf=\"subscriptionData.length==0\">\n      <p>No Data Found!</p>\n    </div>\n  </div>\n  <!-- <div class=\"tabs\">\n    <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck1\" checked />\n      <label class=\"tab-label\" for=\"chck1\">Apple Pay</label>\n      <div class=\"tab-content\">\n        <ion-row>\n          <ion-col size=\"2\">\n            <img src=\"assets/images/profile-img.png\" />\n          </ion-col>\n          <ion-col size=\"6\">\n            <h4>1 Month Premium</h4>\n            <p>BODYFIRST</p>\n            <p>Fitness Coach Plans</p>\n          </ion-col>\n          <ion-col size=\"4\">\n            <h5>₹ 600.00/1month</h5>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n    <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck2\" />\n      <label class=\"tab-label\" for=\"chck2\"\n        ><img src=\"assets/images/apple.png\" /> Visa-5175</label\n      >\n      <div class=\"tab-content\"></div>\n    </div>\n    <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck3\" checked />\n      <label class=\"tab-label\" for=\"chck3\"\n        >Cancel anytime in Subscription in Apple Pay</label\n      >\n      <div class=\"tab-content\">\n        <p>\n          You will be charged 600.00 automatically 1 month untill you cancel.\n          Learn how to cancel.\n        </p>\n      </div>\n    </div>\n  </div> -->\n  <!-- <div class=\"bottom-btn\">\n    <ion-button class=\"subscribe-btn\">SUBSCRIBE</ion-button>\n  </div> -->\n</ion-content>");

/***/ }),

/***/ "./src/app/subscriptions/subscriptions-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/subscriptions/subscriptions-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: SubscriptionsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscriptionsPageRoutingModule", function() { return SubscriptionsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _subscriptions_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./subscriptions.page */ "./src/app/subscriptions/subscriptions.page.ts");




const routes = [
    {
        path: '',
        component: _subscriptions_page__WEBPACK_IMPORTED_MODULE_3__["SubscriptionsPage"]
    }
];
let SubscriptionsPageRoutingModule = class SubscriptionsPageRoutingModule {
};
SubscriptionsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SubscriptionsPageRoutingModule);



/***/ }),

/***/ "./src/app/subscriptions/subscriptions.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/subscriptions/subscriptions.module.ts ***!
  \*******************************************************/
/*! exports provided: SubscriptionsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscriptionsPageModule", function() { return SubscriptionsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _subscriptions_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./subscriptions-routing.module */ "./src/app/subscriptions/subscriptions-routing.module.ts");
/* harmony import */ var _subscriptions_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./subscriptions.page */ "./src/app/subscriptions/subscriptions.page.ts");







let SubscriptionsPageModule = class SubscriptionsPageModule {
};
SubscriptionsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _subscriptions_routing_module__WEBPACK_IMPORTED_MODULE_5__["SubscriptionsPageRoutingModule"]
        ],
        declarations: [_subscriptions_page__WEBPACK_IMPORTED_MODULE_6__["SubscriptionsPage"]]
    })
], SubscriptionsPageModule);



/***/ }),

/***/ "./src/app/subscriptions/subscriptions.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/subscriptions/subscriptions.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@charset \"UTF-8\";\nion-content {\n  font-family: Rajdhani-Regular;\n}\n.header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 30px;\n  letter-spacing: 1px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n  margin: 5px;\n  margin-right: 10px;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\n.header ion-back-button {\n  font-size: 12px;\n}\n.plan-video {\n  text-align: center;\n  position: relative;\n}\n.plan-video img {\n  position: relative;\n  width: 100%;\n}\n.tabs {\n  border-radius: 8px;\n  overflow: hidden;\n}\n.tab {\n  width: 100%;\n  color: white;\n  overflow: hidden;\n  position: relative;\n}\n.tab-label {\n  display: flex;\n  border-bottom: 1px solid #dddddd;\n  justify-content: space-between;\n  background: #fff;\n  margin-bottom: 10px;\n  padding: 0.8rem;\n  font-size: 15px;\n  letter-spacing: 1px;\n  font-weight: bold;\n  cursor: pointer;\n  color: #222;\n  font-family: Rajdhani-Regular;\n  /* Icon */\n}\n.tab-label::after {\n  content: \"❯\";\n  width: 1em;\n  height: 1em;\n  text-align: center;\n  transition: all 0.35s;\n}\n.tab-content {\n  max-height: 0;\n  padding: 0 1em;\n  color: #2c3e50;\n  font-family: Rajdhani-Regular;\n  font-size: 14px;\n  background: white;\n  transition: all 0.35s;\n}\n.tab-content h4 {\n  padding-left: 0;\n  margin: 0;\n  font-size: 16px;\n  font-weight: 600;\n  font-family: Rajdhani-SemiBold;\n}\n.tab-content h5 {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 600;\n  font-family: Rajdhani-SemiBold;\n}\n.tab-content p {\n  margin: 0;\n}\n.tab-content ion-toggle {\n  float: right;\n}\n.tab-close {\n  display: flex;\n  justify-content: flex-end;\n  padding: 1em;\n  font-size: 0.75em;\n  background: #fff;\n  cursor: pointer;\n}\n.tab-close:hover {\n  background: #1a252f;\n}\ninput[type=checkbox]:checked,\ninput[type=radio]:checked {\n  background: #f77e21;\n}\ninput:checked + .tab-label {\n  background: #fff;\n}\ninput:checked + .tab-label::after {\n  transform: rotate(90deg);\n}\ninput[type=checkbox],\ninput[type=radio] {\n  padding: 0;\n  position: absolute;\n  left: 10px;\n  top: 14px;\n  display: none;\n}\ninput:checked ~ .tab-content {\n  max-height: 100vh;\n  padding: 0 1em;\n}\n.bottom-btn {\n  text-align: center;\n  margin: 40px auto;\n}\n.bottom-btn ion-button.subscribe-btn {\n  --background: #00a651;\n  background: #00a651;\n  --border-radius: 0px;\n  border: 1px solid #00a651;\n  text-align: center;\n  color: #fff;\n  width: 200px;\n  letter-spacing: 1px;\n}\n.plan-heading h1 {\n  padding: 12px 25px;\n  margin: 0px;\n  color: #2b931d;\n}\n.plan-body {\n  background-image: linear-gradient(0deg, #31464e, #31464eb3), url('catalyst.jpg');\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n  color: #fff;\n  padding-top: 20px;\n  margin-top: 25px;\n  padding-bottom: 20px;\n}\n.plan-body .plan-body-heading {\n  margin: 0px;\n  text-align: center;\n  margin-bottom: 30px;\n  letter-spacing: 2px;\n  font-family: Rajdhani-SemiBold;\n}\n.plan-list-div {\n  padding: 10px;\n}\n.plan-list-plan {\n  padding: 4px 15px;\n  border: 1px solid #fff;\n  border-radius: 12px;\n  margin-bottom: 40px;\n  position: relative;\n}\n.plan-list-plan .plan-price {\n  float: right;\n}\n.plan-right {\n  width: 60%;\n  display: inline-block;\n}\n.plan-left {\n  width: 40%;\n  display: inline-block;\n  vertical-align: super;\n}\n.plan-left ion-icon {\n  top: 3px;\n  position: relative;\n}\n.plan-heading {\n  font-size: 20px;\n  font-weight: 600;\n  letter-spacing: 1px;\n  font-family: Rajdhani-Regular;\n}\n.plan-heading h1 {\n  font-family: Rajdhani-SemiBold;\n  text-shadow: 1px 1px 3px #37323436;\n}\n.plan-description {\n  font-size: 20px;\n  font-family: Rajdhani-Regular;\n}\n.plan-price {\n  font-size: 20px;\n  font-family: Rajdhani-SemiBold;\n}\n.save-plan-badge {\n  position: absolute;\n  right: 11%;\n  top: -25%;\n  background: #00a651;\n  padding: 4px 20px;\n  border-radius: 30px;\n  font-size: 18px;\n  font-family: Rajdhani-Regular;\n  letter-spacing: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3Vic2NyaXB0aW9ucy9zdWJzY3JpcHRpb25zLnBhZ2Uuc2NzcyIsIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL3N1YnNjcmlwdGlvbnMvc3Vic2NyaXB0aW9ucy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FDQWhCO0VBQ0UsNkJBQUE7QURFRjtBQ0NBO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7QURFRjtBQ0NFO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FEQ0o7QUNFRTtFQUNFLFdBQUE7QURBSjtBQ0dFO0VBQ0Usc0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBRERKO0FDSUU7RUFDRSxZQUFBO0VBQ0EsY0FBQTtFQUNBLDBCQUFBO0VBQ0EsV0FBQTtBREZKO0FDS0U7RUFDRSxlQUFBO0FESEo7QUNPQTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7QURKRjtBQ01FO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0FESko7QUNRQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7QURMRjtBQ1NBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FETkY7QUNTQTtFQUVFLGFBQUE7RUFDQSxnQ0FBQTtFQUVBLDhCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7RUFFQSxTQUFBO0FEUEY7QUNjQTtFQUNFLFlBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBRUEscUJBQUE7QURYRjtBQ2NBO0VBQ0UsYUFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0EsNkJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFFQSxxQkFBQTtBRFhGO0FDYUU7RUFDRSxlQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLDhCQUFBO0FEWEo7QUNjRTtFQUNFLFNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSw4QkFBQTtBRFpKO0FDZUU7RUFDRSxTQUFBO0FEYko7QUNnQkU7RUFDRSxZQUFBO0FEZEo7QUNrQkE7RUFFRSxhQUFBO0VBRUEseUJBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QURmRjtBQ2tCQTtFQUNFLG1CQUFBO0FEZkY7QUNrQkE7O0VBRUUsbUJBQUE7QURmRjtBQ2tCQTtFQUNFLGdCQUFBO0FEZkY7QUNrQkE7RUFFRSx3QkFBQTtBRGZGO0FDa0JBOztFQUVFLFVBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtBRGZGO0FDa0JBO0VBQ0UsaUJBQUE7RUFDQSxjQUFBO0FEZkY7QUNrQkE7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0FEZkY7QUNpQkU7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esb0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBRGZKO0FDb0JFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtBRGpCSjtBQ3FCQTtFQUNFLGdGQUFBO0VBRUEsNEJBQUE7RUFDQSxzQkFBQTtFQUNBLDJCQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtBRG5CRjtBQ3FCRTtFQUNFLFdBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtBRG5CSjtBQ3VCQTtFQUNFLGFBQUE7QURwQkY7QUN1QkE7RUFDRSxpQkFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FEcEJGO0FDc0JFO0VBQ0UsWUFBQTtBRHBCSjtBQ3dCQTtFQUNFLFVBQUE7RUFDQSxxQkFBQTtBRHJCRjtBQ3dCQTtFQUNFLFVBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBO0FEckJGO0FDdUJFO0VBQ0UsUUFBQTtFQUNBLGtCQUFBO0FEckJKO0FDeUJBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSw2QkFBQTtBRHRCRjtBQ3dCRTtFQUNFLDhCQUFBO0VBQ0Esa0NBQUE7QUR0Qko7QUMwQkE7RUFDRSxlQUFBO0VBQ0EsNkJBQUE7QUR2QkY7QUMwQkE7RUFDRSxlQUFBO0VBQ0EsOEJBQUE7QUR2QkY7QUMwQkE7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7QUR2QkYiLCJmaWxlIjoic3JjL2FwcC9zdWJzY3JpcHRpb25zL3N1YnNjcmlwdGlvbnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGNoYXJzZXQgXCJVVEYtOFwiO1xuaW9uLWNvbnRlbnQge1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbn1cblxuLmhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi10aXRsZSB7XG4gIHBhZGRpbmc6IDBweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIHBhZGRpbmctbGVmdDogMzBweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbn1cbi5oZWFkZXIgaW9uLW1lbnUtYnV0dG9uIHtcbiAgY29sb3I6ICNmZmY7XG59XG4uaGVhZGVyIGlvbi1pY29uIHtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbWFyZ2luOiA1cHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5oZWFkZXIgcCB7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6ICNmNzdlMjE7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICBtYXJnaW46IDBlbTtcbn1cbi5oZWFkZXIgaW9uLWJhY2stYnV0dG9uIHtcbiAgZm9udC1zaXplOiAxMnB4O1xufVxuXG4ucGxhbi12aWRlbyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLnBsYW4tdmlkZW8gaW1nIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogMTAwJTtcbn1cblxuLnRhYnMge1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi50YWIge1xuICB3aWR0aDogMTAwJTtcbiAgY29sb3I6IHdoaXRlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi50YWItbGFiZWwge1xuICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgZGlzcGxheTogZmxleDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkZGRkZGQ7XG4gIC13ZWJraXQtYm94LXBhY2s6IGp1c3RpZnk7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgcGFkZGluZzogMC44cmVtO1xuICBmb250LXNpemU6IDE1cHg7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGNvbG9yOiAjMjIyO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgLyogSWNvbiAqL1xufVxuXG4udGFiLWxhYmVsOjphZnRlciB7XG4gIGNvbnRlbnQ6IFwi4p2vXCI7XG4gIHdpZHRoOiAxZW07XG4gIGhlaWdodDogMWVtO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xuICB0cmFuc2l0aW9uOiBhbGwgMC4zNXM7XG59XG5cbi50YWItY29udGVudCB7XG4gIG1heC1oZWlnaHQ6IDA7XG4gIHBhZGRpbmc6IDAgMWVtO1xuICBjb2xvcjogIzJjM2U1MDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xuICB0cmFuc2l0aW9uOiBhbGwgMC4zNXM7XG59XG4udGFiLWNvbnRlbnQgaDQge1xuICBwYWRkaW5nLWxlZnQ6IDA7XG4gIG1hcmdpbjogMDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktU2VtaUJvbGQ7XG59XG4udGFiLWNvbnRlbnQgaDUge1xuICBtYXJnaW46IDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVNlbWlCb2xkO1xufVxuLnRhYi1jb250ZW50IHAge1xuICBtYXJnaW46IDA7XG59XG4udGFiLWNvbnRlbnQgaW9uLXRvZ2dsZSB7XG4gIGZsb2F0OiByaWdodDtcbn1cblxuLnRhYi1jbG9zZSB7XG4gIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICBkaXNwbGF5OiBmbGV4O1xuICAtd2Via2l0LWJveC1wYWNrOiBlbmQ7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gIHBhZGRpbmc6IDFlbTtcbiAgZm9udC1zaXplOiAwLjc1ZW07XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLnRhYi1jbG9zZTpob3ZlciB7XG4gIGJhY2tncm91bmQ6ICMxYTI1MmY7XG59XG5cbmlucHV0W3R5cGU9Y2hlY2tib3hdOmNoZWNrZWQsXG5pbnB1dFt0eXBlPXJhZGlvXTpjaGVja2VkIHtcbiAgYmFja2dyb3VuZDogI2Y3N2UyMTtcbn1cblxuaW5wdXQ6Y2hlY2tlZCArIC50YWItbGFiZWwge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuXG5pbnB1dDpjaGVja2VkICsgLnRhYi1sYWJlbDo6YWZ0ZXIge1xuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbiAgdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xufVxuXG5pbnB1dFt0eXBlPWNoZWNrYm94XSxcbmlucHV0W3R5cGU9cmFkaW9dIHtcbiAgcGFkZGluZzogMDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAxMHB4O1xuICB0b3A6IDE0cHg7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbmlucHV0OmNoZWNrZWQgfiAudGFiLWNvbnRlbnQge1xuICBtYXgtaGVpZ2h0OiAxMDB2aDtcbiAgcGFkZGluZzogMCAxZW07XG59XG5cbi5ib3R0b20tYnRuIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDQwcHggYXV0bztcbn1cbi5ib3R0b20tYnRuIGlvbi1idXR0b24uc3Vic2NyaWJlLWJ0biB7XG4gIC0tYmFja2dyb3VuZDogIzAwYTY1MTtcbiAgYmFja2dyb3VuZDogIzAwYTY1MTtcbiAgLS1ib3JkZXItcmFkaXVzOiAwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICMwMGE2NTE7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNmZmY7XG4gIHdpZHRoOiAyMDBweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbn1cblxuLnBsYW4taGVhZGluZyBoMSB7XG4gIHBhZGRpbmc6IDEycHggMjVweDtcbiAgbWFyZ2luOiAwcHg7XG4gIGNvbG9yOiAjMmI5MzFkO1xufVxuXG4ucGxhbi1ib2R5IHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KDBkZWcsICMzMTQ2NGUsICMzMTQ2NGViMyksIHVybCguLi8uLi9hc3NldHMvaW1hZ2VzL2NhdGFseXN0LmpwZyk7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgY29sb3I6ICNmZmY7XG4gIHBhZGRpbmctdG9wOiAyMHB4O1xuICBtYXJnaW4tdG9wOiAyNXB4O1xuICBwYWRkaW5nLWJvdHRvbTogMjBweDtcbn1cbi5wbGFuLWJvZHkgLnBsYW4tYm9keS1oZWFkaW5nIHtcbiAgbWFyZ2luOiAwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDJweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVNlbWlCb2xkO1xufVxuXG4ucGxhbi1saXN0LWRpdiB7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG5cbi5wbGFuLWxpc3QtcGxhbiB7XG4gIHBhZGRpbmc6IDRweCAxNXB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICBtYXJnaW4tYm90dG9tOiA0MHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4ucGxhbi1saXN0LXBsYW4gLnBsYW4tcHJpY2Uge1xuICBmbG9hdDogcmlnaHQ7XG59XG5cbi5wbGFuLXJpZ2h0IHtcbiAgd2lkdGg6IDYwJTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4ucGxhbi1sZWZ0IHtcbiAgd2lkdGg6IDQwJTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB2ZXJ0aWNhbC1hbGlnbjogc3VwZXI7XG59XG4ucGxhbi1sZWZ0IGlvbi1pY29uIHtcbiAgdG9wOiAzcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLnBsYW4taGVhZGluZyB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG59XG4ucGxhbi1oZWFkaW5nIGgxIHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVNlbWlCb2xkO1xuICB0ZXh0LXNoYWRvdzogMXB4IDFweCAzcHggIzM3MzIzNDM2O1xufVxuXG4ucGxhbi1kZXNjcmlwdGlvbiB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG59XG5cbi5wbGFuLXByaWNlIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktU2VtaUJvbGQ7XG59XG5cbi5zYXZlLXBsYW4tYmFkZ2Uge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAxMSU7XG4gIHRvcDogLTI1JTtcbiAgYmFja2dyb3VuZDogIzAwYTY1MTtcbiAgcGFkZGluZzogNHB4IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG59IiwiaW9uLWNvbnRlbnQge1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbn1cblxuLmhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG4gIC8vcGFkZGluZzogIDVweDtcblxuICBpb24tdGl0bGUge1xuICAgIHBhZGRpbmc6IDBweDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgIHBhZGRpbmctbGVmdDogMzBweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICB9XG5cbiAgaW9uLW1lbnUtYnV0dG9uIHtcbiAgICBjb2xvcjogI2ZmZjtcbiAgfVxuXG4gIGlvbi1pY29uIHtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBtYXJnaW46IDVweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIH1cblxuICBwIHtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgY29sb3I6ICNmNzdlMjE7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgbWFyZ2luOiAwZW07XG4gIH1cblxuICBpb24tYmFjay1idXR0b24ge1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgfVxufVxuXG4ucGxhbi12aWRlbyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gIGltZyB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG59XG5cbi50YWJzIHtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICAvLyBib3gtc2hhZG93OiAwIDRweCA0cHggLTJweCByZ2JhKDAsIDAsIDAsIDAuNSk7XG59XG5cbi50YWIge1xuICB3aWR0aDogMTAwJTtcbiAgY29sb3I6IHdoaXRlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi50YWItbGFiZWwge1xuICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgZGlzcGxheTogZmxleDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkZGRkZGQ7XG4gIC13ZWJraXQtYm94LXBhY2s6IGp1c3RpZnk7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgcGFkZGluZzogMC44cmVtO1xuICBmb250LXNpemU6IDE1cHg7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGNvbG9yOiAjMjIyO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcblxuICAvKiBJY29uICovXG59XG5cbi50YWItbGFiZWw6aG92ZXIge1xuICAvL2JhY2tncm91bmQ6ICMxYTI1MmY7XG59XG5cbi50YWItbGFiZWw6OmFmdGVyIHtcbiAgY29udGVudDogXCJcXDI3NkZcIjtcbiAgd2lkdGg6IDFlbTtcbiAgaGVpZ2h0OiAxZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgMC4zNXM7XG4gIHRyYW5zaXRpb246IGFsbCAwLjM1cztcbn1cblxuLnRhYi1jb250ZW50IHtcbiAgbWF4LWhlaWdodDogMDtcbiAgcGFkZGluZzogMCAxZW07XG4gIGNvbG9yOiAjMmMzZTUwO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgMC4zNXM7XG4gIHRyYW5zaXRpb246IGFsbCAwLjM1cztcblxuICBoNCB7XG4gICAgcGFkZGluZy1sZWZ0OiAwO1xuICAgIG1hcmdpbjogMDtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktU2VtaUJvbGQ7XG4gIH1cblxuICBoNSB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1TZW1pQm9sZDtcbiAgfVxuXG4gIHAge1xuICAgIG1hcmdpbjogMDtcbiAgfVxuXG4gIGlvbi10b2dnbGUge1xuICAgIGZsb2F0OiByaWdodDtcbiAgfVxufVxuXG4udGFiLWNsb3NlIHtcbiAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIC13ZWJraXQtYm94LXBhY2s6IGVuZDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgcGFkZGluZzogMWVtO1xuICBmb250LXNpemU6IDAuNzVlbTtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4udGFiLWNsb3NlOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogIzFhMjUyZjtcbn1cblxuaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdOmNoZWNrZWQsXG5pbnB1dFt0eXBlPVwicmFkaW9cIl06Y2hlY2tlZCB7XG4gIGJhY2tncm91bmQ6ICNmNzdlMjE7XG59XG5cbmlucHV0OmNoZWNrZWQrLnRhYi1sYWJlbCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG59XG5cbmlucHV0OmNoZWNrZWQrLnRhYi1sYWJlbDo6YWZ0ZXIge1xuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbiAgdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xufVxuXG5pbnB1dFt0eXBlPVwiY2hlY2tib3hcIl0sXG5pbnB1dFt0eXBlPVwicmFkaW9cIl0ge1xuICBwYWRkaW5nOiAwO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDEwcHg7XG4gIHRvcDogMTRweDtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuaW5wdXQ6Y2hlY2tlZH4udGFiLWNvbnRlbnQge1xuICBtYXgtaGVpZ2h0OiAxMDB2aDtcbiAgcGFkZGluZzogMCAxZW07XG59XG5cbi5ib3R0b20tYnRuIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDQwcHggYXV0bztcblxuICBpb24tYnV0dG9uLnN1YnNjcmliZS1idG4ge1xuICAgIC0tYmFja2dyb3VuZDogIzAwYTY1MTtcbiAgICBiYWNrZ3JvdW5kOiAjMDBhNjUxO1xuICAgIC0tYm9yZGVyLXJhZGl1czogMHB4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICMwMGE2NTE7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIHdpZHRoOiAyMDBweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICB9XG59XG5cbi5wbGFuLWhlYWRpbmcge1xuICBoMSB7XG4gICAgcGFkZGluZzogMTJweCAyNXB4O1xuICAgIG1hcmdpbjogMHB4O1xuICAgIGNvbG9yOiAjMmI5MzFkO1xuICB9XG59XG5cbi5wbGFuLWJvZHkge1xuICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQoMGRlZywgIzMxNDY0ZSwgIzMxNDY0ZWIzKSxcbiAgICB1cmwoLi4vLi4vYXNzZXRzL2ltYWdlcy9jYXRhbHlzdC5qcGcpO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xuICBwYWRkaW5nLXRvcDogMjBweDtcbiAgbWFyZ2luLXRvcDogMjVweDtcbiAgcGFkZGluZy1ib3R0b206IDIwcHg7XG5cbiAgLnBsYW4tYm9keS1oZWFkaW5nIHtcbiAgICBtYXJnaW46IDBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMnB4O1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1TZW1pQm9sZDtcbiAgfVxufVxuXG4ucGxhbi1saXN0LWRpdiB7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG5cbi5wbGFuLWxpc3QtcGxhbiB7XG4gIHBhZGRpbmc6IDRweCAxNXB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICBtYXJnaW4tYm90dG9tOiA0MHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgLnBsYW4tcHJpY2Uge1xuICAgIGZsb2F0OiByaWdodDtcbiAgfVxufVxuXG4ucGxhbi1yaWdodCB7XG4gIHdpZHRoOiA2MCU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cblxuLnBsYW4tbGVmdCB7XG4gIHdpZHRoOiA0MCU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgdmVydGljYWwtYWxpZ246IHN1cGVyO1xuXG4gIGlvbi1pY29uIHtcbiAgICB0b3A6IDNweDtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIH1cbn1cblxuLnBsYW4taGVhZGluZyB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG5cbiAgaDEge1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1TZW1pQm9sZDtcbiAgICB0ZXh0LXNoYWRvdzogMXB4IDFweCAzcHggIzM3MzIzNDM2O1xuICB9XG59XG5cbi5wbGFuLWRlc2NyaXB0aW9uIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbn1cblxuLnBsYW4tcHJpY2Uge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1TZW1pQm9sZDtcbn1cblxuLnNhdmUtcGxhbi1iYWRnZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDExJTtcbiAgdG9wOiAtMjUlO1xuICBiYWNrZ3JvdW5kOiAjMDBhNjUxO1xuICBwYWRkaW5nOiA0cHggMjBweDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/subscriptions/subscriptions.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/subscriptions/subscriptions.page.ts ***!
  \*****************************************************/
/*! exports provided: SubscriptionsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscriptionsPage", function() { return SubscriptionsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _service_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/api.service */ "./src/app/service/api.service.ts");




let SubscriptionsPage = class SubscriptionsPage {
    constructor(navCtrl, api) {
        this.navCtrl = navCtrl;
        this.api = api;
        this.subscriptionData = [];
        this.subscriptionData = [{
                'trial_name': '3 Months',
                'trial_payment': '$ 44.99',
                'trial_type': 'test',
                'id': 1
            }, {
                'trial_name': '1 Months',
                'trial_payment': '$ 14.99',
                'trial_type': 'test',
                'id': 2
            }
        ];
    }
    ngOnInit() {
        this.getSuuscription();
    }
    purchasePlan() {
        this.navCtrl.navigateForward('/card-information');
    }
    getSuuscription() {
        console.log("gettt");
        this.api.get("/getPlans").subscribe((res) => {
            console.log(res, "data");
            if (res['success']) {
                this.subscriptionData = res['data'];
            }
            else {
                this.subscriptionData = [];
            }
        });
    }
};
SubscriptionsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _service_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"] }
];
SubscriptionsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-subscriptions',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./subscriptions.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/subscriptions/subscriptions.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./subscriptions.page.scss */ "./src/app/subscriptions/subscriptions.page.scss")).default]
    })
], SubscriptionsPage);



/***/ })

}]);
//# sourceMappingURL=subscriptions-subscriptions-module-es2015.js.map