(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["survey-survey-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/survey/survey.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/survey/survey.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-header>\n  <div class=\"header\">\n    <ion-row>\n      <ion-col size=\"1\">\n        <ion-icon name=\"chevron-back-outline\"></ion-icon>\n      </ion-col>\n      <ion-col size=\"9\">\n        <ion-title> GETTING STARTED SURVEY</ion-title>\n      </ion-col>\n      <ion-col size=\"2\" text-right>\n        <ion-icon name=\"search-outline\" class=\"search\"></ion-icon>\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-header> -->\n\n<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\" text=\"\" icon=\"chevron-back-outline\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>GETTING STARTED SURVEY</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-icon name=\"search-outline\" class=\"setting\" (click)=\"search()\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"surveyForm\">\n      <div class=\"content-box\">\n    <div class=\"padding-16\">\n      <ion-label><b>What is your sex ?</b></ion-label>\n      <ion-select placeholder=\"SEX\" formControlName=\"gender\">\n        <ion-select-option value=\"female\">Female</ion-select-option>\n        <ion-select-option value=\"male\">Male</ion-select-option>\n      </ion-select>\n    </div>\n    <p class=\"error\">\n      <span *ngIf=\"surveyForm.get('gender').hasError('required') && surveyForm.get('gender').touched\">Please select gender.</span>\n   </p>\n    <ion-radio-group formControlName=\"experience\">\n    <div class=\"padding-16\">\n      <ion-label><b>Experience Level ?</b></ion-label>\n    </div>\n\n    <ion-row class=\"border-bottom\">\n      <ion-col size=\"6\">\n        <ion-item lines=\"none\">\n          <ion-label>BEGINEER</ion-label>\n          <ion-radio  slot=\"end\" placeholder=\"0-1day per week\" value=\"begineer\"></ion-radio>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-icon name=\"chevron-down-outline\" class=\"arrow-down\"></ion-icon>\n        <ion-label class=\"label-week\">(0-1 day per week)</ion-label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"border-bottom\">\n      <ion-col size=\"6\">\n        <ion-item lines=\"none\">\n          <ion-label>INTERMEDIATE</ion-label>\n          <ion-radio checked slot=\"end\" placeholder=\"2-3 days per week\"  value=\"intermediate\"></ion-radio>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-icon name=\"chevron-down-outline\" class=\"arrow-down\"></ion-icon>\n        <ion-label class=\"label-week\">(2-3 days per week)</ion-label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"border-bottom\">\n      <ion-col size=\"6\">\n        <ion-item lines=\"none\">\n          <ion-label>ADVANCED</ion-label>\n          <ion-radio  slot=\"end\" placeholder=\"4-7 days per week\" value=\"advanced\"></ion-radio>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-icon name=\"chevron-down-outline\" class=\"arrow-down\"></ion-icon>\n        <ion-label class=\"label-week\">(4-7 days per week)</ion-label>\n      </ion-col>\n    </ion-row>\n  </ion-radio-group>\n  <p class=\"error\">\n    <span *ngIf=\"surveyForm.get('experience').hasError('required') && surveyForm.get('experience').touched\">Please select one experience level.</span>\n </p>\n  <ion-radio-group formControlName=\"goal\">\n    <div class=\"padding-16\">\n      <ion-label><b>Desired Goal ?</b></ion-label>\n    </div>\n    <ion-row class=\"border-bottom\">\n      <ion-col size=\"5\">\n        <ion-item lines=\"none\">\n          <ion-label>LOSE WEIGHT </ion-label>\n          <ion-radio checked slot=\"end\" placeholder=\"\" class=\"custom-chekbox\" value=\"fat_loss\"></ion-radio>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"7\">\n        <ion-icon name=\"chevron-down-outline\" class=\"arrow-down\"></ion-icon>\n        <ion-label class=\"label-week\">(Fat Loss) </ion-label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"border-bottom\">\n      <ion-col size=\"5\">\n        <ion-item lines=\"none\">\n          <ion-label>TONE TIGHTEN </ion-label>\n          <ion-radio checked slot=\"end\" placeholder=\"\" class=\"custom-chekbox\" value=\"fat_muscle\"></ion-radio>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"7\">\n        <ion-icon name=\"chevron-down-outline\" class=\"arrow-down\"></ion-icon>\n        <ion-label class=\"label-week\">(Burn Fat, Build Muscle) </ion-label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"border-bottom\">\n      <ion-col size=\"5\">\n        <ion-item lines=\"none\">\n          <ion-label>GAIN WEIGHT </ion-label>\n          <ion-radio checked slot=\"end\" placeholder=\"\" class=\"custom-chekbox\" value=\"build_muscle\"></ion-radio>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"7\">\n        <ion-icon name=\"chevron-down-outline\" class=\"arrow-down\"></ion-icon>\n        <ion-label class=\"label-week\">(Build Muscle) </ion-label>\n      </ion-col>\n    </ion-row>\n  </ion-radio-group>\n  <p class=\"error\">\n    <span *ngIf=\"surveyForm.get('goal').hasError('required') && surveyForm.get('goal').touched\">Please select one goal.</span>\n </p>\n    <div class=\"padding-16\">\n      <div class=\"button-center\">\n        <ion-button class=\"update-button\" (click)=\"update()\" [disabled]=\"!surveyForm.valid\">UPDATE <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n        </ion-button>\n      </div>\n    </div>\n  </div>\n  </form>\n</ion-content>");

/***/ }),

/***/ "./src/app/survey/survey-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/survey/survey-routing.module.ts ***!
  \*************************************************/
/*! exports provided: SurveyPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SurveyPageRoutingModule", function() { return SurveyPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _survey_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./survey.page */ "./src/app/survey/survey.page.ts");




const routes = [
    {
        path: '',
        component: _survey_page__WEBPACK_IMPORTED_MODULE_3__["SurveyPage"]
    }
];
let SurveyPageRoutingModule = class SurveyPageRoutingModule {
};
SurveyPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SurveyPageRoutingModule);



/***/ }),

/***/ "./src/app/survey/survey.module.ts":
/*!*****************************************!*\
  !*** ./src/app/survey/survey.module.ts ***!
  \*****************************************/
/*! exports provided: SurveyPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SurveyPageModule", function() { return SurveyPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _survey_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./survey-routing.module */ "./src/app/survey/survey-routing.module.ts");
/* harmony import */ var _survey_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./survey.page */ "./src/app/survey/survey.page.ts");








let SurveyPageModule = class SurveyPageModule {
};
SurveyPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _survey_routing_module__WEBPACK_IMPORTED_MODULE_5__["SurveyPageRoutingModule"]
        ],
        declarations: [_survey_page__WEBPACK_IMPORTED_MODULE_6__["SurveyPage"]]
    })
], SurveyPageModule);



/***/ }),

/***/ "./src/app/survey/survey.page.scss":
/*!*****************************************!*\
  !*** ./src/app/survey/survey.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n  padding: 0 16px;\n}\n.header ion-back-button {\n  font-size: 12px;\n}\n.header ion-title {\n  padding-left: 35px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  letter-spacing: 1px;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n}\n.header .search {\n  text-align: right;\n  float: right;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\n.item-native {\n  padding: 0px !important;\n  padding-left: 0px !important;\n  -webkit-padding-start: 0px !important;\n          padding-inline-start: 0px !important;\n  -webkit-padding-end: 0px !important;\n          padding-inline-end: 0px !important;\n}\n.content-box {\n  background: #fff;\n  height: 100%;\n  /* ion-item {\n    margin-bottom: 20px;\n  }*/\n}\n.content-box ion-label {\n  font-size: 20px;\n  font-family: Rajdhani-Regular;\n}\n.content-box ion-select {\n  --padding-start: 0px;\n  border-bottom: 1px solid #858585;\n  margin-bottom: 20px;\n  font-size: 15px;\n}\n.content-box ion-checkbox {\n  --border-radius: 0px;\n}\n.content-box .button-center {\n  margin: 20px auto;\n  text-align: center;\n}\n.content-box .button-center ion-button {\n  --background: #233942;\n  color: #fff;\n  width: 150px;\n  --border-radius: 0;\n  text-align: center;\n  letter-spacing: 1px;\n  font-family: Rajdhani-Regular;\n}\n.content-box .button-center ion-button ion-icon {\n  color: #fff;\n  margin-left: 10px;\n}\n.padding-16 {\n  padding: 16px;\n}\nion-row {\n  align-items: baseline;\n}\nion-row.border-bottom {\n  border-bottom: 1px solid #858585;\n  margin-left: 10px;\n  margin-right: 10px;\n}\nion-row.border-bottom ion-checkbox {\n  width: 20px;\n  height: 20px;\n  margin: 0;\n}\nion-row.border-bottom ion-checkbox.custom-chekbox {\n  left: 10px;\n  position: relative;\n}\nion-row.border-bottom ion-item {\n  margin-left: -15px;\n}\nion-row.border-bottom ion-icon {\n  position: absolute;\n  left: -7px;\n}\nion-row.border-bottom ion-label.label-week {\n  margin-left: 10px;\n}\nion-row.border-bottom ion-label {\n  font-size: 17px;\n  --padding-start: 0 !important;\n}\np .error span {\n  margin-left: 19px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL3N1cnZleS9zdXJ2ZXkucGFnZS5zY3NzIiwic3JjL2FwcC9zdXJ2ZXkvc3VydmV5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQ0NGO0FEQ0U7RUFDRSxlQUFBO0FDQ0o7QURHRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtFQUVBLG1CQUFBO0FDRko7QURLRTtFQUNFLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUNISjtBRE1FO0VBQ0UsaUJBQUE7RUFDQSxZQUFBO0FDSko7QURPRTtFQUNFLFlBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxXQUFBO0FDTEo7QURVQTtFQUNFLHVCQUFBO0VBQ0EsNEJBQUE7RUFDQSxxQ0FBQTtVQUFBLG9DQUFBO0VBQ0EsbUNBQUE7VUFBQSxrQ0FBQTtBQ1BGO0FEV0E7RUFFRSxnQkFBQTtFQUNBLFlBQUE7RUFvQkE7O0lBQUE7QUMxQkY7QURRRTtFQUNFLGVBQUE7RUFDQSw2QkFBQTtBQ05KO0FEV0U7RUFDRSxvQkFBQTtFQUNBLGdDQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0FDVEo7QURZRTtFQUNFLG9CQUFBO0FDVko7QURpQkU7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0FDZko7QURpQkk7RUFDRSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsNkJBQUE7QUNmTjtBRGlCTTtFQUNFLFdBQUE7RUFDQSxpQkFBQTtBQ2ZSO0FEcUJBO0VBQ0UsYUFBQTtBQ2xCRjtBRHFCQTtFQUVFLHFCQUFBO0FDbkJGO0FEc0JBO0VBQ0UsZ0NBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDbkJGO0FEcUJFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxTQUFBO0FDbkJKO0FEc0JFO0VBQ0UsVUFBQTtFQUNBLGtCQUFBO0FDcEJKO0FEdUJFO0VBQ0Usa0JBQUE7QUNyQko7QUR3QkU7RUFDRSxrQkFBQTtFQUNBLFVBQUE7QUN0Qko7QUR5QkU7RUFDRSxpQkFBQTtBQ3ZCSjtBRDBCRTtFQUNFLGVBQUE7RUFDQSw2QkFBQTtBQ3hCSjtBRDRCRTtFQUNFLDRCQUFBO0FDekJKIiwiZmlsZSI6InNyYy9hcHAvc3VydmV5L3N1cnZleS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogMCAxNnB4O1xuXG4gIGlvbi1iYWNrLWJ1dHRvbiB7XG4gICAgZm9udC1zaXplOiAxMnB4O1xuICAgIDtcbiAgfVxuXG4gIGlvbi10aXRsZSB7XG4gICAgcGFkZGluZy1sZWZ0OiAzNXB4O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgLy9wYWRkaW5nLWxlZnQ6IDMwcHg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgfVxuXG4gIGlvbi1pY29uIHtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgfVxuXG4gIC5zZWFyY2gge1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgIGZsb2F0OiByaWdodDtcbiAgfVxuXG4gIHAge1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBjb2xvcjogI2Y3N2UyMTtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgICBtYXJnaW46IDBlbTtcbiAgfVxufVxuXG4vLyBpb24taXRlbSB7XG4uaXRlbS1uYXRpdmUge1xuICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcbiAgcGFkZGluZy1sZWZ0OiAwcHggIWltcG9ydGFudDtcbiAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IDBweCAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWlubGluZS1lbmQ6IDBweCAhaW1wb3J0YW50O1xufVxuXG4vLyB9XG4uY29udGVudC1ib3gge1xuICAvLyBwYWRkaW5nOjIwcHg7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGhlaWdodDogMTAwJTtcblxuICBpb24tbGFiZWwge1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgICAvLyBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgIC8vIG1hcmdpbi10b3A6MHB4XG4gIH1cblxuICBpb24tc2VsZWN0IHtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzg1ODU4NTtcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgfVxuXG4gIGlvbi1jaGVja2JveCB7XG4gICAgLS1ib3JkZXItcmFkaXVzOiAwcHg7XG4gIH1cblxuICAvKiBpb24taXRlbSB7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgfSovXG5cbiAgLmJ1dHRvbi1jZW50ZXIge1xuICAgIG1hcmdpbjogMjBweCBhdXRvO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICAgIGlvbi1idXR0b24ge1xuICAgICAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICAgICAgY29sb3I6ICNmZmY7XG4gICAgICB3aWR0aDogMTUwcHg7XG4gICAgICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG5cbiAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4ucGFkZGluZy0xNiB7XG4gIHBhZGRpbmc6IDE2cHg7XG59XG5cbmlvbi1yb3cge1xuICAvLyBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2NjYztcbiAgYWxpZ24taXRlbXM6IGJhc2VsaW5lO1xufVxuXG5pb24tcm93LmJvcmRlci1ib3R0b20ge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzg1ODU4NTtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcblxuICBpb24tY2hlY2tib3gge1xuICAgIHdpZHRoOiAyMHB4O1xuICAgIGhlaWdodDogMjBweDtcbiAgICBtYXJnaW46IDA7XG4gIH1cblxuICBpb24tY2hlY2tib3guY3VzdG9tLWNoZWtib3gge1xuICAgIGxlZnQ6IDEwcHg7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB9XG5cbiAgaW9uLWl0ZW0ge1xuICAgIG1hcmdpbi1sZWZ0OiAtMTVweDtcbiAgfVxuXG4gIGlvbi1pY29uIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogLTdweDtcbiAgfVxuXG4gIGlvbi1sYWJlbC5sYWJlbC13ZWVrIHtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgfVxuXG4gIGlvbi1sYWJlbCB7XG4gICAgZm9udC1zaXplOiAxN3B4O1xuICAgIC0tcGFkZGluZy1zdGFydDogMCAhaW1wb3J0YW50O1xuICB9XG59XG5wIC5lcnJvcntcbiAgc3BhbntcbiAgICBtYXJnaW4tbGVmdDogMTlweCAhaW1wb3J0YW50O1xuXG4gIH1cbn0iLCIuaGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogMCAxNnB4O1xufVxuLmhlYWRlciBpb24tYmFjay1idXR0b24ge1xuICBmb250LXNpemU6IDEycHg7XG59XG4uaGVhZGVyIGlvbi10aXRsZSB7XG4gIHBhZGRpbmctbGVmdDogMzVweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG59XG4uaGVhZGVyIGlvbi1pY29uIHtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cbi5oZWFkZXIgLnNlYXJjaCB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBmbG9hdDogcmlnaHQ7XG59XG4uaGVhZGVyIHAge1xuICBmbG9hdDogcmlnaHQ7XG4gIGNvbG9yOiAjZjc3ZTIxO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgbWFyZ2luOiAwZW07XG59XG5cbi5pdGVtLW5hdGl2ZSB7XG4gIHBhZGRpbmc6IDBweCAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWxlZnQ6IDBweCAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWlubGluZS1zdGFydDogMHB4ICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmctaW5saW5lLWVuZDogMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5jb250ZW50LWJveCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGhlaWdodDogMTAwJTtcbiAgLyogaW9uLWl0ZW0ge1xuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gIH0qL1xufVxuLmNvbnRlbnQtYm94IGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG59XG4uY29udGVudC1ib3ggaW9uLXNlbGVjdCB7XG4gIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzg1ODU4NTtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgZm9udC1zaXplOiAxNXB4O1xufVxuLmNvbnRlbnQtYm94IGlvbi1jaGVja2JveCB7XG4gIC0tYm9yZGVyLXJhZGl1czogMHB4O1xufVxuLmNvbnRlbnQtYm94IC5idXR0b24tY2VudGVyIHtcbiAgbWFyZ2luOiAyMHB4IGF1dG87XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5jb250ZW50LWJveCAuYnV0dG9uLWNlbnRlciBpb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbiAgd2lkdGg6IDE1MHB4O1xuICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG59XG4uY29udGVudC1ib3ggLmJ1dHRvbi1jZW50ZXIgaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIGNvbG9yOiAjZmZmO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cblxuLnBhZGRpbmctMTYge1xuICBwYWRkaW5nOiAxNnB4O1xufVxuXG5pb24tcm93IHtcbiAgYWxpZ24taXRlbXM6IGJhc2VsaW5lO1xufVxuXG5pb24tcm93LmJvcmRlci1ib3R0b20ge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzg1ODU4NTtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbmlvbi1yb3cuYm9yZGVyLWJvdHRvbSBpb24tY2hlY2tib3gge1xuICB3aWR0aDogMjBweDtcbiAgaGVpZ2h0OiAyMHB4O1xuICBtYXJnaW46IDA7XG59XG5pb24tcm93LmJvcmRlci1ib3R0b20gaW9uLWNoZWNrYm94LmN1c3RvbS1jaGVrYm94IHtcbiAgbGVmdDogMTBweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuaW9uLXJvdy5ib3JkZXItYm90dG9tIGlvbi1pdGVtIHtcbiAgbWFyZ2luLWxlZnQ6IC0xNXB4O1xufVxuaW9uLXJvdy5ib3JkZXItYm90dG9tIGlvbi1pY29uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAtN3B4O1xufVxuaW9uLXJvdy5ib3JkZXItYm90dG9tIGlvbi1sYWJlbC5sYWJlbC13ZWVrIHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5pb24tcm93LmJvcmRlci1ib3R0b20gaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxN3B4O1xuICAtLXBhZGRpbmctc3RhcnQ6IDAgIWltcG9ydGFudDtcbn1cblxucCAuZXJyb3Igc3BhbiB7XG4gIG1hcmdpbi1sZWZ0OiAxOXB4ICFpbXBvcnRhbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/survey/survey.page.ts":
/*!***************************************!*\
  !*** ./src/app/survey/survey.page.ts ***!
  \***************************************/
/*! exports provided: SurveyPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SurveyPage", function() { return SurveyPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _service_events_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../service/events.service */ "./src/app/service/events.service.ts");






let SurveyPage = class SurveyPage {
    constructor(navCtrl, router, formBuilder, events) {
        this.navCtrl = navCtrl;
        this.router = router;
        this.formBuilder = formBuilder;
        this.events = events;
        this.surveyForm = this.formBuilder.group({
            gender: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            experience: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            goal: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
        });
    }
    ngOnInit() { }
    search() {
        this.navCtrl.navigateForward("/search-exercises");
    }
    update() {
        var user = {
            gender: this.surveyForm.value.gender,
            experience: this.surveyForm.value.experience,
            goal: this.surveyForm.value.goal,
            name: JSON.parse(localStorage.getItem('userData')).name,
            email: JSON.parse(localStorage.getItem('userData')).email,
        };
        localStorage.setItem('userData', JSON.stringify(user));
        this.events.publish('user:created', { user: JSON.stringify(user) });
        this.navCtrl.navigateRoot('/profile');
        // let navigationExtras: NavigationExtras = {
        //   queryParams: {
        //     back: true,
        //   },
        // };
        // this.navCtrl.navigateForward(["profile"], navigationExtras);
        // this.router.navigate(["profile", { back: true }]);
    }
};
SurveyPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _service_events_service__WEBPACK_IMPORTED_MODULE_5__["EventsService"] }
];
SurveyPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-survey",
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./survey.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/survey/survey.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./survey.page.scss */ "./src/app/survey/survey.page.scss")).default]
    })
], SurveyPage);



/***/ })

}]);
//# sourceMappingURL=survey-survey-module-es2015.js.map