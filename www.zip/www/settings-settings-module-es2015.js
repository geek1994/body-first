(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["settings-settings-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\" text=\"\" style=\"display:block;\" defaultHref=\"week-workout\"\n        icon=\"chevron-back-outline\">\n      </ion-back-button>\n    </ion-buttons>\n\n    <ion-title>SETTINGS</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <h4>General</h4>\n  <div class=\"tabs\">\n    <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck1\">\n      <label class=\"tab-label\" for=\"chck1\" (click)=\"presentAlertConfirm()\">Go Subscription</label>\n      <!--div class=\"tab-content\">\n        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsum, reiciendis!\n      </div-->\n    </div>\n    <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck2\" checked>\n      <label class=\"tab-label\" for=\"chck2\">Language Setting</label>\n      <div class=\"tab-content\">\n        <h4 class=\"mrg\">Notification</h4>\n        <ion-row>\n          <ion-col size=\"8\">\n            <h5>Health Tips</h5>\n            <p>Daily Health Tips</p>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-toggle checked></ion-toggle>\n          </ion-col>\n        </ion-row>\n        <h4 class=\"mrg\">About</h4>\n        <ion-row>\n          <ion-col size=\"12\">\n            <h5>Feedback</h5>\n            <p>Got any query? We are happy to help!</p>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n    <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck3\">\n      <label class=\"tab-label\" for=\"chck3\">Rate BODYFIRST</label>\n      <div class=\"tab-content\">\n        <P class=\"tab-inner-content\">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsum, reiciendis!</P>\n      </div>\n    </div>\n    <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck4\">\n      <label class=\"tab-label\" for=\"chck4\">Privacy Policy</label>\n      <div class=\"tab-content\">\n        <P class=\"tab-inner-content\"> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsum, reiciendis!</P>\n      </div>\n    </div>\n    <!-- <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck5\">\n      <label class=\"tab-label\" for=\"chck5\">Share this App</label>\n      <div class=\"tab-content\">\n        <P class=\"tab-inner-content\"> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsum, reiciendis!</P>\n      </div>\n    </div> -->\n    <div class=\"tab\" (click)=\"share()\">\n      <input type=\"checkbox\" >\n      <label class=\"tab-label\" >Share this App</label>\n    </div>\n    <div class=\"tab\">\n      <input type=\"checkbox\" id=\"chck6\">\n      <label class=\"tab-label\" for=\"chck6\">Version</label>\n      <div class=\"tab-content\">\n        <P class=\"tab-inner-content\"> {{app_version}}</P>\n      </div>\n    </div>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/settings/settings-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/settings/settings-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: SettingsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPageRoutingModule", function() { return SettingsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings.page */ "./src/app/settings/settings.page.ts");




const routes = [
    {
        path: '',
        component: _settings_page__WEBPACK_IMPORTED_MODULE_3__["SettingsPage"]
    }
];
let SettingsPageRoutingModule = class SettingsPageRoutingModule {
};
SettingsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SettingsPageRoutingModule);



/***/ }),

/***/ "./src/app/settings/settings.module.ts":
/*!*********************************************!*\
  !*** ./src/app/settings/settings.module.ts ***!
  \*********************************************/
/*! exports provided: SettingsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPageModule", function() { return SettingsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _settings_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./settings-routing.module */ "./src/app/settings/settings-routing.module.ts");
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./settings.page */ "./src/app/settings/settings.page.ts");







let SettingsPageModule = class SettingsPageModule {
};
SettingsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _settings_routing_module__WEBPACK_IMPORTED_MODULE_5__["SettingsPageRoutingModule"]
        ],
        declarations: [_settings_page__WEBPACK_IMPORTED_MODULE_6__["SettingsPage"]]
    })
], SettingsPageModule);



/***/ }),

/***/ "./src/app/settings/settings.page.scss":
/*!*********************************************!*\
  !*** ./src/app/settings/settings.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@charset \"UTF-8\";\n.header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 35px;\n  letter-spacing: 1px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n  margin: 5px;\n  margin-right: 10px;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\n.header ion-back-button {\n  font-size: 12px;\n}\nion-content h4 {\n  font-size: 18px;\n  color: green;\n  font-family: Rajdhani-Regular;\n  padding-left: 10px;\n}\nion-content h4.mrg {\n  margin-top: 13px;\n}\nion-content h5 {\n  margin-top: 0;\n}\nion-content h3 {\n  margin: 0;\n}\n.tabs {\n  border-radius: 8px;\n  overflow: hidden;\n}\n.tab {\n  width: 100%;\n  color: white;\n  overflow: hidden;\n  position: relative;\n}\n.tab-label {\n  display: flex;\n  border-bottom: 1px solid #dddddd;\n  justify-content: space-between;\n  background: #fff;\n  margin-bottom: 10px;\n  padding: 0.8rem;\n  font-size: 17px;\n  letter-spacing: 1px;\n  font-weight: bold;\n  cursor: pointer;\n  color: #222;\n  font-family: Rajdhani-Regular;\n  /* Icon */\n}\n.tab-label::after {\n  content: \"❯\";\n  width: 1em;\n  height: 1em;\n  text-align: center;\n  transition: all 0.35s;\n}\n.tab-content {\n  max-height: 0;\n  padding: 0 1em;\n  color: #2c3e50;\n  font-family: Rajdhani-Regular;\n  font-size: 14px;\n  background: white;\n  transition: all 0.35s;\n}\n.tab-content .tab-inner-content {\n  margin-bottom: 12px;\n}\n.tab-content h4 {\n  padding-left: 0;\n  margin: 0;\n}\n.tab-content p {\n  margin: 0;\n}\n.tab-content ion-toggle {\n  float: right;\n}\n.tab-close {\n  display: flex;\n  justify-content: flex-end;\n  padding: 1em;\n  font-size: 0.75em;\n  background: #fff;\n  cursor: pointer;\n}\n.tab-close:hover {\n  background: #1a252f;\n}\ninput[type=checkbox]:checked,\ninput[type=radio]:checked {\n  background: #f77e21;\n}\ninput:checked + .tab-label {\n  background: #fff;\n}\ninput:checked + .tab-label::after {\n  transform: rotate(90deg);\n}\ninput[type=checkbox],\ninput[type=radio] {\n  padding: 0;\n  position: absolute;\n  left: 10px;\n  top: 14px;\n  display: none;\n}\ninput:checked ~ .tab-content {\n  max-height: 100vh;\n  padding: 0 1em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2V0dGluZ3Mvc2V0dGluZ3MucGFnZS5zY3NzIiwiL1ZvbHVtZXMvRGlzazIvYm9keUZpcnN0L3NyYy9hcHAvc2V0dGluZ3Mvc2V0dGluZ3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQ0FoQjtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FERUY7QUNDRTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBRENKO0FDRUU7RUFDRSxXQUFBO0FEQUo7QUNHRTtFQUNFLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QURESjtBQ0lFO0VBQ0UsWUFBQTtFQUNBLGNBQUE7RUFDQSwwQkFBQTtFQUNBLFdBQUE7QURGSjtBQ0tFO0VBQ0UsZUFBQTtBREhKO0FDUUU7RUFDRSxlQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7QURMSjtBQ1FFO0VBQ0UsZ0JBQUE7QUROSjtBQ1NFO0VBQ0UsYUFBQTtBRFBKO0FDVUU7RUFDRSxTQUFBO0FEUko7QUNZQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7QURURjtBQ2FBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FEVkY7QUNjQTtFQUVFLGFBQUE7RUFDQSxnQ0FBQTtFQUVBLDhCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7RUFFQSxTQUFBO0FEWkY7QUNtQkE7RUFDRSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUVBLHFCQUFBO0FEaEJGO0FDbUJBO0VBQ0UsYUFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0EsNkJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFFQSxxQkFBQTtBRGhCRjtBQ2tCRTtFQUNFLG1CQUFBO0FEaEJKO0FDbUJFO0VBQ0UsZUFBQTtFQUNBLFNBQUE7QURqQko7QUNvQkU7RUFDRSxTQUFBO0FEbEJKO0FDcUJFO0VBQ0UsWUFBQTtBRG5CSjtBQ3VCQTtFQUVFLGFBQUE7RUFFQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBRHBCRjtBQ3VCQTtFQUNFLG1CQUFBO0FEcEJGO0FDdUJBOztFQUVFLG1CQUFBO0FEcEJGO0FDdUJBO0VBQ0UsZ0JBQUE7QURwQkY7QUN1QkE7RUFFRSx3QkFBQTtBRHBCRjtBQ3VCQTs7RUFFRSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtFQUNBLGFBQUE7QURwQkY7QUN1QkE7RUFDRSxpQkFBQTtFQUNBLGNBQUE7QURwQkYiLCJmaWxlIjoic3JjL2FwcC9zZXR0aW5ncy9zZXR0aW5ncy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAY2hhcnNldCBcIlVURi04XCI7XG4uaGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbn1cbi5oZWFkZXIgaW9uLXRpdGxlIHtcbiAgcGFkZGluZzogMHB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgcGFkZGluZy1sZWZ0OiAzNXB4O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xufVxuLmhlYWRlciBpb24tbWVudS1idXR0b24ge1xuICBjb2xvcjogI2ZmZjtcbn1cbi5oZWFkZXIgaW9uLWljb24ge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBtYXJnaW46IDVweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLmhlYWRlciBwIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBjb2xvcjogI2Y3N2UyMTtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gIG1hcmdpbjogMGVtO1xufVxuLmhlYWRlciBpb24tYmFjay1idXR0b24ge1xuICBmb250LXNpemU6IDEycHg7XG59XG5cbmlvbi1jb250ZW50IGg0IHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBjb2xvcjogZ3JlZW47XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG59XG5pb24tY29udGVudCBoNC5tcmcge1xuICBtYXJnaW4tdG9wOiAxM3B4O1xufVxuaW9uLWNvbnRlbnQgaDUge1xuICBtYXJnaW4tdG9wOiAwO1xufVxuaW9uLWNvbnRlbnQgaDMge1xuICBtYXJnaW46IDA7XG59XG5cbi50YWJzIHtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udGFiIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4udGFiLWxhYmVsIHtcbiAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZGRkZGRkO1xuICAtd2Via2l0LWJveC1wYWNrOiBqdXN0aWZ5O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIHBhZGRpbmc6IDAuOHJlbTtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBjb2xvcjogIzIyMjtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIC8qIEljb24gKi9cbn1cblxuLnRhYi1sYWJlbDo6YWZ0ZXIge1xuICBjb250ZW50OiBcIuKdr1wiO1xuICB3aWR0aDogMWVtO1xuICBoZWlnaHQ6IDFlbTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjM1cztcbiAgdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xufVxuXG4udGFiLWNvbnRlbnQge1xuICBtYXgtaGVpZ2h0OiAwO1xuICBwYWRkaW5nOiAwIDFlbTtcbiAgY29sb3I6ICMyYzNlNTA7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjM1cztcbiAgdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xufVxuLnRhYi1jb250ZW50IC50YWItaW5uZXItY29udGVudCB7XG4gIG1hcmdpbi1ib3R0b206IDEycHg7XG59XG4udGFiLWNvbnRlbnQgaDQge1xuICBwYWRkaW5nLWxlZnQ6IDA7XG4gIG1hcmdpbjogMDtcbn1cbi50YWItY29udGVudCBwIHtcbiAgbWFyZ2luOiAwO1xufVxuLnRhYi1jb250ZW50IGlvbi10b2dnbGUge1xuICBmbG9hdDogcmlnaHQ7XG59XG5cbi50YWItY2xvc2Uge1xuICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgZGlzcGxheTogZmxleDtcbiAgLXdlYmtpdC1ib3gtcGFjazogZW5kO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICBwYWRkaW5nOiAxZW07XG4gIGZvbnQtc2l6ZTogMC43NWVtO1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi50YWItY2xvc2U6aG92ZXIge1xuICBiYWNrZ3JvdW5kOiAjMWEyNTJmO1xufVxuXG5pbnB1dFt0eXBlPWNoZWNrYm94XTpjaGVja2VkLFxuaW5wdXRbdHlwZT1yYWRpb106Y2hlY2tlZCB7XG4gIGJhY2tncm91bmQ6ICNmNzdlMjE7XG59XG5cbmlucHV0OmNoZWNrZWQgKyAudGFiLWxhYmVsIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbn1cblxuaW5wdXQ6Y2hlY2tlZCArIC50YWItbGFiZWw6OmFmdGVyIHtcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gIHRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbn1cblxuaW5wdXRbdHlwZT1jaGVja2JveF0sXG5pbnB1dFt0eXBlPXJhZGlvXSB7XG4gIHBhZGRpbmc6IDA7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMTBweDtcbiAgdG9wOiAxNHB4O1xuICBkaXNwbGF5OiBub25lO1xufVxuXG5pbnB1dDpjaGVja2VkIH4gLnRhYi1jb250ZW50IHtcbiAgbWF4LWhlaWdodDogMTAwdmg7XG4gIHBhZGRpbmc6IDAgMWVtO1xufSIsIi5oZWFkZXIge1xuICAtLWJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIGNvbG9yOiAjZmZmO1xuICAvL3BhZGRpbmc6ICA1cHg7XG5cbiAgaW9uLXRpdGxlIHtcbiAgICBwYWRkaW5nOiAwcHg7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgICBwYWRkaW5nLWxlZnQ6IDM1cHg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgfVxuXG4gIGlvbi1tZW51LWJ1dHRvbiB7XG4gICAgY29sb3I6ICNmZmY7XG4gIH1cblxuICBpb24taWNvbiB7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgbWFyZ2luOiA1cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICB9XG5cbiAgcCB7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGNvbG9yOiAjZjc3ZTIxO1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgIG1hcmdpbjogMGVtO1xuICB9XG5cbiAgaW9uLWJhY2stYnV0dG9uIHtcbiAgICBmb250LXNpemU6IDEycHg7XG4gIH1cbn1cblxuaW9uLWNvbnRlbnQge1xuICBoNCB7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGNvbG9yOiBncmVlbjtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIH1cblxuICBoNC5tcmcge1xuICAgIG1hcmdpbi10b3A6IDEzcHg7XG4gIH1cblxuICBoNSB7XG4gICAgbWFyZ2luLXRvcDogMDtcbiAgfVxuXG4gIGgzIHtcbiAgICBtYXJnaW46IDA7XG4gIH1cbn1cblxuLnRhYnMge1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIC8vIGJveC1zaGFkb3c6IDAgNHB4IDRweCAtMnB4IHJnYmEoMCwgMCwgMCwgMC41KTtcbn1cblxuLnRhYiB7XG4gIHdpZHRoOiAxMDAlO1xuICBjb2xvcjogd2hpdGU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxufVxuXG4udGFiLWxhYmVsIHtcbiAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZGRkZGRkO1xuICAtd2Via2l0LWJveC1wYWNrOiBqdXN0aWZ5O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIHBhZGRpbmc6IDAuOHJlbTtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBjb2xvcjogIzIyMjtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG5cbiAgLyogSWNvbiAqL1xufVxuXG4udGFiLWxhYmVsOmhvdmVyIHtcbiAgLy9iYWNrZ3JvdW5kOiAjMWEyNTJmO1xufVxuXG4udGFiLWxhYmVsOjphZnRlciB7XG4gIGNvbnRlbnQ6IFwiXFwyNzZGXCI7XG4gIHdpZHRoOiAxZW07XG4gIGhlaWdodDogMWVtO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4zNXM7XG4gIHRyYW5zaXRpb246IGFsbCAuMzVzO1xufVxuXG4udGFiLWNvbnRlbnQge1xuICBtYXgtaGVpZ2h0OiAwO1xuICBwYWRkaW5nOiAwIDFlbTtcbiAgY29sb3I6ICMyYzNlNTA7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuMzVzO1xuICB0cmFuc2l0aW9uOiBhbGwgLjM1cztcblxuICAudGFiLWlubmVyLWNvbnRlbnQge1xuICAgIG1hcmdpbi1ib3R0b206IDEycHg7XG4gIH1cblxuICBoNCB7XG4gICAgcGFkZGluZy1sZWZ0OiAwO1xuICAgIG1hcmdpbjogMDtcbiAgfVxuXG4gIHAge1xuICAgIG1hcmdpbjogMDtcbiAgfVxuXG4gIGlvbi10b2dnbGUge1xuICAgIGZsb2F0OiByaWdodDtcbiAgfVxufVxuXG4udGFiLWNsb3NlIHtcbiAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIC13ZWJraXQtYm94LXBhY2s6IGVuZDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgcGFkZGluZzogMWVtO1xuICBmb250LXNpemU6IDAuNzVlbTtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4udGFiLWNsb3NlOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogIzFhMjUyZjtcbn1cblxuaW5wdXRbdHlwZT1jaGVja2JveF06Y2hlY2tlZCxcbmlucHV0W3R5cGU9cmFkaW9dOmNoZWNrZWQge1xuICBiYWNrZ3JvdW5kOiAjZjc3ZTIxO1xufVxuXG5pbnB1dDpjaGVja2VkKy50YWItbGFiZWwge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuXG5pbnB1dDpjaGVja2VkKy50YWItbGFiZWw6OmFmdGVyIHtcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gIHRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbn1cblxuaW5wdXRbdHlwZT1jaGVja2JveF0sXG5pbnB1dFt0eXBlPXJhZGlvXSB7XG4gIHBhZGRpbmc6IDA7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMTBweDtcbiAgdG9wOiAxNHB4O1xuICBkaXNwbGF5OiBub25lO1xufVxuXG5pbnB1dDpjaGVja2Vkfi50YWItY29udGVudCB7XG4gIG1heC1oZWlnaHQ6IDEwMHZoO1xuICBwYWRkaW5nOiAwIDFlbTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/settings/settings.page.ts":
/*!*******************************************!*\
  !*** ./src/app/settings/settings.page.ts ***!
  \*******************************************/
/*! exports provided: SettingsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPage", function() { return SettingsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _service_component_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/component.service */ "./src/app/service/component.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_app_version_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/app-version/ngx */ "./node_modules/@ionic-native/app-version/__ivy_ngcc__/ngx/index.js");






let SettingsPage = class SettingsPage {
    constructor(alertController, socialSharing, componentService, platform, appVersion) {
        this.alertController = alertController;
        this.socialSharing = socialSharing;
        this.componentService = componentService;
        this.platform = platform;
        this.appVersion = appVersion;
        this.link = '';
        this.app_version = '';
        this.appVersion.getVersionNumber().then(function (version) {
            this.app_version = version;
        });
    }
    presentAlertConfirm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: "my-custom-class subscription-label",
                header: "SUBSCRIPTION",
                message: "",
                buttons: [
                    {
                        text: "ALLOW",
                        role: "cancel",
                        cssClass: "secondary",
                        handler: (blah) => {
                            console.log("Confirm Cancel: blah");
                        },
                    },
                    {
                        text: "DELETE ACCOUNT",
                        handler: () => {
                            console.log("Confirm Okay");
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    ngOnInit() {
        this.platform.ready().then(() => {
            if (this.platform.is('android')) {
                this.link = 'https://play.google.com/store';
            }
            if (this.platform.is('ios')) {
                this.link = 'https://www.apple.com/itunes/';
            }
        });
    }
    share() {
        this.componentService.presentLoading();
        console.log(this.link, "link");
        this.socialSharing.share("BodyFirst App", this.link).then(() => {
            this.componentService.dismissLoading();
            // this.socialSharing.share('Post',null, URL, link).then(() => {
            console.log("share");
        }).catch(() => {
            console.log("not share");
            this.componentService.dismissLoading();
            alert("not share");
        });
    }
};
SettingsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_2__["SocialSharing"],] }] },
    { type: _service_component_service__WEBPACK_IMPORTED_MODULE_3__["ComponentService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _ionic_native_app_version_ngx__WEBPACK_IMPORTED_MODULE_5__["AppVersion"] }
];
SettingsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-settings",
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./settings.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./settings.page.scss */ "./src/app/settings/settings.page.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_2__["SocialSharing"]))
], SettingsPage);



/***/ })

}]);
//# sourceMappingURL=settings-settings-module-es2015.js.map