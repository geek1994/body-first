(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["functional-functional-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/functional/functional.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/functional/functional.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\" text=\"\" icon=\"chevron-back-outline\" ></ion-back-button>\n    </ion-buttons> -->\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>FUNCTIONAL RESISTANCE TRAINING</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-icon name=\"heart-outline\" class=\"heart\"></ion-icon>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <div class=\"functional\">\n    <div class=\"img-box\">\n      <img src=\"assets/images/f1.png\">\n      <h3>Functional<br /> Resistance<br /> Training Program</h3>\n      <img src=\"assets/images/video.png\" class=\"video-icon\" />\n    </div>\n\n    <!-- <div class=\"functional-content\">\n   <h2>FUNCTIONAL RESISTANCE TRAINING PROGRAM</h2>\n   <div class=\"box\">\n     <ion-row>\n       <ion-col size=\"6\">\n         <h5>Primary</h5>\n         <img src=\"assets/images/primary.png\">\n       </ion-col>\n       <ion-col size=\"6\">\n         <H5>Secondary</H5>\n         <img src=\"assets/images/secondary.png\">\n      </ion-col>\n     </ion-row>\n   </div>\n</div> -->\n\n    <div class=\"circuit\">\n      <div class=\"tabs\">\n        <div class=\"tab\">\n          <input type=\"checkbox\" id=\"chck7\">\n          <label class=\"tab-label\" for=\"chck7\">Exercise 1</label>\n          <div class=\"tab-content\">\n            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsum, reiciendis!\n          </div>\n        </div>\n        <div class=\"tab\">\n          <input type=\"checkbox\" id=\"chck8\">\n          <label class=\"tab-label\" for=\"chck8\">Exercise 2</label>\n          <div class=\"tab-content\">\n            Lorem ipsum dolor sit amet consectetur adipisicing elit. A, in!\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/functional/functional-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/functional/functional-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: FunctionalPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FunctionalPageRoutingModule", function() { return FunctionalPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _functional_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./functional.page */ "./src/app/functional/functional.page.ts");




const routes = [
    {
        path: '',
        component: _functional_page__WEBPACK_IMPORTED_MODULE_3__["FunctionalPage"]
    }
];
let FunctionalPageRoutingModule = class FunctionalPageRoutingModule {
};
FunctionalPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], FunctionalPageRoutingModule);



/***/ }),

/***/ "./src/app/functional/functional.module.ts":
/*!*************************************************!*\
  !*** ./src/app/functional/functional.module.ts ***!
  \*************************************************/
/*! exports provided: FunctionalPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FunctionalPageModule", function() { return FunctionalPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _functional_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./functional-routing.module */ "./src/app/functional/functional-routing.module.ts");
/* harmony import */ var _functional_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./functional.page */ "./src/app/functional/functional.page.ts");







let FunctionalPageModule = class FunctionalPageModule {
};
FunctionalPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _functional_routing_module__WEBPACK_IMPORTED_MODULE_5__["FunctionalPageRoutingModule"]
        ],
        declarations: [_functional_page__WEBPACK_IMPORTED_MODULE_6__["FunctionalPage"]]
    })
], FunctionalPageModule);



/***/ }),

/***/ "./src/app/functional/functional.page.scss":
/*!*************************************************!*\
  !*** ./src/app/functional/functional.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@charset \"UTF-8\";\nion-toolbar {\n  --background:#233942;\n  background: #233942;\n  color: #fff;\n  padding: 5px;\n}\nion-toolbar ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 44px;\n}\nion-toolbar ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n}\nion-toolbar ion-back-button {\n  font-size: 12px;\n}\nion-toolbar .search {\n  text-align: right;\n  float: right;\n  margin-right: 10px;\n}\nion-toolbar p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\n.functional .img-box {\n  position: relative;\n}\n.functional .img-box img {\n  width: 100%;\n  position: relative;\n}\n.functional .img-box img.video-icon {\n  position: absolute;\n  width: auto;\n  left: 44%;\n  bottom: 23%;\n  right: 0;\n}\n.functional .img-box H3 {\n  color: #fff;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 0;\n  letter-spacing: 2px;\n  font-size: 32px;\n  font-family: Rajdhani-Bold;\n  text-align: center;\n}\n.functional .img-box ion-icon {\n  text-align: center;\n  color: #fff;\n  position: absolute;\n  top: 58%;\n  font-size: 50px;\n  z-index: 9999;\n  left: 43%;\n}\nion-content {\n  --background: #f9f9f9 !important;\n}\n.functional-content {\n  padding: 20px;\n}\n.functional-content h2 {\n  font-family: Rajdhani-Bold;\n}\n.functional-content .box {\n  background: #233942;\n  padding: 10px;\n  color: #fff;\n  text-align: center;\n  border-radius: 10px;\n}\n.functional-content .box h5 {\n  letter-spacing: 1px;\n  font-family: Rajdhani-Regular;\n  margin-bottom: 20px;\n}\n.functional {\n  background: #f9f9f9;\n  height: 100%;\n}\n.circuit {\n  padding: 20px;\n  margin: 20px;\n  border: 1px solid #222;\n  border-radius: 10px;\n  background: #fff;\n}\n.circuit h3 {\n  font-family: Rajdhani-Regular;\n}\n.tabs {\n  border-radius: 8px;\n  overflow: hidden;\n}\n.tab {\n  width: 100%;\n  color: white;\n  overflow: hidden;\n  position: relative;\n}\n.tab-label {\n  display: flex;\n  margin-left: 20px;\n  justify-content: space-between;\n  background: #fff;\n  margin-bottom: 10px;\n  padding: 0.8rem;\n  font-size: 14px;\n  font-weight: bold;\n  cursor: pointer;\n  color: #222;\n  font-family: Rajdhani-Regular;\n  /* Icon */\n}\n.tab-label::after {\n  content: \"❯\";\n  width: 1em;\n  height: 1em;\n  text-align: center;\n  transition: all 0.35s;\n}\n.tab-content {\n  max-height: 0;\n  padding: 0 1em;\n  color: #2c3e50;\n  font-family: Rajdhani-Regular;\n  font-size: 14px;\n  background: white;\n  transition: all 0.35s;\n}\n.tab-close {\n  display: flex;\n  justify-content: flex-end;\n  padding: 1em;\n  font-size: 0.75em;\n  background: #fff;\n  cursor: pointer;\n}\n.tab-close:hover {\n  background: #1a252f;\n}\ninput[type=checkbox]:checked, input[type=radio]:checked {\n  background: #f77e21;\n}\ninput:checked + .tab-label {\n  background: #fff;\n}\ninput:checked + .tab-label::after {\n  transform: rotate(90deg);\n}\ninput[type=checkbox], input[type=radio] {\n  padding: 0;\n  position: absolute;\n  left: 10px;\n  top: 14px;\n}\ninput:checked ~ .tab-content {\n  max-height: 100vh;\n  padding: 1em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZnVuY3Rpb25hbC9mdW5jdGlvbmFsLnBhZ2Uuc2NzcyIsIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL2Z1bmN0aW9uYWwvZnVuY3Rpb25hbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FDQWhCO0VBQ0ksb0JBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FERUo7QUNBSTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7QURFSjtBQ0FJO0VBQ0ksc0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBREVSO0FDQUk7RUFDRSxlQUFBO0FERU47QUNBSTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FERVI7QUNBSTtFQUNJLFlBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7RUFDSixXQUFBO0FERUo7QUNHSTtFQUNJLGtCQUFBO0FEQVI7QUNDUTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtBRENaO0FDQ1E7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLFFBQUE7QURDVjtBQ0NRO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxNQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsMEJBQUE7RUFDQSxrQkFBQTtBRENaO0FDRVE7RUFDSSxrQkFBQTtFQUNSLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtFQUNBLFNBQUE7QURBSjtBQ0tBO0VBQ0UsZ0NBQUE7QURGRjtBQ0lBO0VBQ0EsYUFBQTtBRERBO0FDRUE7RUFDSSwwQkFBQTtBREFKO0FDR0E7RUFDSSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBRERKO0FDRUk7RUFDSSxtQkFBQTtFQUNKLDZCQUFBO0VBQ0EsbUJBQUE7QURBSjtBQ0lBO0VBQ0ksbUJBQUE7RUFDQSxZQUFBO0FEREo7QUNHQTtFQUNJLGFBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FEQUo7QUNDSTtFQUNBLDZCQUFBO0FEQ0o7QUNHQTtFQUNJLGtCQUFBO0VBQ0EsZ0JBQUE7QURBSjtBQ0lFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FEREo7QUNHRTtFQUVFLGFBQUE7RUFDQSxpQkFBQTtFQUVRLDhCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ1IsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBRUEsU0FBQTtBRERKO0FDTUU7RUFDRSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUVBLHFCQUFBO0FESEo7QUNLRTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLDZCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBRUEscUJBQUE7QURGSjtBQ0lFO0VBRUUsYUFBQTtFQUVBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FEREo7QUNHRTtFQUNFLG1CQUFBO0FEQUo7QUNFRTtFQUNJLG1CQUFBO0FEQ047QUNDRTtFQUNFLGdCQUFBO0FERUo7QUNBRTtFQUVVLHdCQUFBO0FER1o7QUNBRTtFQUNFLFVBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0FER0o7QUNERTtFQUNFLGlCQUFBO0VBQ0EsWUFBQTtBRElKIiwiZmlsZSI6InNyYy9hcHAvZnVuY3Rpb25hbC9mdW5jdGlvbmFsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBjaGFyc2V0IFwiVVRGLThcIjtcbmlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiMyMzM5NDI7XG4gIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gIGNvbG9yOiAjZmZmO1xuICBwYWRkaW5nOiA1cHg7XG59XG5pb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBwYWRkaW5nOiAwcHg7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBwYWRkaW5nLWxlZnQ6IDQ0cHg7XG59XG5pb24tdG9vbGJhciBpb24taWNvbiB7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG59XG5pb24tdG9vbGJhciBpb24tYmFjay1idXR0b24ge1xuICBmb250LXNpemU6IDEycHg7XG59XG5pb24tdG9vbGJhciAuc2VhcmNoIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuaW9uLXRvb2xiYXIgcCB7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6ICNmNzdlMjE7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICBtYXJnaW46IDBlbTtcbn1cblxuLmZ1bmN0aW9uYWwgLmltZy1ib3gge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4uZnVuY3Rpb25hbCAuaW1nLWJveCBpbWcge1xuICB3aWR0aDogMTAwJTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLmZ1bmN0aW9uYWwgLmltZy1ib3ggaW1nLnZpZGVvLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiBhdXRvO1xuICBsZWZ0OiA0NCU7XG4gIGJvdHRvbTogMjMlO1xuICByaWdodDogMDtcbn1cbi5mdW5jdGlvbmFsIC5pbWctYm94IEgzIHtcbiAgY29sb3I6ICNmZmY7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogMDtcbiAgbGV0dGVyLXNwYWNpbmc6IDJweDtcbiAgZm9udC1zaXplOiAzMnB4O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLmZ1bmN0aW9uYWwgLmltZy1ib3ggaW9uLWljb24ge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNTglO1xuICBmb250LXNpemU6IDUwcHg7XG4gIHotaW5kZXg6IDk5OTk7XG4gIGxlZnQ6IDQzJTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICNmOWY5ZjkgIWltcG9ydGFudDtcbn1cblxuLmZ1bmN0aW9uYWwtY29udGVudCB7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG4uZnVuY3Rpb25hbC1jb250ZW50IGgyIHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG59XG4uZnVuY3Rpb25hbC1jb250ZW50IC5ib3gge1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBwYWRkaW5nOiAxMHB4O1xuICBjb2xvcjogI2ZmZjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuLmZ1bmN0aW9uYWwtY29udGVudCAuYm94IGg1IHtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG5cbi5mdW5jdGlvbmFsIHtcbiAgYmFja2dyb3VuZDogI2Y5ZjlmOTtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uY2lyY3VpdCB7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIG1hcmdpbjogMjBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgIzIyMjtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbn1cbi5jaXJjdWl0IGgzIHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG59XG5cbi50YWJzIHtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udGFiIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4udGFiLWxhYmVsIHtcbiAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAtd2Via2l0LWJveC1wYWNrOiBqdXN0aWZ5O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIHBhZGRpbmc6IDAuOHJlbTtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBjb2xvcjogIzIyMjtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIC8qIEljb24gKi9cbn1cblxuLnRhYi1sYWJlbDo6YWZ0ZXIge1xuICBjb250ZW50OiBcIuKdr1wiO1xuICB3aWR0aDogMWVtO1xuICBoZWlnaHQ6IDFlbTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjM1cztcbiAgdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xufVxuXG4udGFiLWNvbnRlbnQge1xuICBtYXgtaGVpZ2h0OiAwO1xuICBwYWRkaW5nOiAwIDFlbTtcbiAgY29sb3I6ICMyYzNlNTA7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjM1cztcbiAgdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xufVxuXG4udGFiLWNsb3NlIHtcbiAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIC13ZWJraXQtYm94LXBhY2s6IGVuZDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgcGFkZGluZzogMWVtO1xuICBmb250LXNpemU6IDAuNzVlbTtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4udGFiLWNsb3NlOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogIzFhMjUyZjtcbn1cblxuaW5wdXRbdHlwZT1jaGVja2JveF06Y2hlY2tlZCwgaW5wdXRbdHlwZT1yYWRpb106Y2hlY2tlZCB7XG4gIGJhY2tncm91bmQ6ICNmNzdlMjE7XG59XG5cbmlucHV0OmNoZWNrZWQgKyAudGFiLWxhYmVsIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbn1cblxuaW5wdXQ6Y2hlY2tlZCArIC50YWItbGFiZWw6OmFmdGVyIHtcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gIHRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbn1cblxuaW5wdXRbdHlwZT1jaGVja2JveF0sIGlucHV0W3R5cGU9cmFkaW9dIHtcbiAgcGFkZGluZzogMDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAxMHB4O1xuICB0b3A6IDE0cHg7XG59XG5cbmlucHV0OmNoZWNrZWQgfiAudGFiLWNvbnRlbnQge1xuICBtYXgtaGVpZ2h0OiAxMDB2aDtcbiAgcGFkZGluZzogMWVtO1xufSIsImlvbi10b29sYmFye1xuICAgIC0tYmFja2dyb3VuZDojMjMzOTQyO1xuICAgIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gICAgY29sb3I6I2ZmZjtcbiAgICBwYWRkaW5nOiAgNXB4O1xuXG4gICAgaW9uLXRpdGxle1xuICAgIHBhZGRpbmc6IDBweDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgIHBhZGRpbmctbGVmdDo0NHB4O1xuICAgIH0gXG4gICAgaW9uLWljb257XG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgICAgIGNvbG9yOiNmZmY7XG4gICAgICAgIGZvbnQtc2l6ZToyMHB4O1xuICAgIH1cbiAgICBpb24tYmFjay1idXR0b257XG4gICAgICBmb250LXNpemU6IDEycHg7XG4gICAgfVxuICAgIC5zZWFyY2h7XG4gICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgICAgICBmbG9hdDogcmlnaHQ7XG4gICAgICAgIG1hcmdpbi1yaWdodDoxMHB4O1xuICAgIH1cbiAgICBwe1xuICAgICAgICBmbG9hdDpyaWdodDtcbiAgICAgICAgY29sb3I6I2Y3N2UyMTtcbiAgICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgbWFyZ2luOiAwZW07XG4gICAgfVxuICAgXG59XG4uZnVuY3Rpb25hbHtcbiAgICAuaW1nLWJveHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICBpbWd7XG4gICAgICAgICAgICB3aWR0aDoxMDAlO1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB9XG4gICAgICAgIGltZy52aWRlby1pY29ue1xuICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICB3aWR0aDogYXV0bztcbiAgICAgICAgICBsZWZ0OiA0NCU7XG4gICAgICAgICAgYm90dG9tOiAyMyU7XG4gICAgICAgICAgcmlnaHQ6IDA7XG4gICAgICAgIH1cbiAgICAgICAgSDN7XG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIGxlZnQ6IDA7XG4gICAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICAgIHRvcDogMDtcbiAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAycHg7XG4gICAgICAgICAgICBmb250LXNpemU6IDMycHg7XG4gICAgICAgICAgICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICAgICAgICB9XG4gICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDU4JTtcbiAgICBmb250LXNpemU6IDUwcHg7XG4gICAgei1pbmRleDogOTk5OTtcbiAgICBsZWZ0OiA0MyU7XG4gICAgICAgIH1cbiAgICB9XG4gICBcbn1cbmlvbi1jb250ZW50e1xuICAtLWJhY2tncm91bmQ6ICNmOWY5ZjkgIWltcG9ydGFudDtcbn1cbi5mdW5jdGlvbmFsLWNvbnRlbnR7XG5wYWRkaW5nOjIwcHg7XG5oMntcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcblxufVxuLmJveHtcbiAgICBiYWNrZ3JvdW5kOiMyMzM5NDI7XG4gICAgcGFkZGluZzoxMHB4O1xuICAgIGNvbG9yOiNmZmY7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgaDV7XG4gICAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgbWFyZ2luLWJvdHRvbToyMHB4O1xuICAgIH1cbn1cbn1cbi5mdW5jdGlvbmFse1xuICAgIGJhY2tncm91bmQ6ICNmOWY5Zjk7XG4gICAgaGVpZ2h0OjEwMCU7XG59XG4uY2lyY3VpdHtcbiAgICBwYWRkaW5nOjIwcHg7XG4gICAgbWFyZ2luOjIwcHg7XG4gICAgYm9yZGVyOiAxcHggc29saWQgIzIyMjtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGJhY2tncm91bmQ6I2ZmZjtcbiAgICBoM3tcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcblxuICAgIH1cbn1cbi50YWJzIHtcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAvL2JveC1zaGFkb3c6IDAgNHB4IDRweCAtMnB4IHJnYmEoMCwgMCwgMCwgMC41KTtcbiAgfVxuICBcbiAgLnRhYiB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB9XG4gIC50YWItbGFiZWwge1xuICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gICAgLXdlYmtpdC1ib3gtcGFjazoganVzdGlmeTtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgcGFkZGluZzowLjhyZW07XG4gICAgICAgICAgICBmb250LXNpemU6MTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgY29sb3I6IzIyMjtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcblxuICAgIC8qIEljb24gKi9cbiAgfVxuICAudGFiLWxhYmVsOmhvdmVyIHtcbiAgIC8vIGJhY2tncm91bmQ6ICMxYTI1MmY7XG4gIH1cbiAgLnRhYi1sYWJlbDo6YWZ0ZXIge1xuICAgIGNvbnRlbnQ6IFwiXFwyNzZGXCI7XG4gICAgd2lkdGg6IDFlbTtcbiAgICBoZWlnaHQ6IDFlbTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjM1cztcbiAgICB0cmFuc2l0aW9uOiBhbGwgLjM1cztcbiAgfVxuICAudGFiLWNvbnRlbnQge1xuICAgIG1heC1oZWlnaHQ6IDA7XG4gICAgcGFkZGluZzogMCAxZW07XG4gICAgY29sb3I6ICMyYzNlNTA7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgZm9udC1zaXplOjE0cHg7XG4gICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjM1cztcbiAgICB0cmFuc2l0aW9uOiBhbGwgLjM1cztcbiAgfVxuICAudGFiLWNsb3NlIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIC13ZWJraXQtYm94LXBhY2s6IGVuZDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICAgIHBhZGRpbmc6IDFlbTtcbiAgICBmb250LXNpemU6IDAuNzVlbTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAudGFiLWNsb3NlOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kOiAjMWEyNTJmO1xuICB9XG4gIGlucHV0W3R5cGU9Y2hlY2tib3hdOmNoZWNrZWQsIGlucHV0W3R5cGU9cmFkaW9dOmNoZWNrZWR7XG4gICAgICBiYWNrZ3JvdW5kOiAjZjc3ZTIxO1xuICB9XG4gIGlucHV0OmNoZWNrZWQgKyAudGFiLWxhYmVsIHtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICB9XG4gIGlucHV0OmNoZWNrZWQgKyAudGFiLWxhYmVsOjphZnRlciB7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gIH1cblxuICBpbnB1dFt0eXBlPWNoZWNrYm94XSwgaW5wdXRbdHlwZT1yYWRpb10ge1xuICAgIHBhZGRpbmc6IDA7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDEwcHg7XG4gICAgdG9wOiAxNHB4O1xufVxuICBpbnB1dDpjaGVja2VkIH4gLnRhYi1jb250ZW50IHtcbiAgICBtYXgtaGVpZ2h0OiAxMDB2aDtcbiAgICBwYWRkaW5nOiAxZW07XG4gIH0iXX0= */");

/***/ }),

/***/ "./src/app/functional/functional.page.ts":
/*!***********************************************!*\
  !*** ./src/app/functional/functional.page.ts ***!
  \***********************************************/
/*! exports provided: FunctionalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FunctionalPage", function() { return FunctionalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let FunctionalPage = class FunctionalPage {
    constructor() { }
    ngOnInit() {
    }
};
FunctionalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-functional',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./functional.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/functional/functional.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./functional.page.scss */ "./src/app/functional/functional.page.scss")).default]
    })
], FunctionalPage);



/***/ })

}]);
//# sourceMappingURL=functional-functional-module-es2015.js.map