function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppProfileProfilePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!--<ion-header >\n  <div class=\"header\">\n  <ion-row>\n    <ion-col size=\"1\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button color=\"dark\" text=\"\" icon=\"ios-arrow-back\" ></ion-back-button>\n      </ion-buttons>\n    </ion-col>\n  <ion-col size=\"9\">\n    <ion-title> PROFILE</ion-title>\n  </ion-col>\n  <ion-col size=\"1\" text-right>\n    <ion-icon name=\"chatbox-outline\"></ion-icon>\n  </ion-col>\n  <ion-col size=\"1\" text-right>\n    <ion-icon name=\"settings-outline\"></ion-icon>\n  </ion-col>\n</ion-row>\n</div>\n</ion-header>-->\n<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button ></ion-menu-button>\n      <!-- <ion-back-button\n      color=\"light\"\n      text=\"\"\n      icon=\"chevron-back-outline\"\n      defaultHref=\"week-workout\"\n      *ngIf=\"back\"\n    ></ion-back-button> -->\n      <!-- <ion-icon name=\"chevron-back-outline\" *ngIf=\"back\" (click)=\"goBack()\" style=\"font-size: 28px;\"></ion-icon> -->\n    </ion-buttons>\n    <ion-title>PROFILE</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-icon name=\"chatbubbles\"></ion-icon>\n      <ion-icon name=\"settings\" (click)=\"setting()\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"section\">\n    <div class=\"profile\">\n      <div class=\"profile-img\">\n        <img src=\"assets/images/profile_pic.jpg\" *ngIf=\"userData?.picture == null || userData?.picture =='' \"/>\n        <img src=\"{{userData.picture}}\" *ngIf=\"userData?.picture != null && userData?.picture !='' \"/>\n        <p>{{userData?.name}}</p>\n      </div>\n      <div class=\"edit-profile\">\n        <h3>Basic Info</h3>\n        <ion-item>\n          <ion-label>Email</ion-label>\n          <!-- <ion-input placeholder=\"abc@example.com\" readonly></ion-input> -->\n          <p class=\"profile-para\">{{userData?.email}}</p>\n        </ion-item>\n        <ion-item>\n          <ion-label>I Measure in</ion-label>\n          <ion-input placeholder=\"lb\" readonly></ion-input>\n        </ion-item>\n        <ion-item>\n          <ion-label>Goal</ion-label>\n          <p class=\"profile-para\" *ngIf=\"userData?.goal =='fat_loss'\">Fat Loss</p>\n          <p class=\"profile-para\" *ngIf=\"userData?.goal =='fat_muscle'\">Burn Fat, Build Muscle</p>\n          <p class=\"profile-para\" *ngIf=\"userData?.goal =='build_muscle'\">Build Muscle</p>\n        </ion-item>\n        <ion-item *ngIf=\"userData?.gender && userData?.gender!=null\">\n          <ion-label>Gender</ion-label>\n          <p class=\"profile-para\" > {{userData?.gender}}</p>\n\n          <!-- <ion-select placeholder=\"Male\" readonly> \n            <ion-select-option value=\"m\">Male</ion-select-option>\n            <ion-select-option value=\"f\">Female</ion-select-option>\n          </ion-select> -->\n        </ion-item>\n        <ion-item *ngIf=\"userData?.age && userData?.age!=null\">\n          <ion-label>Age</ion-label>\n          <!-- <ion-input type=\"number\" placeholder=\"24\" readonly></ion-input> -->\n          <p class=\"profile-para\" > {{userData?.age}}</p>\n        </ion-item>\n        <ion-item *ngIf=\"userData?.height && userData?.height!=null\">\n          <ion-label>Height</ion-label>\n          <!-- <ion-input placeholder=\"177cm\" readonly></ion-input> -->\n          <p class=\"profile-para\" > {{userData?.height}}</p>\n        </ion-item>\n        <ion-item *ngIf=\"userData?.weight && userData?.weight!=null\">\n          <ion-label>Weight</ion-label>\n          <!-- <ion-input placeholder=\"82Kg\" readonly></ion-input> -->\n          <p class=\"profile-para\" > {{userData?.weight}}</p>\n        </ion-item>\n      </div>\n    </div>\n    <div class=\"bottom\">\n      <h4 class=\"edit-profile-btn\" *ngIf=\"!back\" (click)=\"editProfile()\">Edit Profile</h4>\n      <h4>Delete my account</h4>\n    </div>\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/profile/profile-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/profile/profile-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: ProfilePageRoutingModule */

  /***/
  function srcAppProfileProfileRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfilePageRoutingModule", function () {
      return ProfilePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./profile.page */
    "./src/app/profile/profile.page.ts");

    var routes = [{
      path: '',
      component: _profile_page__WEBPACK_IMPORTED_MODULE_3__["ProfilePage"]
    }];

    var ProfilePageRoutingModule = function ProfilePageRoutingModule() {
      _classCallCheck(this, ProfilePageRoutingModule);
    };

    ProfilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ProfilePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/profile/profile.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/profile/profile.module.ts ***!
    \*******************************************/

  /*! exports provided: ProfilePageModule */

  /***/
  function srcAppProfileProfileModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function () {
      return ProfilePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./profile-routing.module */
    "./src/app/profile/profile-routing.module.ts");
    /* harmony import */


    var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./profile.page */
    "./src/app/profile/profile.page.ts");

    var ProfilePageModule = function ProfilePageModule() {
      _classCallCheck(this, ProfilePageModule);
    };

    ProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProfilePageRoutingModule"]],
      declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]]
    })], ProfilePageModule);
    /***/
  },

  /***/
  "./src/app/profile/profile.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/profile/profile.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppProfileProfilePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n  padding: 5px;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 50px;\n  letter-spacing: 1px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n  margin: 5px;\n  margin-right: 10px;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\n.profile {\n  padding: 20px 20px 20px 10px;\n  background: #fff;\n}\n.profile .profile-img {\n  padding: 20px;\n  text-align: center;\n  margin: 0 auto;\n  position: relative;\n}\n.profile .profile-img img {\n  position: relative;\n  width: 100px;\n  height: 100px;\n  border-radius: 50%;\n}\n.profile .profile-img ion-icon {\n  position: absolute;\n  right: 40%;\n  color: #ffff;\n  background: #f77e21;\n  top: 20%;\n  border-radius: 100px;\n  padding: 5px;\n}\n.profile .profile-img p {\n  margin: 0;\n}\n.profile .edit-profile ion-input,\n.profile .edit-profile ion-select,\n.profile .edit-profile ion-datetime {\n  text-align: right;\n  line-height: 30px;\n  margin-bottom: 10px;\n  font-family: Rajdhani-Regular;\n}\n.profile .edit-profile h3 {\n  text-align: center;\n  color: #233942;\n  font-family: Rajdhani-Bold;\n  padding-bottom: 20px;\n  margin-top: 0;\n}\n.profile .edit-profile ion-label {\n  font-family: Rajdhani-Regular;\n}\n.section {\n  background: #fff;\n}\n.measurements {\n  padding: 20px;\n  background: #fff;\n  margin-top: 20px;\n}\n.measurements h4 {\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n}\n.measurements img {\n  text-align: center;\n  padding: 100px 20px;\n  margin: 0 auto;\n}\n.measurements h5 {\n  text-align: center;\n  font-family: Rajdhani-Bold;\n}\n.measurements p {\n  font-size: 18px;\n  font-family: Rajdhani-Regular;\n  margin: 3px;\n}\n.bottom {\n  background: #fff;\n}\n.bottom h4 {\n  color: red;\n  text-align: center;\n  font-family: Rajdhani-Regular;\n}\nion-input input:disabled {\n  opacity: 1 !important;\n}\n.edit-profile-btn {\n  color: #f77e21 !important;\n}\n.profile-para {\n  color: grey;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL3Byb2ZpbGUvcHJvZmlsZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3Byb2ZpbGUvcHJvZmlsZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNDSjtBRENJO0VBQ0ksWUFBQTtFQUNBLGdCQUFBO0VBQ0EsNkJBQUE7RUFFQSxrQkFBQTtFQUNBLG1CQUFBO0FDQVI7QURHSTtFQUNJLFdBQUE7QUNEUjtBRElJO0VBQ0ksc0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQ0ZSO0FES0k7RUFDSSxZQUFBO0VBQ0EsY0FBQTtFQUNBLDBCQUFBO0VBQ0EsV0FBQTtBQ0hSO0FET0E7RUFDSSw0QkFBQTtFQUNBLGdCQUFBO0FDSko7QURNSTtFQUNJLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0pSO0FETVE7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUNKWjtBRE9RO0VBQ0ksa0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsUUFBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtBQ0xaO0FEUVE7RUFDSSxTQUFBO0FDTlo7QURZUTs7O0VBR0ksaUJBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsNkJBQUE7QUNWWjtBRGFRO0VBQ0ksa0JBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxvQkFBQTtFQUNBLGFBQUE7QUNYWjtBRGNRO0VBQ0ksNkJBQUE7QUNaWjtBRGtCQTtFQUNJLGdCQUFBO0FDZko7QURrQkE7RUFDSSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ2ZKO0FEaUJJO0VBQ0ksY0FBQTtFQUNBLDBCQUFBO0FDZlI7QURrQkk7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQ2hCUjtBRG1CSTtFQUNJLGtCQUFBO0VBQ0EsMEJBQUE7QUNqQlI7QURvQkk7RUFDSSxlQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0FDbEJSO0FEc0JBO0VBQ0ksZ0JBQUE7QUNuQko7QURxQkk7RUFDSSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSw2QkFBQTtBQ25CUjtBRHlCSTtFQUNJLHFCQUFBO0FDdEJSO0FEMkJBO0VBQ0kseUJBQUE7QUN4Qko7QUQwQkE7RUFDSSxXQUFBO0VBQ0EsZUFBQTtBQ3ZCSiIsImZpbGUiOiJzcmMvYXBwL3Byb2ZpbGUvcHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyIHtcbiAgICAtLWJhY2tncm91bmQ6ICMyMzM5NDI7XG4gICAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBwYWRkaW5nOiA1cHg7XG5cbiAgICBpb24tdGl0bGUge1xuICAgICAgICBwYWRkaW5nOiAwcHg7XG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgICAgICAvLyBwYWRkaW5nLWxlZnQ6IDUwcHg7XG4gICAgICAgIHBhZGRpbmctbGVmdDogNTBweDtcbiAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICB9XG5cbiAgICBpb24tbWVudS1idXR0b24ge1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICB9XG5cbiAgICBpb24taWNvbiB7XG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgIG1hcmdpbjogNXB4O1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgfVxuXG4gICAgcCB7XG4gICAgICAgIGZsb2F0OiByaWdodDtcbiAgICAgICAgY29sb3I6ICNmNzdlMjE7XG4gICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgICAgICBtYXJnaW46IDBlbTtcbiAgICB9XG59XG5cbi5wcm9maWxlIHtcbiAgICBwYWRkaW5nOiAyMHB4IDIwcHggMjBweCAxMHB4O1xuICAgIGJhY2tncm91bmQ6ICNmZmY7XG5cbiAgICAucHJvZmlsZS1pbWcge1xuICAgICAgICBwYWRkaW5nOiAyMHB4O1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIG1hcmdpbjogMCBhdXRvO1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAgICAgaW1nIHtcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgICAgIHdpZHRoOiAxMDBweDtcbiAgICAgICAgICAgIGhlaWdodDogMTAwcHg7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgIH1cblxuICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICByaWdodDogNDAlO1xuICAgICAgICAgICAgY29sb3I6ICNmZmZmO1xuICAgICAgICAgICAgYmFja2dyb3VuZDogI2Y3N2UyMTtcbiAgICAgICAgICAgIHRvcDogMjAlO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTAwcHg7XG4gICAgICAgICAgICBwYWRkaW5nOiA1cHg7XG4gICAgICAgIH1cblxuICAgICAgICBwIHtcbiAgICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5lZGl0LXByb2ZpbGUge1xuXG4gICAgICAgIGlvbi1pbnB1dCxcbiAgICAgICAgaW9uLXNlbGVjdCxcbiAgICAgICAgaW9uLWRhdGV0aW1lIHtcbiAgICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDMwcHg7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgICAgIH1cblxuICAgICAgICBoMyB7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICBjb2xvcjogIzIzMzk0MjtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDIwcHg7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAwO1xuICAgICAgICB9XG5cbiAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuXG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5zZWN0aW9uIHtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuXG4ubWVhc3VyZW1lbnRzIHtcbiAgICBwYWRkaW5nOiAyMHB4O1xuICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgbWFyZ2luLXRvcDogMjBweDtcblxuICAgIGg0IHtcbiAgICAgICAgY29sb3I6ICNmNzdlMjE7XG4gICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgIH1cblxuICAgIGltZyB7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgcGFkZGluZzogMTAwcHggMjBweDtcbiAgICAgICAgbWFyZ2luOiAwIGF1dG87XG4gICAgfVxuXG4gICAgaDUge1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgIH1cblxuICAgIHAge1xuICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgICAgICBtYXJnaW46IDNweDtcbiAgICB9XG59XG5cbi5ib3R0b20ge1xuICAgIGJhY2tncm91bmQ6ICNmZmY7XG5cbiAgICBoNCB7XG4gICAgICAgIGNvbG9yOiByZWQ7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG5cbiAgICB9XG59XG5cbmlvbi1pbnB1dCB7XG4gICAgaW5wdXQ6ZGlzYWJsZWQge1xuICAgICAgICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XG4gICAgfVxuXG59XG5cbi5lZGl0LXByb2ZpbGUtYnRuIHtcbiAgICBjb2xvcjogI2Y3N2UyMSAhaW1wb3J0YW50O1xufVxuLnByb2ZpbGUtcGFyYXtcbiAgICBjb2xvcjogZ3JleTtcbiAgICBmb250LXNpemU6IDE0cHg7XG59IiwiLmhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG4gIHBhZGRpbmc6IDVweDtcbn1cbi5oZWFkZXIgaW9uLXRpdGxlIHtcbiAgcGFkZGluZzogMHB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgcGFkZGluZy1sZWZ0OiA1MHB4O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xufVxuLmhlYWRlciBpb24tbWVudS1idXR0b24ge1xuICBjb2xvcjogI2ZmZjtcbn1cbi5oZWFkZXIgaW9uLWljb24ge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBtYXJnaW46IDVweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLmhlYWRlciBwIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBjb2xvcjogI2Y3N2UyMTtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gIG1hcmdpbjogMGVtO1xufVxuXG4ucHJvZmlsZSB7XG4gIHBhZGRpbmc6IDIwcHggMjBweCAyMHB4IDEwcHg7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG59XG4ucHJvZmlsZSAucHJvZmlsZS1pbWcge1xuICBwYWRkaW5nOiAyMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbjogMCBhdXRvO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4ucHJvZmlsZSAucHJvZmlsZS1pbWcgaW1nIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogMTAwcHg7XG4gIGhlaWdodDogMTAwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cbi5wcm9maWxlIC5wcm9maWxlLWltZyBpb24taWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDQwJTtcbiAgY29sb3I6ICNmZmZmO1xuICBiYWNrZ3JvdW5kOiAjZjc3ZTIxO1xuICB0b3A6IDIwJTtcbiAgYm9yZGVyLXJhZGl1czogMTAwcHg7XG4gIHBhZGRpbmc6IDVweDtcbn1cbi5wcm9maWxlIC5wcm9maWxlLWltZyBwIHtcbiAgbWFyZ2luOiAwO1xufVxuLnByb2ZpbGUgLmVkaXQtcHJvZmlsZSBpb24taW5wdXQsXG4ucHJvZmlsZSAuZWRpdC1wcm9maWxlIGlvbi1zZWxlY3QsXG4ucHJvZmlsZSAuZWRpdC1wcm9maWxlIGlvbi1kYXRldGltZSB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBsaW5lLWhlaWdodDogMzBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG59XG4ucHJvZmlsZSAuZWRpdC1wcm9maWxlIGgzIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogIzIzMzk0MjtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gIHBhZGRpbmctYm90dG9tOiAyMHB4O1xuICBtYXJnaW4tdG9wOiAwO1xufVxuLnByb2ZpbGUgLmVkaXQtcHJvZmlsZSBpb24tbGFiZWwge1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbn1cblxuLnNlY3Rpb24ge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuXG4ubWVhc3VyZW1lbnRzIHtcbiAgcGFkZGluZzogMjBweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgbWFyZ2luLXRvcDogMjBweDtcbn1cbi5tZWFzdXJlbWVudHMgaDQge1xuICBjb2xvcjogI2Y3N2UyMTtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG59XG4ubWVhc3VyZW1lbnRzIGltZyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogMTAwcHggMjBweDtcbiAgbWFyZ2luOiAwIGF1dG87XG59XG4ubWVhc3VyZW1lbnRzIGg1IHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbn1cbi5tZWFzdXJlbWVudHMgcCB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIG1hcmdpbjogM3B4O1xufVxuXG4uYm90dG9tIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbn1cbi5ib3R0b20gaDQge1xuICBjb2xvcjogcmVkO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xufVxuXG5pb24taW5wdXQgaW5wdXQ6ZGlzYWJsZWQge1xuICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XG59XG5cbi5lZGl0LXByb2ZpbGUtYnRuIHtcbiAgY29sb3I6ICNmNzdlMjEgIWltcG9ydGFudDtcbn1cblxuLnByb2ZpbGUtcGFyYSB7XG4gIGNvbG9yOiBncmV5O1xuICBmb250LXNpemU6IDE0cHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/profile/profile.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/profile/profile.page.ts ***!
    \*****************************************/

  /*! exports provided: ProfilePage */

  /***/
  function srcAppProfileProfilePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfilePage", function () {
      return ProfilePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _service_events_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../service/events.service */
    "./src/app/service/events.service.ts");

    var ProfilePage = /*#__PURE__*/function () {
      function ProfilePage(actionSheetController, navCtrl, router, route, events) {
        var _this = this;

        _classCallCheck(this, ProfilePage);

        this.actionSheetController = actionSheetController;
        this.navCtrl = navCtrl;
        this.router = router;
        this.route = route;
        this.events = events;
        this.back = false;
        this.userData = '';
        console.log(JSON.parse(localStorage.getItem('userData')));
        this.userData = JSON.parse(localStorage.getItem('userData'));
        this.route.queryParams.subscribe(function (params) {
          _this.back = params["back"];
        });
        console.log('back:: ', this.back);
        this.events.subscribe('user:created', function (data) {
          _this.userData = JSON.parse(localStorage.getItem('userData'));
        });
      }

      _createClass(ProfilePage, [{
        key: "setting",
        value: function setting() {
          this.navCtrl.navigateForward("/settings");
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.navigateRoot("/week-workout");
        }
      }, {
        key: "editProfile",
        value: function editProfile() {
          this.navCtrl.navigateForward("/edit-profile");
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return ProfilePage;
    }();

    ProfilePage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ActionSheetController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _service_events_service__WEBPACK_IMPORTED_MODULE_4__["EventsService"]
      }];
    };

    ProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: "app-profile",
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./profile.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./profile.page.scss */
      "./src/app/profile/profile.page.scss"))["default"]]
    })], ProfilePage);
    /***/
  }
}]);
//# sourceMappingURL=profile-profile-module-es5.js.map