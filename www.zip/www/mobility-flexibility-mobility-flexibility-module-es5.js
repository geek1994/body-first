function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mobility-flexibility-mobility-flexibility-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/mobility-flexibility/mobility-flexibility.page.html":
  /*!***********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/mobility-flexibility/mobility-flexibility.page.html ***!
    \***********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMobilityFlexibilityMobilityFlexibilityPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!--<ion-header>\n  <div class=\"header\">\n    <ion-row>\n      <ion-col size=\"1\">\n        <ion-icon name=\"chevron-back-outline\"></ion-icon>\n      </ion-col>\n      <ion-col size=\"9\">\n        <ion-title> MOBILITY & FLEXIBILITY</ion-title>\n      </ion-col>\n      <ion-col size=\"2\" text-right>\n    <ion-icon name=\"heart-outline\" class=\"heart\"></ion-icon>\n        \n      </ion-col>\n    </ion-row>\n  </div>\n</ion-header>-->\n<ion-header>\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\" text=\"\" icon=\"chevron-back-outline\"></ion-back-button>\n    </ion-buttons> -->\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>MOBILITY & FLEXIBILITY</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-icon name=\"heart-outline\" class=\"heart\"></ion-icon>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"functional\">\n    <div class=\"img-box\">\n      <img src=\"assets/images/f1.png\">\n      <h3>Mobility <br/>& <BR/>Flexibility</h3>\n      <img src=\"assets/images/video.png\" class=\"video-icon\">\n    </div>\n\n    <!-- <div class=\"functional-content\">\n      <h2>MOBILITY & FLEXIBILITY</h2>\n      <div class=\"box\">\n        <ion-row>\n          <ion-col size=\"6\">\n            <h5>Primary</h5>\n            <img src=\"assets/images/m1.png\">\n          </ion-col>\n          <ion-col size=\"6\">\n            <h5>Secondary</h5>\n            <img src=\"assets/images/m2.png\">\n          </ion-col>\n        </ion-row>\n      </div>\n    </div> -->\n\n    <div class=\"circuit\">\n      <div class=\"tabs\">\n        <div class=\"tab\">\n          <input type=\"checkbox\" id=\"chck1\">\n          <label class=\"tab-label\" for=\"chck1\">Exercise 1</label>\n          <div class=\"tab-content\">\n            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsum, reiciendis!\n          </div>\n        </div>\n        <div class=\"tab\">\n          <input type=\"checkbox\" id=\"chck2\">\n          <label class=\"tab-label\" for=\"chck2\">Exercise 2</label>\n          <div class=\"tab-content\">\n            Lorem ipsum dolor sit amet consectetur adipisicing elit. A, in!\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/mobility-flexibility/mobility-flexibility-routing.module.ts":
  /*!*****************************************************************************!*\
    !*** ./src/app/mobility-flexibility/mobility-flexibility-routing.module.ts ***!
    \*****************************************************************************/

  /*! exports provided: MobilityFlexibilityPageRoutingModule */

  /***/
  function srcAppMobilityFlexibilityMobilityFlexibilityRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MobilityFlexibilityPageRoutingModule", function () {
      return MobilityFlexibilityPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _mobility_flexibility_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./mobility-flexibility.page */
    "./src/app/mobility-flexibility/mobility-flexibility.page.ts");

    var routes = [{
      path: '',
      component: _mobility_flexibility_page__WEBPACK_IMPORTED_MODULE_3__["MobilityFlexibilityPage"]
    }];

    var MobilityFlexibilityPageRoutingModule = function MobilityFlexibilityPageRoutingModule() {
      _classCallCheck(this, MobilityFlexibilityPageRoutingModule);
    };

    MobilityFlexibilityPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MobilityFlexibilityPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/mobility-flexibility/mobility-flexibility.module.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/mobility-flexibility/mobility-flexibility.module.ts ***!
    \*********************************************************************/

  /*! exports provided: MobilityFlexibilityPageModule */

  /***/
  function srcAppMobilityFlexibilityMobilityFlexibilityModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MobilityFlexibilityPageModule", function () {
      return MobilityFlexibilityPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _mobility_flexibility_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./mobility-flexibility-routing.module */
    "./src/app/mobility-flexibility/mobility-flexibility-routing.module.ts");
    /* harmony import */


    var _mobility_flexibility_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./mobility-flexibility.page */
    "./src/app/mobility-flexibility/mobility-flexibility.page.ts");

    var MobilityFlexibilityPageModule = function MobilityFlexibilityPageModule() {
      _classCallCheck(this, MobilityFlexibilityPageModule);
    };

    MobilityFlexibilityPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _mobility_flexibility_routing_module__WEBPACK_IMPORTED_MODULE_5__["MobilityFlexibilityPageRoutingModule"]],
      declarations: [_mobility_flexibility_page__WEBPACK_IMPORTED_MODULE_6__["MobilityFlexibilityPage"]]
    })], MobilityFlexibilityPageModule);
    /***/
  },

  /***/
  "./src/app/mobility-flexibility/mobility-flexibility.page.scss":
  /*!*********************************************************************!*\
    !*** ./src/app/mobility-flexibility/mobility-flexibility.page.scss ***!
    \*********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppMobilityFlexibilityMobilityFlexibilityPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "@charset \"UTF-8\";\nion-toolbar {\n  --background:#233942;\n  background: #233942;\n  color: #fff;\n  padding: 5px;\n}\nion-toolbar ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  letter-spacing: 1px;\n  padding-left: 44px;\n}\nion-toolbar ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n  margin-right: 10px;\n}\nion-toolbar .search {\n  text-align: right;\n  float: right;\n}\nion-toolbar p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\nion-toolbar ion-icon.heart {\n  float: right;\n}\nion-toolbar ion-back-button {\n  display: block;\n  font-size: 12px;\n}\nion-content {\n  --background: #f9f9f9 !important;\n}\n.functional .img-box {\n  position: relative;\n  text-align: center;\n}\n.functional .img-box img {\n  position: relative;\n  width: 100%;\n}\n.functional .img-box img.video-icon {\n  position: absolute;\n  width: auto;\n  left: 44%;\n  bottom: 23%;\n  right: 0;\n}\n.functional .img-box H3 {\n  text-align: center;\n  color: #fff;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 0;\n  letter-spacing: 2px;\n  font-size: 36px;\n  font-family: Rajdhani-Bold;\n}\n.functional .img-box ion-icon {\n  text-align: center;\n  color: #fff;\n  position: absolute;\n  top: 58%;\n  font-size: 50px;\n  z-index: 9999;\n  left: 43%;\n}\n.functional-content {\n  padding: 20px;\n}\n.functional-content h2 {\n  font-family: Rajdhani-Bold;\n  margin: 0;\n  padding-bottom: 18px;\n}\n.functional-content .box {\n  background: #233942;\n  padding: 10px;\n  color: #fff;\n  text-align: center;\n  border-radius: 10px;\n}\n.functional-content .box h5 {\n  letter-spacing: 1px;\n  font-family: Rajdhani-Regular;\n  margin-bottom: 20px;\n}\n.functional {\n  background: #f9f9f9;\n  height: 100%;\n}\n.circuit {\n  padding: 20px;\n  margin: 20px;\n  border: 1px solid #222;\n  border-radius: 10px;\n  background: #fff;\n}\n.circuit h3 {\n  font-family: Rajdhani-Regular;\n  margin: 0;\n  margin-bottom: 10px;\n}\n.tabs {\n  border-radius: 8px;\n  overflow: hidden;\n}\n.tab {\n  width: 100%;\n  color: white;\n  overflow: hidden;\n  position: relative;\n}\n.tab-label {\n  display: flex;\n  margin-left: 20px;\n  justify-content: space-between;\n  background: #fff;\n  margin-bottom: 10px;\n  padding: 0.8rem;\n  font-size: 14px;\n  font-weight: bold;\n  cursor: pointer;\n  color: #222;\n  font-family: Rajdhani-Regular;\n  /* Icon */\n}\n.tab-label::after {\n  content: \"❯\";\n  width: 1em;\n  height: 1em;\n  text-align: center;\n  transition: all 0.35s;\n}\n.tab-content {\n  max-height: 0;\n  padding: 0 1em;\n  color: #2c3e50;\n  font-family: Rajdhani-Regular;\n  font-size: 14px;\n  background: white;\n  transition: all 0.35s;\n}\n.tab-close {\n  display: flex;\n  justify-content: flex-end;\n  padding: 1em;\n  font-size: 0.75em;\n  background: #fff;\n  cursor: pointer;\n}\n.tab-close:hover {\n  background: #1a252f;\n}\ninput[type=checkbox]:checked, input[type=radio]:checked {\n  background: #f77e21;\n}\ninput:checked + .tab-label {\n  background: #fff;\n}\ninput:checked + .tab-label::after {\n  transform: rotate(90deg);\n}\ninput[type=checkbox], input[type=radio] {\n  padding: 0;\n  position: absolute;\n  left: 10px;\n  top: 14px;\n}\ninput:checked ~ .tab-content {\n  max-height: 100vh;\n  padding: 1em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9iaWxpdHktZmxleGliaWxpdHkvbW9iaWxpdHktZmxleGliaWxpdHkucGFnZS5zY3NzIiwiL1ZvbHVtZXMvRGlzazIvYm9keUZpcnN0L3NyYy9hcHAvbW9iaWxpdHktZmxleGliaWxpdHkvbW9iaWxpdHktZmxleGliaWxpdHkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQ0FoQjtFQUNJLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBREVKO0FDQUk7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QURFSjtBQ0FJO0VBQ0ksc0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FERVI7QUNDSTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtBRENSO0FDQ0k7RUFDSSxZQUFBO0VBQ0EsY0FBQTtFQUNKLDBCQUFBO0VBQ0EsV0FBQTtBRENKO0FDQ0k7RUFDSSxZQUFBO0FEQ1I7QUNDSTtFQUNJLGNBQUE7RUFDQSxlQUFBO0FEQ1I7QUNFQTtFQUNFLGdDQUFBO0FEQ0Y7QUNFSTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7QURDUjtBQ0FRO0VBQ0Usa0JBQUE7RUFDRSxXQUFBO0FERVo7QUNBUTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtBREVWO0FDQVE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsTUFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLDBCQUFBO0FERVo7QUNBUTtFQUNJLGtCQUFBO0VBQ1IsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0VBQ0EsU0FBQTtBREVKO0FDRUE7RUFDQSxhQUFBO0FEQ0E7QUNBQTtFQUNJLDBCQUFBO0VBQ0EsU0FBQTtFQUNBLG9CQUFBO0FERUo7QUNBQTtFQUNJLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FERUo7QUNESTtFQUNJLG1CQUFBO0VBQ0osNkJBQUE7RUFDQSxtQkFBQTtBREdKO0FDRUE7RUFDSSxtQkFBQTtFQUNBLFlBQUE7QURDSjtBQ0NBO0VBQ0ksYUFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QURFSjtBQ0RJO0VBQ0EsNkJBQUE7RUFDQSxTQUFBO0VBQ0EsbUJBQUE7QURHSjtBQ0FBO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtBREdKO0FDQ0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QURFSjtBQ0FFO0VBRUUsYUFBQTtFQUNBLGlCQUFBO0VBRVEsOEJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDUixpQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7RUFFQSxTQUFBO0FERUo7QUNHRTtFQUNFLFlBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBRUEscUJBQUE7QURBSjtBQ0VFO0VBQ0UsYUFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0EsNkJBQUE7RUFDSixlQUFBO0VBQ0ksaUJBQUE7RUFFQSxxQkFBQTtBRENKO0FDQ0U7RUFFRSxhQUFBO0VBRVEseUJBQUE7RUFDUixZQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QURFSjtBQ0FFO0VBQ0UsbUJBQUE7QURHSjtBQ0RFO0VBQ0ksbUJBQUE7QURJTjtBQ0ZFO0VBQ0UsZ0JBQUE7QURLSjtBQ0hFO0VBRVUsd0JBQUE7QURNWjtBQ0hFO0VBQ0UsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7QURNSjtBQ0pFO0VBQ0UsaUJBQUE7RUFDQSxZQUFBO0FET0oiLCJmaWxlIjoic3JjL2FwcC9tb2JpbGl0eS1mbGV4aWJpbGl0eS9tb2JpbGl0eS1mbGV4aWJpbGl0eS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAY2hhcnNldCBcIlVURi04XCI7XG5pb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDojMjMzOTQyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogNXB4O1xufVxuaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgcGFkZGluZzogMHB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgcGFkZGluZy1sZWZ0OiA0NHB4O1xufVxuaW9uLXRvb2xiYXIgaW9uLWljb24ge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5pb24tdG9vbGJhciAuc2VhcmNoIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGZsb2F0OiByaWdodDtcbn1cbmlvbi10b29sYmFyIHAge1xuICBmbG9hdDogcmlnaHQ7XG4gIGNvbG9yOiAjZjc3ZTIxO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgbWFyZ2luOiAwZW07XG59XG5pb24tdG9vbGJhciBpb24taWNvbi5oZWFydCB7XG4gIGZsb2F0OiByaWdodDtcbn1cbmlvbi10b29sYmFyIGlvbi1iYWNrLWJ1dHRvbiB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBmb250LXNpemU6IDEycHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjZjlmOWY5ICFpbXBvcnRhbnQ7XG59XG5cbi5mdW5jdGlvbmFsIC5pbWctYm94IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uZnVuY3Rpb25hbCAuaW1nLWJveCBpbWcge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiAxMDAlO1xufVxuLmZ1bmN0aW9uYWwgLmltZy1ib3ggaW1nLnZpZGVvLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiBhdXRvO1xuICBsZWZ0OiA0NCU7XG4gIGJvdHRvbTogMjMlO1xuICByaWdodDogMDtcbn1cbi5mdW5jdGlvbmFsIC5pbWctYm94IEgzIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgdG9wOiAwO1xuICBsZXR0ZXItc3BhY2luZzogMnB4O1xuICBmb250LXNpemU6IDM2cHg7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xufVxuLmZ1bmN0aW9uYWwgLmltZy1ib3ggaW9uLWljb24ge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNTglO1xuICBmb250LXNpemU6IDUwcHg7XG4gIHotaW5kZXg6IDk5OTk7XG4gIGxlZnQ6IDQzJTtcbn1cblxuLmZ1bmN0aW9uYWwtY29udGVudCB7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG4uZnVuY3Rpb25hbC1jb250ZW50IGgyIHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gIG1hcmdpbjogMDtcbiAgcGFkZGluZy1ib3R0b206IDE4cHg7XG59XG4uZnVuY3Rpb25hbC1jb250ZW50IC5ib3gge1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBwYWRkaW5nOiAxMHB4O1xuICBjb2xvcjogI2ZmZjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuLmZ1bmN0aW9uYWwtY29udGVudCAuYm94IGg1IHtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG5cbi5mdW5jdGlvbmFsIHtcbiAgYmFja2dyb3VuZDogI2Y5ZjlmOTtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uY2lyY3VpdCB7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIG1hcmdpbjogMjBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgIzIyMjtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbn1cbi5jaXJjdWl0IGgzIHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIG1hcmdpbjogMDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cblxuLnRhYnMge1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi50YWIge1xuICB3aWR0aDogMTAwJTtcbiAgY29sb3I6IHdoaXRlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi50YWItbGFiZWwge1xuICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgZGlzcGxheTogZmxleDtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gIC13ZWJraXQtYm94LXBhY2s6IGp1c3RpZnk7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgcGFkZGluZzogMC44cmVtO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGNvbG9yOiAjMjIyO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgLyogSWNvbiAqL1xufVxuXG4udGFiLWxhYmVsOjphZnRlciB7XG4gIGNvbnRlbnQ6IFwi4p2vXCI7XG4gIHdpZHRoOiAxZW07XG4gIGhlaWdodDogMWVtO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xuICB0cmFuc2l0aW9uOiBhbGwgMC4zNXM7XG59XG5cbi50YWItY29udGVudCB7XG4gIG1heC1oZWlnaHQ6IDA7XG4gIHBhZGRpbmc6IDAgMWVtO1xuICBjb2xvcjogIzJjM2U1MDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xuICB0cmFuc2l0aW9uOiBhbGwgMC4zNXM7XG59XG5cbi50YWItY2xvc2Uge1xuICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgZGlzcGxheTogZmxleDtcbiAgLXdlYmtpdC1ib3gtcGFjazogZW5kO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICBwYWRkaW5nOiAxZW07XG4gIGZvbnQtc2l6ZTogMC43NWVtO1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi50YWItY2xvc2U6aG92ZXIge1xuICBiYWNrZ3JvdW5kOiAjMWEyNTJmO1xufVxuXG5pbnB1dFt0eXBlPWNoZWNrYm94XTpjaGVja2VkLCBpbnB1dFt0eXBlPXJhZGlvXTpjaGVja2VkIHtcbiAgYmFja2dyb3VuZDogI2Y3N2UyMTtcbn1cblxuaW5wdXQ6Y2hlY2tlZCArIC50YWItbGFiZWwge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuXG5pbnB1dDpjaGVja2VkICsgLnRhYi1sYWJlbDo6YWZ0ZXIge1xuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbiAgdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xufVxuXG5pbnB1dFt0eXBlPWNoZWNrYm94XSwgaW5wdXRbdHlwZT1yYWRpb10ge1xuICBwYWRkaW5nOiAwO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDEwcHg7XG4gIHRvcDogMTRweDtcbn1cblxuaW5wdXQ6Y2hlY2tlZCB+IC50YWItY29udGVudCB7XG4gIG1heC1oZWlnaHQ6IDEwMHZoO1xuICBwYWRkaW5nOiAxZW07XG59IiwiaW9uLXRvb2xiYXJ7XG4gICAgLS1iYWNrZ3JvdW5kOiMyMzM5NDI7XG4gICAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgICBjb2xvcjojZmZmO1xuICAgIHBhZGRpbmc6ICA1cHg7XG5cbiAgICBpb24tdGl0bGV7XG4gICAgcGFkZGluZzogMHB4O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICBwYWRkaW5nLWxlZnQ6NDRweDtcbiAgICB9IFxuICAgIGlvbi1pY29ue1xuICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgICAgICBjb2xvcjojZmZmO1xuICAgICAgICBmb250LXNpemU6MjBweDtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIH1cbiAgIFxuICAgIC5zZWFyY2h7XG4gICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgICAgICBmbG9hdDogcmlnaHQ7XG4gICAgfVxuICAgIHB7XG4gICAgICAgIGZsb2F0OnJpZ2h0O1xuICAgICAgICBjb2xvcjojZjc3ZTIxO1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgIG1hcmdpbjogMGVtO1xuICAgIH1cbiAgICBpb24taWNvbi5oZWFydHtcbiAgICAgICAgZmxvYXQ6cmlnaHQ7XG4gICAgfVxuICAgIGlvbi1iYWNrLWJ1dHRvbiB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgfVxufVxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICNmOWY5ZjkgIWltcG9ydGFudDtcbn1cbi5mdW5jdGlvbmFse1xuICAgIC5pbWctYm94e1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIHRleHQtYWxpZ246Y2VudGVyO1xuICAgICAgICBpbWd7XG4gICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgd2lkdGg6MTAwJTtcbiAgICAgICAgfVxuICAgICAgICBpbWcudmlkZW8taWNvbntcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgd2lkdGg6IGF1dG87XG4gICAgICAgICAgbGVmdDogNDQlO1xuICAgICAgICAgIGJvdHRvbTogMjMlO1xuICAgICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICB9XG4gICAgICAgIEgze1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICBsZWZ0OiAwO1xuICAgICAgICAgICAgcmlnaHQ6IDA7XG4gICAgICAgICAgICB0b3A6IDA7XG4gICAgICAgICAgICBsZXR0ZXItc3BhY2luZzogMnB4O1xuICAgICAgICAgICAgZm9udC1zaXplOiAzNnB4O1xuICAgICAgICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgICAgIH1cbiAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogNTglO1xuICAgIGZvbnQtc2l6ZTogNTBweDtcbiAgICB6LWluZGV4OiA5OTk5O1xuICAgIGxlZnQ6IDQzJTtcbiAgICAgICAgfVxuICAgIH1cbn1cbi5mdW5jdGlvbmFsLWNvbnRlbnR7XG5wYWRkaW5nOjIwcHg7XG5oMntcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgICBtYXJnaW46IDA7XG4gICAgcGFkZGluZy1ib3R0b206IDE4cHg7XG59XG4uYm94e1xuICAgIGJhY2tncm91bmQ6IzIzMzk0MjtcbiAgICBwYWRkaW5nOjEwcHg7XG4gICAgY29sb3I6I2ZmZjtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBoNXtcbiAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgICBtYXJnaW4tYm90dG9tOjIwcHg7XG5cbiAgICB9XG59XG59XG4uZnVuY3Rpb25hbHtcbiAgICBiYWNrZ3JvdW5kOiAjZjlmOWY5O1xuICAgIGhlaWdodDoxMDAlO1xufVxuLmNpcmN1aXR7XG4gICAgcGFkZGluZzoyMHB4O1xuICAgIG1hcmdpbjoyMHB4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICMyMjI7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBiYWNrZ3JvdW5kOiNmZmY7XG4gICAgaDN7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gICAgbWFyZ2luOiAwO1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgfVxufVxuLnRhYnMge1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIC8vYm94LXNoYWRvdzogMCA0cHggNHB4IC0ycHggcmdiYSgwLCAwLCAwLCAwLjUpO1xuICB9XG4gIFxuICAudGFiIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIH1cbiAgLnRhYi1sYWJlbCB7XG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcbiAgICAtd2Via2l0LWJveC1wYWNrOiBqdXN0aWZ5O1xuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgICAgICAgICBwYWRkaW5nOjAuOHJlbTtcbiAgICAgICAgICAgIGZvbnQtc2l6ZToxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBjb2xvcjojMjIyO1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuXG4gICAgLyogSWNvbiAqL1xuICB9XG4gIC50YWItbGFiZWw6aG92ZXIge1xuICAgIC8vYmFja2dyb3VuZDogIzFhMjUyZjtcbiAgfVxuICAudGFiLWxhYmVsOjphZnRlciB7XG4gICAgY29udGVudDogXCJcXDI3NkZcIjtcbiAgICB3aWR0aDogMWVtO1xuICAgIGhlaWdodDogMWVtO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuMzVzO1xuICAgIHRyYW5zaXRpb246IGFsbCAuMzVzO1xuICB9XG4gIC50YWItY29udGVudCB7XG4gICAgbWF4LWhlaWdodDogMDtcbiAgICBwYWRkaW5nOiAwIDFlbTtcbiAgICBjb2xvcjogIzJjM2U1MDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbmZvbnQtc2l6ZToxNHB4O1xuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4zNXM7XG4gICAgdHJhbnNpdGlvbjogYWxsIC4zNXM7XG4gIH1cbiAgLnRhYi1jbG9zZSB7XG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICAtd2Via2l0LWJveC1wYWNrOiBlbmQ7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICAgIHBhZGRpbmc6IDFlbTtcbiAgICBmb250LXNpemU6IDAuNzVlbTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAudGFiLWNsb3NlOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kOiAjMWEyNTJmO1xuICB9XG4gIGlucHV0W3R5cGU9Y2hlY2tib3hdOmNoZWNrZWQsIGlucHV0W3R5cGU9cmFkaW9dOmNoZWNrZWR7XG4gICAgICBiYWNrZ3JvdW5kOiAjZjc3ZTIxO1xuICB9XG4gIGlucHV0OmNoZWNrZWQgKyAudGFiLWxhYmVsIHtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICB9XG4gIGlucHV0OmNoZWNrZWQgKyAudGFiLWxhYmVsOjphZnRlciB7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gIH1cblxuICBpbnB1dFt0eXBlPWNoZWNrYm94XSwgaW5wdXRbdHlwZT1yYWRpb10ge1xuICAgIHBhZGRpbmc6IDA7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDEwcHg7XG4gICAgdG9wOiAxNHB4O1xufVxuICBpbnB1dDpjaGVja2VkIH4gLnRhYi1jb250ZW50IHtcbiAgICBtYXgtaGVpZ2h0OiAxMDB2aDtcbiAgICBwYWRkaW5nOiAxZW07XG4gIH1cbiJdfQ== */";
    /***/
  },

  /***/
  "./src/app/mobility-flexibility/mobility-flexibility.page.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/mobility-flexibility/mobility-flexibility.page.ts ***!
    \*******************************************************************/

  /*! exports provided: MobilityFlexibilityPage */

  /***/
  function srcAppMobilityFlexibilityMobilityFlexibilityPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MobilityFlexibilityPage", function () {
      return MobilityFlexibilityPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var MobilityFlexibilityPage = /*#__PURE__*/function () {
      function MobilityFlexibilityPage(navCtrl) {
        _classCallCheck(this, MobilityFlexibilityPage);

        this.navCtrl = navCtrl;
      }

      _createClass(MobilityFlexibilityPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "signup",
        value: function signup() {//this.navCtrl.navigateForward('/exercises');
        }
      }]);

      return MobilityFlexibilityPage;
    }();

    MobilityFlexibilityPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    MobilityFlexibilityPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-mobility-flexibility',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./mobility-flexibility.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/mobility-flexibility/mobility-flexibility.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./mobility-flexibility.page.scss */
      "./src/app/mobility-flexibility/mobility-flexibility.page.scss"))["default"]]
    })], MobilityFlexibilityPage);
    /***/
  }
}]);
//# sourceMappingURL=mobility-flexibility-mobility-flexibility-module-es5.js.map