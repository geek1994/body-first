(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["balance-coordination-balance-coordination-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/balance-coordination/balance-coordination.page.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/balance-coordination/balance-coordination.page.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--<ion-header>\n  <div class=\"header\">\n    <ion-row>\n      <ion-col size=\"1\">\n        <ion-icon name=\"chevron-back-outline\"></ion-icon>\n      </ion-col>\n      <ion-col size=\"9\">\n        <ion-title> BALANCE & COORDINATION</ion-title>\n      </ion-col>\n      <ion-col size=\"2\" text-right>\n    <ion-icon name=\"heart-outline\" class=\"heart\"></ion-icon>\n        \n      </ion-col>\n    </ion-row>\n  </div>\n</ion-header>-->\n<ion-header>\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\" text=\"\" icon=\"chevron-back-outline\" ></ion-back-button>\n    </ion-buttons> -->\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>BALANCE & COORDINATION</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-icon name=\"heart-outline\" class=\"heart\"></ion-icon>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <div class=\"functional\">\n    <div class=\"img-box\">\n      <img src=\"assets/images/f1.png\">\n      <h3>Balance <br />& <br />Coordination</h3>\n      <img src=\"assets/images/video.png\" class=\"video-icon\" />\n    </div>\n\n    <!-- <div class=\"functional-content\">\n   <h2>BALANCE & COORDINATION</h2>\n   <div class=\"box\">\n     <ion-row>\n       <ion-col size=\"6\">\n         <h5>PRIMARY</h5>\n         <img src=\"assets/images/b1.png\">\n       </ion-col>\n       <ion-col size=\"6\">\n         <H5>SECONDARY</H5>\n         <img src=\"assets/images/b2.png\">\n      </ion-col>\n     </ion-row>\n   </div>\n</div> -->\n\n    <div class=\"circuit\">\n      <div class=\"tabs\">\n        <div class=\"tab\">\n          <input type=\"checkbox\" id=\"chck3\">\n          <label class=\"tab-label\" for=\"chck3\">Exercise 1</label>\n          <div class=\"tab-content\">\n            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsum, reiciendis!\n          </div>\n        </div>\n        <div class=\"tab\">\n          <input type=\"checkbox\" id=\"chck4\">\n          <label class=\"tab-label\" for=\"chck4\">Exercise 2</label>\n          <div class=\"tab-content\">\n            Lorem ipsum dolor sit amet consectetur adipisicing elit. A, in!\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/balance-coordination/balance-coordination-routing.module.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/balance-coordination/balance-coordination-routing.module.ts ***!
  \*****************************************************************************/
/*! exports provided: BalanceCoordinationPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BalanceCoordinationPageRoutingModule", function() { return BalanceCoordinationPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _balance_coordination_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./balance-coordination.page */ "./src/app/balance-coordination/balance-coordination.page.ts");




const routes = [
    {
        path: '',
        component: _balance_coordination_page__WEBPACK_IMPORTED_MODULE_3__["BalanceCoordinationPage"]
    }
];
let BalanceCoordinationPageRoutingModule = class BalanceCoordinationPageRoutingModule {
};
BalanceCoordinationPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], BalanceCoordinationPageRoutingModule);



/***/ }),

/***/ "./src/app/balance-coordination/balance-coordination.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/balance-coordination/balance-coordination.module.ts ***!
  \*********************************************************************/
/*! exports provided: BalanceCoordinationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BalanceCoordinationPageModule", function() { return BalanceCoordinationPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _balance_coordination_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./balance-coordination-routing.module */ "./src/app/balance-coordination/balance-coordination-routing.module.ts");
/* harmony import */ var _balance_coordination_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./balance-coordination.page */ "./src/app/balance-coordination/balance-coordination.page.ts");







let BalanceCoordinationPageModule = class BalanceCoordinationPageModule {
};
BalanceCoordinationPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _balance_coordination_routing_module__WEBPACK_IMPORTED_MODULE_5__["BalanceCoordinationPageRoutingModule"]
        ],
        declarations: [_balance_coordination_page__WEBPACK_IMPORTED_MODULE_6__["BalanceCoordinationPage"]]
    })
], BalanceCoordinationPageModule);



/***/ }),

/***/ "./src/app/balance-coordination/balance-coordination.page.scss":
/*!*********************************************************************!*\
  !*** ./src/app/balance-coordination/balance-coordination.page.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@charset \"UTF-8\";\nion-toolbar {\n  --background:#233942;\n  background: #233942;\n  color: #fff;\n  padding: 5px;\n}\nion-toolbar ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  letter-spacing: 1px;\n  padding-left: 44px;\n}\nion-toolbar ion-back-button {\n  font-size: 12px;\n}\nion-toolbar ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n}\nion-toolbar .search {\n  text-align: right;\n  float: right;\n}\nion-toolbar p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\nion-toolbar ion-icon.heart {\n  float: right;\n}\nion-content {\n  --background: #f9f9f9 !important;\n}\n.functional .img-box {\n  position: relative;\n  text-align: center;\n}\n.functional .img-box img {\n  width: 100%;\n  position: relative;\n}\n.functional .img-box img.video-icon {\n  position: absolute;\n  width: auto;\n  left: 44%;\n  bottom: 23%;\n  right: 0;\n}\n.functional .img-box H3 {\n  text-align: center;\n  color: #fff;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 0;\n  letter-spacing: 2px;\n  font-size: 36px;\n  font-family: Rajdhani-Bold;\n}\n.functional .img-box ion-icon {\n  text-align: center;\n  color: #fff;\n  position: absolute;\n  top: 58%;\n  font-size: 50px;\n  z-index: 9999;\n  left: 43%;\n}\n.functional-content {\n  padding: 20px;\n}\n.functional-content h2 {\n  font-family: Rajdhani-Bold;\n}\n.functional-content .box {\n  background: #233942;\n  padding: 10px;\n  color: #fff;\n  text-align: center;\n  border-radius: 10px;\n}\n.functional-content .box h5 {\n  letter-spacing: 1px;\n  font-family: Rajdhani-Regular;\n  margin-bottom: 20px;\n}\n.functional {\n  background: #f9f9f9;\n  height: 100%;\n}\n.circuit {\n  padding: 20px;\n  margin: 20px;\n  border: 1px solid #222;\n  border-radius: 10px;\n  background: #fff;\n}\n.circuit h3 {\n  font-family: Rajdhani-Regular;\n}\n.tabs {\n  border-radius: 8px;\n  overflow: hidden;\n}\n.tab {\n  width: 100%;\n  color: white;\n  overflow: hidden;\n  position: relative;\n}\n.tab-label {\n  display: flex;\n  margin-left: 20px;\n  justify-content: space-between;\n  background: #fff;\n  margin-bottom: 10px;\n  padding: 0.8rem;\n  font-size: 14px;\n  font-weight: bold;\n  cursor: pointer;\n  color: #222;\n  font-family: Rajdhani-Regular;\n  /* Icon */\n}\n.tab-label::after {\n  content: \"❯\";\n  width: 1em;\n  height: 1em;\n  text-align: center;\n  transition: all 0.35s;\n}\n.tab-content {\n  max-height: 0;\n  padding: 0 1em;\n  color: #2c3e50;\n  font-family: Rajdhani-Regular;\n  font-size: 14px;\n  background: white;\n  transition: all 0.35s;\n}\n.tab-close {\n  display: flex;\n  justify-content: flex-end;\n  padding: 1em;\n  font-size: 0.75em;\n  background: #fff;\n  cursor: pointer;\n}\n.tab-close:hover {\n  background: #1a252f;\n}\ninput[type=checkbox]:checked, input[type=radio]:checked {\n  background: #f77e21;\n}\ninput:checked + .tab-label {\n  background: #fff;\n}\ninput:checked + .tab-label::after {\n  transform: rotate(90deg);\n}\ninput[type=checkbox], input[type=radio] {\n  padding: 0;\n  position: absolute;\n  left: 10px;\n  top: 14px;\n}\ninput:checked ~ .tab-content {\n  max-height: 100vh;\n  padding: 1em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYmFsYW5jZS1jb29yZGluYXRpb24vYmFsYW5jZS1jb29yZGluYXRpb24ucGFnZS5zY3NzIiwiL1ZvbHVtZXMvRGlzazIvYm9keUZpcnN0L3NyYy9hcHAvYmFsYW5jZS1jb29yZGluYXRpb24vYmFsYW5jZS1jb29yZGluYXRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQ0FoQjtFQUNJLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBREVKO0FDQUk7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QURFSjtBQ0FJO0VBQ0UsZUFBQTtBREVOO0FDQUk7RUFDSSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FERVI7QUNBSTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtBREVSO0FDQUk7RUFDSSxZQUFBO0VBQ0EsY0FBQTtFQUNBLDBCQUFBO0VBQ0EsV0FBQTtBREVSO0FDQUk7RUFDSSxZQUFBO0FERVI7QUNDQTtFQUNFLGdDQUFBO0FERUY7QUNDSTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7QURFUjtBQ0RRO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0FER1o7QUNEUTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtBREdWO0FDRFE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsTUFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLDBCQUFBO0FER1o7QUNEUTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0VBQ0EsU0FBQTtBREdaO0FDQ0E7RUFDQSxhQUFBO0FERUE7QUNEQTtFQUNJLDBCQUFBO0FER0o7QUNBQTtFQUNJLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FERUo7QUNESTtFQUNJLG1CQUFBO0VBQ0osNkJBQUE7RUFDQSxtQkFBQTtBREdKO0FDRUE7RUFDSSxtQkFBQTtFQUNBLFlBQUE7QURDSjtBQ0NBO0VBQ0ksYUFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QURFSjtBQ0RJO0VBQ0EsNkJBQUE7QURHSjtBQ0NBO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtBREVKO0FDRUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QURDSjtBQ0NFO0VBRUUsYUFBQTtFQUNBLGlCQUFBO0VBRVEsOEJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDUixpQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7RUFFQSxTQUFBO0FEQ0o7QUNJRTtFQUNFLFlBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBRUEscUJBQUE7QURESjtBQ0dFO0VBQ0UsYUFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0EsNkJBQUE7RUFDSixlQUFBO0VBQ0ksaUJBQUE7RUFFQSxxQkFBQTtBREFKO0FDRUU7RUFFRSxhQUFBO0VBRVEseUJBQUE7RUFDUixZQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QURDSjtBQ0NFO0VBQ0UsbUJBQUE7QURFSjtBQ0FFO0VBQ0ksbUJBQUE7QURHTjtBQ0RFO0VBQ0UsZ0JBQUE7QURJSjtBQ0ZFO0VBRVUsd0JBQUE7QURLWjtBQ0ZFO0VBQ0UsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7QURLSjtBQ0hFO0VBQ0UsaUJBQUE7RUFDQSxZQUFBO0FETUoiLCJmaWxlIjoic3JjL2FwcC9iYWxhbmNlLWNvb3JkaW5hdGlvbi9iYWxhbmNlLWNvb3JkaW5hdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAY2hhcnNldCBcIlVURi04XCI7XG5pb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDojMjMzOTQyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogNXB4O1xufVxuaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgcGFkZGluZzogMHB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgcGFkZGluZy1sZWZ0OiA0NHB4O1xufVxuaW9uLXRvb2xiYXIgaW9uLWJhY2stYnV0dG9uIHtcbiAgZm9udC1zaXplOiAxMnB4O1xufVxuaW9uLXRvb2xiYXIgaW9uLWljb24ge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuaW9uLXRvb2xiYXIgLnNlYXJjaCB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBmbG9hdDogcmlnaHQ7XG59XG5pb24tdG9vbGJhciBwIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBjb2xvcjogI2Y3N2UyMTtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gIG1hcmdpbjogMGVtO1xufVxuaW9uLXRvb2xiYXIgaW9uLWljb24uaGVhcnQge1xuICBmbG9hdDogcmlnaHQ7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjZjlmOWY5ICFpbXBvcnRhbnQ7XG59XG5cbi5mdW5jdGlvbmFsIC5pbWctYm94IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uZnVuY3Rpb25hbCAuaW1nLWJveCBpbWcge1xuICB3aWR0aDogMTAwJTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLmZ1bmN0aW9uYWwgLmltZy1ib3ggaW1nLnZpZGVvLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiBhdXRvO1xuICBsZWZ0OiA0NCU7XG4gIGJvdHRvbTogMjMlO1xuICByaWdodDogMDtcbn1cbi5mdW5jdGlvbmFsIC5pbWctYm94IEgzIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgdG9wOiAwO1xuICBsZXR0ZXItc3BhY2luZzogMnB4O1xuICBmb250LXNpemU6IDM2cHg7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xufVxuLmZ1bmN0aW9uYWwgLmltZy1ib3ggaW9uLWljb24ge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNTglO1xuICBmb250LXNpemU6IDUwcHg7XG4gIHotaW5kZXg6IDk5OTk7XG4gIGxlZnQ6IDQzJTtcbn1cblxuLmZ1bmN0aW9uYWwtY29udGVudCB7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG4uZnVuY3Rpb25hbC1jb250ZW50IGgyIHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG59XG4uZnVuY3Rpb25hbC1jb250ZW50IC5ib3gge1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBwYWRkaW5nOiAxMHB4O1xuICBjb2xvcjogI2ZmZjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuLmZ1bmN0aW9uYWwtY29udGVudCAuYm94IGg1IHtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG5cbi5mdW5jdGlvbmFsIHtcbiAgYmFja2dyb3VuZDogI2Y5ZjlmOTtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uY2lyY3VpdCB7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIG1hcmdpbjogMjBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgIzIyMjtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbn1cbi5jaXJjdWl0IGgzIHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG59XG5cbi50YWJzIHtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udGFiIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4udGFiLWxhYmVsIHtcbiAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAtd2Via2l0LWJveC1wYWNrOiBqdXN0aWZ5O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIHBhZGRpbmc6IDAuOHJlbTtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBjb2xvcjogIzIyMjtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG4gIC8qIEljb24gKi9cbn1cblxuLnRhYi1sYWJlbDo6YWZ0ZXIge1xuICBjb250ZW50OiBcIuKdr1wiO1xuICB3aWR0aDogMWVtO1xuICBoZWlnaHQ6IDFlbTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjM1cztcbiAgdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xufVxuXG4udGFiLWNvbnRlbnQge1xuICBtYXgtaGVpZ2h0OiAwO1xuICBwYWRkaW5nOiAwIDFlbTtcbiAgY29sb3I6ICMyYzNlNTA7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjM1cztcbiAgdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xufVxuXG4udGFiLWNsb3NlIHtcbiAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIC13ZWJraXQtYm94LXBhY2s6IGVuZDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgcGFkZGluZzogMWVtO1xuICBmb250LXNpemU6IDAuNzVlbTtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4udGFiLWNsb3NlOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogIzFhMjUyZjtcbn1cblxuaW5wdXRbdHlwZT1jaGVja2JveF06Y2hlY2tlZCwgaW5wdXRbdHlwZT1yYWRpb106Y2hlY2tlZCB7XG4gIGJhY2tncm91bmQ6ICNmNzdlMjE7XG59XG5cbmlucHV0OmNoZWNrZWQgKyAudGFiLWxhYmVsIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbn1cblxuaW5wdXQ6Y2hlY2tlZCArIC50YWItbGFiZWw6OmFmdGVyIHtcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gIHRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbn1cblxuaW5wdXRbdHlwZT1jaGVja2JveF0sIGlucHV0W3R5cGU9cmFkaW9dIHtcbiAgcGFkZGluZzogMDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAxMHB4O1xuICB0b3A6IDE0cHg7XG59XG5cbmlucHV0OmNoZWNrZWQgfiAudGFiLWNvbnRlbnQge1xuICBtYXgtaGVpZ2h0OiAxMDB2aDtcbiAgcGFkZGluZzogMWVtO1xufSIsImlvbi10b29sYmFye1xuICAgIC0tYmFja2dyb3VuZDojMjMzOTQyO1xuICAgIGJhY2tncm91bmQ6ICMyMzM5NDI7XG4gICAgY29sb3I6I2ZmZjtcbiAgICBwYWRkaW5nOiAgNXB4O1xuXG4gICAgaW9uLXRpdGxle1xuICAgIHBhZGRpbmc6IDBweDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gICAgcGFkZGluZy1sZWZ0OiA0NHB4O1xuICAgIH0gXG4gICAgaW9uLWJhY2stYnV0dG9ue1xuICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgIH1cbiAgICBpb24taWNvbntcbiAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICAgICAgY29sb3I6I2ZmZjtcbiAgICAgICAgZm9udC1zaXplOjIwcHg7XG4gICAgfVxuICAgIC5zZWFyY2h7XG4gICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgICAgICBmbG9hdDogcmlnaHQ7XG4gICAgfVxuICAgIHB7XG4gICAgICAgIGZsb2F0OnJpZ2h0O1xuICAgICAgICBjb2xvcjojZjc3ZTIxO1xuICAgICAgICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgICAgICAgbWFyZ2luOiAwZW07XG4gICAgfVxuICAgIGlvbi1pY29uLmhlYXJ0e1xuICAgICAgICBmbG9hdDpyaWdodDtcbiAgICB9XG59XG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogI2Y5ZjlmOSAhaW1wb3J0YW50O1xufVxuLmZ1bmN0aW9uYWx7XG4gICAgLmltZy1ib3h7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgdGV4dC1hbGlnbjpjZW50ZXI7XG4gICAgICAgIGltZ3tcbiAgICAgICAgICAgIHdpZHRoOjEwMCU7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIH1cbiAgICAgICAgaW1nLnZpZGVvLWljb257XG4gICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgIHdpZHRoOiBhdXRvO1xuICAgICAgICAgIGxlZnQ6IDQ0JTtcbiAgICAgICAgICBib3R0b206IDIzJTtcbiAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgfVxuICAgICAgICBIM3tcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICAgICAgdG9wOiAwO1xuICAgICAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDJweDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMzZweDtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgICAgICB9XG4gICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICB0b3A6IDU4JTtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogNTBweDtcbiAgICAgICAgICAgIHotaW5kZXg6IDk5OTk7XG4gICAgICAgICAgICBsZWZ0OiA0MyU7XG4gICAgICAgIH1cbiAgICB9XG59XG4uZnVuY3Rpb25hbC1jb250ZW50e1xucGFkZGluZzoyMHB4O1xuaDJ7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG5cbn1cbi5ib3h7XG4gICAgYmFja2dyb3VuZDojMjMzOTQyO1xuICAgIHBhZGRpbmc6MTBweDtcbiAgICBjb2xvcjojZmZmO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGg1e1xuICAgICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICAgIG1hcmdpbi1ib3R0b206MjBweDtcblxuICAgIH1cbn1cbn1cbi5mdW5jdGlvbmFse1xuICAgIGJhY2tncm91bmQ6ICNmOWY5Zjk7XG4gICAgaGVpZ2h0OjEwMCU7XG59XG4uY2lyY3VpdHtcbiAgICBwYWRkaW5nOjIwcHg7XG4gICAgbWFyZ2luOjIwcHg7XG4gICAgYm9yZGVyOiAxcHggc29saWQgIzIyMjtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGJhY2tncm91bmQ6I2ZmZjtcbiAgICBoM3tcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcblxuICAgIH1cbn1cbi50YWJzIHtcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAvL2JveC1zaGFkb3c6IDAgNHB4IDRweCAtMnB4IHJnYmEoMCwgMCwgMCwgMC41KTtcbiAgfVxuICBcbiAgLnRhYiB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB9XG4gIC50YWItbGFiZWwge1xuICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gICAgLXdlYmtpdC1ib3gtcGFjazoganVzdGlmeTtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgcGFkZGluZzowLjhyZW07XG4gICAgICAgICAgICBmb250LXNpemU6MTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgY29sb3I6IzIyMjtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcblxuICAgIC8qIEljb24gKi9cbiAgfVxuICAudGFiLWxhYmVsOmhvdmVyIHtcbiAgICAvL2JhY2tncm91bmQ6ICMxYTI1MmY7XG4gIH1cbiAgLnRhYi1sYWJlbDo6YWZ0ZXIge1xuICAgIGNvbnRlbnQ6IFwiXFwyNzZGXCI7XG4gICAgd2lkdGg6IDFlbTtcbiAgICBoZWlnaHQ6IDFlbTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjM1cztcbiAgICB0cmFuc2l0aW9uOiBhbGwgLjM1cztcbiAgfVxuICAudGFiLWNvbnRlbnQge1xuICAgIG1heC1oZWlnaHQ6IDA7XG4gICAgcGFkZGluZzogMCAxZW07XG4gICAgY29sb3I6ICMyYzNlNTA7XG4gICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG5mb250LXNpemU6MTRweDtcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuMzVzO1xuICAgIHRyYW5zaXRpb246IGFsbCAuMzVzO1xuICB9XG4gIC50YWItY2xvc2Uge1xuICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgLXdlYmtpdC1ib3gtcGFjazogZW5kO1xuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgICBwYWRkaW5nOiAxZW07XG4gICAgZm9udC1zaXplOiAwLjc1ZW07XG4gICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLnRhYi1jbG9zZTpob3ZlciB7XG4gICAgYmFja2dyb3VuZDogIzFhMjUyZjtcbiAgfVxuICBpbnB1dFt0eXBlPWNoZWNrYm94XTpjaGVja2VkLCBpbnB1dFt0eXBlPXJhZGlvXTpjaGVja2Vke1xuICAgICAgYmFja2dyb3VuZDogI2Y3N2UyMTtcbiAgfVxuICBpbnB1dDpjaGVja2VkICsgLnRhYi1sYWJlbCB7XG4gICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgfVxuICBpbnB1dDpjaGVja2VkICsgLnRhYi1sYWJlbDo6YWZ0ZXIge1xuICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xuICB9XG5cbiAgaW5wdXRbdHlwZT1jaGVja2JveF0sIGlucHV0W3R5cGU9cmFkaW9dIHtcbiAgICBwYWRkaW5nOiAwO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBsZWZ0OiAxMHB4O1xuICAgIHRvcDogMTRweDtcbn1cbiAgaW5wdXQ6Y2hlY2tlZCB+IC50YWItY29udGVudCB7XG4gICAgbWF4LWhlaWdodDogMTAwdmg7XG4gICAgcGFkZGluZzogMWVtO1xuICB9Il19 */");

/***/ }),

/***/ "./src/app/balance-coordination/balance-coordination.page.ts":
/*!*******************************************************************!*\
  !*** ./src/app/balance-coordination/balance-coordination.page.ts ***!
  \*******************************************************************/
/*! exports provided: BalanceCoordinationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BalanceCoordinationPage", function() { return BalanceCoordinationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let BalanceCoordinationPage = class BalanceCoordinationPage {
    constructor() { }
    ngOnInit() {
    }
};
BalanceCoordinationPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-balance-coordination',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./balance-coordination.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/balance-coordination/balance-coordination.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./balance-coordination.page.scss */ "./src/app/balance-coordination/balance-coordination.page.scss")).default]
    })
], BalanceCoordinationPage);



/***/ })

}]);
//# sourceMappingURL=balance-coordination-balance-coordination-module-es2015.js.map