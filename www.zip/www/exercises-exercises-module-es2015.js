(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["exercises-exercises-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/exercises/exercises.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/exercises/exercises.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>EXERCISE</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-icon\n        name=\"search-outline\"\n        class=\"setting\"\n        (click)=\"search()\"\n      ></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"type=='guid'\">\n    <div class=\"mindset-guid\">\n      <img src=\"assets/images/e-bg.jpg\" />\n      <div class=\"mindset-guid-head\">\n        <h4>EXERCISE PRINCIPLE</h4>\n      </div>\n      <div class=\"exercise-img\">\n        <img src=\"assets/images/overview.png\"/>\n      </div>\n      <div class=\"mindset-data\">\n        <div class=\"mindset-principle\">\n          <h5>Overview</h5>\n          <p>\n            The exercise principle consists of 4 Core Modules: mobility &\n            flexibility, balance & coordination, core & conditioning, and\n            functional resistance strength training. Committing to this model\n            and following the plan is essential to your success. It will help\n            improve circulation, range of motion, alleviate daily aches & pains,\n            sharpen awareness, while increasing strength and conditioning. No\n            matter where you are in your fitness journey this structure will\n            help you reach your greatest potential. Research has shown that\n            interval training is highly effective in transforming your physique\n            and creating a greater post-exercise oxygen consumption that will\n            keep your metabolism running higher for several hours after your\n            workout. Plus the additional positive health benefits like;\n            increased cardiovascular health, decreased risk of osteoporosis,\n            physically stronger, reduced risk of injury & diabetes, improves\n            your attitude and fights depression. Recording your base assessment\n            information is essential in getting started because it is difficult\n            to decide where you want to go if you don’t know where you are\n            starting. This will include total body weight, body fat percentage,\n            lean body mass, measurements and pictures.\n          </p>\n          <br />\n          <h5>Assessment Information</h5>\n          <p>\n            It’s important for you to understand a little about your body\n            composition to help you set realistic goals. Three important numbers\n            are used in your body composition: body weight, body fat mass and\n            lean body mass. Your body fat mass is usually looked at as a body\n            fat percentage (BF%): this is the percentage of body fat mass from\n            your total body weight. A lower BF% is a good indicator of your\n            health.\n          </p>\n          <p>\n            Your body weight is the total of your body fat and your lean body\n            mass (which includes not only your muscle mass also tissue, organs,\n            bones, body water, etc…) It’s important that you focus on losing\n            more body fat (lowering BF%) and not just weight, as you can see\n            many aspects make up your total body weight.\n          </p>\n          <p>\n            Remember when you increase your muscle mass you will be increasing\n            your metabolism which will increase the burning of fat (this is what\n            we all desire).\n          </p>\n          <p>\n            Also, your body weight can fluctuate daily since it is influenced by\n            many different factors: stomach/bladder/bowel content, water\n            retention/loss, muscle mass loss/gain and fat loss/gain. So you can\n            see how just looking at body weight alone is not the best indicator\n            of the changes that are occurring in your body and can be very\n            deceiving.\n          </p>\n          <p>\n            When logging your assessment information I recommend using a scale\n            that not only has your weight but also your body fat mass or BF%. If\n            you do not have a scale that will give you these numbers, most\n            nutrition shops will have the type of scale with this information\n            (the more detailed the info the better you will be able to track\n            your progress). It’s important for you to stick with the same scale\n            throughout the program to track your progress (different scales can\n            give slightly different readings based on calibration, so stay\n            consistent and use the same device).\n          </p>\n          <p>\n            Hydration can also play a factor in muscle mass as your muscles are\n            made up of around 75% water and it also helps with proper organ\n            function (see the hydration section in the nutrition element guide).\n          </p>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>Assessment</h5>\n          <div>\n            <p>- Fill out the assessment guide with measurements.</p>\n            <p>- Take starting pictures and progress pictures each month.</p>\n            <p>- Do your assessment every two weeks to track your progress.</p>\n          </div>\n          <div class=\"dfd\">\n            <div class=\"df-input\">\n              <ion-row>\n                <ion-col>\n                  <ion-label>Body Weight</ion-label>\n                  <ion-input class=\"weight\"></ion-input>\n                </ion-col>\n                <ion-col>\n                  <ion-label>Body Fat</ion-label>\n                  <ion-input class=\"weight\"></ion-input>\n                </ion-col>\n              </ion-row>\n            </div>\n            <img src=\"assets/images/dfd.png\"/>\n          </div>\n        </div>\n        <div class=\"overview\">\n          <ion-row>\n            <ion-col>\n              <ion-label>Chest</ion-label>\n              <ion-input></ion-input>\n              </ion-col>\n              <ion-col>\n                <ion-label>Neck</ion-label>\n                <ion-input></ion-input>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col>\n              <ion-label>Shoulder</ion-label>\n              <ion-input></ion-input>\n              </ion-col>\n              <ion-col>\n                <ion-label>Left Bicep</ion-label>\n                <ion-input></ion-input>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col>\n              <ion-label>Right Bicep</ion-label>\n              <ion-input></ion-input>\n              </ion-col>\n              <ion-col>\n                <ion-label>Left Forearm</ion-label>\n                <ion-input></ion-input>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col>\n              <ion-label>Right Forearm</ion-label>\n              <ion-input></ion-input>\n              </ion-col>\n              <ion-col>\n                <ion-label>Waist</ion-label>\n                <ion-input></ion-input>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col>\n              <ion-label>Hips</ion-label>\n              <ion-input></ion-input>\n              </ion-col>\n              <ion-col>\n                <ion-label>Left Thigh</ion-label>\n                <ion-input></ion-input>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col>\n              <ion-label>Right Thigh</ion-label>\n              <ion-input></ion-input>\n              </ion-col>\n              <ion-col>\n                <ion-label>Left Calf</ion-label>\n                <ion-input></ion-input>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col>\n              <ion-label>Right Calf</ion-label>\n              <ion-input></ion-input>\n              </ion-col>\n          </ion-row>\n        </div>\n        <div class=\"mindset-principle\">\n          <h5>Exercise</h5>\n          <div>\n            <p>\n              Exercise principle consists of 4 Core Modules in this order:\n              mobility & flexibility, balance & coordination, core &\n              conditioning, and functional resistance strength training.\n              Committing to this model will help improve circulation, range of\n              motion, alleviate daily aches and pains, sharpen awareness,\n              increases strength and conditioning, while creating a more durable\n              structure. No matter where you are in your fitness journey this\n              format will help you reach your greatest potential.\n            </p>\n            <p>- The Mobility & Flexibility component.</p>\n            <p>- Next is Balance & Coordination component.</p>\n            <p>- Then Core & Conditioning component.</p>\n            <p>\n              - Lastly is Functional Resistance Strength Training component.\n            </p>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <div class=\"sample-size-container\">\n            <div class=\"sample-text-container\">\n              <p><b>CONSISTENCY IS KEY! </b></p>\n            </div>\n            <div class=\"sample-image-container\">\n              <img src=\"assets/images/consistancyiskey.png\" />\n            </div>\n          </div>\n          <div>\n            <h5>\n              Trainings\n            </h5>\n            <p>\n              - Schedule your workouts and commit to them (consistency is key).\n            </p>\n            <p>\n              - No matter what your fitness level is following the series\n              sequence of Mobility & Flexibility, Balance & Coordination then\n              Core & Conditioning is recommended.\n            </p>\n            <p>\n              - Based on your level of conditioning and/or the time available to\n              train, you can modify each days routine by doing fewer sets or\n              circuits.\n            </p>\n            <p>\n              - Challenge yourself in your workouts, however, listen to your\n              body and don’t over do it.\n            </p>\n            <p>- Using proper form is essential to prevent injury.</p>\n            <p>- Increase your weights to keep the exercises challenging.</p>\n            <p>- Adjust your training intensity based on your progress.</p>\n            <p>\n              - Active recovery days Mobility & Flexibility, Balance &\n              Coordination or Core & Conditioning is recommended.\n            </p>\n            <p>- Passive recovery days will be full rest days.</p>\n          </div>\n        </div>\n\n        <div class=\"mindset-principle\">\n          <h5>\n            Goal Setting (Refer to the Getting Started Guide for Goal Setting\n            Instructions)\n          </h5>\n          <p>\n            Set 1 to 3 goals to strengthen your mindset (example: meditate,\n            pray, journal daily)\n          </p>\n          <p class=\"goal-input\">1. <input type=\"text\" /></p>\n          <p class=\"goal-input\">2. <input type=\"text\" /></p>\n          <p class=\"goal-input\">3. <input type=\"text\" /></p>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"exercises\" *ngIf=\"type=='videos'\">\n    <div\n      class=\"box\"\n      style=\"\n        border-radius: 10px;\n        background: url(assets/images/e3.jpg);\n        background-position: right;\n        background-repeat: no-repeat;\n        width: 100%;\n        height: 130px;\n        background-size: cover;\n      \"\n    >\n      <h4 (click)=\"mobility()\">Guid</h4>\n    </div>\n    <div\n      class=\"box\"\n      style=\"\n        border-radius: 10px;\n        background: url(assets/images/e3.jpg);\n        background-position: right;\n        background-repeat: no-repeat;\n        width: 100%;\n        height: 130px;\n        background-size: cover;\n      \"\n    >\n      <h4 (click)=\"mobility()\">Mobility & Flexibility</h4>\n    </div>\n    <div\n      class=\"box\"\n      style=\"\n        border-radius: 10px;\n        background: url(assets/images/e3.jpg);\n        background-position: right;\n        background-repeat: no-repeat;\n        width: 100%;\n        height: 130px;\n        background-size: cover;\n      \"\n    >\n      <h4 (click)=\"balance()\">Balance & Coordination</h4>\n    </div>\n    <div\n      class=\"box\"\n      style=\"\n        border-radius: 10px;\n        background: url(assets/images/e3.jpg);\n        background-position: right;\n        background-repeat: no-repeat;\n        width: 100%;\n        height: 130px;\n        background-size: cover;\n      \"\n    >\n      <h4 (click)=\"core()\">Core & Conditioning</h4>\n    </div>\n    <div\n      class=\"box\"\n      style=\"\n        border-radius: 10px;\n        background: url(assets/images/e3.jpg);\n        background-position: right;\n        background-repeat: no-repeat;\n        width: 100%;\n        height: 130px;\n        background-size: cover;\n      \"\n    >\n      <h4 (click)=\"functional()\">\n        <!-- Functional Resistance Training Program -->\n        Functional Resistance Strength Training\n      </h4>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/exercises/exercises-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/exercises/exercises-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: ExercisesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExercisesPageRoutingModule", function() { return ExercisesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _exercises_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./exercises.page */ "./src/app/exercises/exercises.page.ts");




const routes = [
    {
        path: '',
        component: _exercises_page__WEBPACK_IMPORTED_MODULE_3__["ExercisesPage"]
    }
];
let ExercisesPageRoutingModule = class ExercisesPageRoutingModule {
};
ExercisesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ExercisesPageRoutingModule);



/***/ }),

/***/ "./src/app/exercises/exercises.module.ts":
/*!***********************************************!*\
  !*** ./src/app/exercises/exercises.module.ts ***!
  \***********************************************/
/*! exports provided: ExercisesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExercisesPageModule", function() { return ExercisesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _exercises_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./exercises-routing.module */ "./src/app/exercises/exercises-routing.module.ts");
/* harmony import */ var _exercises_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./exercises.page */ "./src/app/exercises/exercises.page.ts");







let ExercisesPageModule = class ExercisesPageModule {
};
ExercisesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _exercises_routing_module__WEBPACK_IMPORTED_MODULE_5__["ExercisesPageRoutingModule"]
        ],
        declarations: [_exercises_page__WEBPACK_IMPORTED_MODULE_6__["ExercisesPage"]]
    })
], ExercisesPageModule);



/***/ }),

/***/ "./src/app/exercises/exercises.page.scss":
/*!***********************************************!*\
  !*** ./src/app/exercises/exercises.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header {\n  --background: #233942;\n  background: #233942;\n  color: #fff;\n}\n.header ion-title {\n  padding: 0px;\n  text-align: left;\n  font-family: Rajdhani-Regular;\n  padding-left: 50px;\n  letter-spacing: 1px;\n}\n.header ion-menu-button {\n  color: #fff;\n}\n.header ion-icon {\n  vertical-align: middle;\n  color: #fff;\n  font-size: 20px;\n  margin-right: 10px;\n}\n.header p {\n  float: right;\n  color: #f77e21;\n  font-family: Rajdhani-Bold;\n  margin: 0em;\n}\nion-content {\n  font-family: Rajdhani-Regular;\n}\nion-content p {\n  text-align: justify;\n  font-family: Rajdhani-Regular;\n}\n.mindset-guid-head {\n  padding: 5px 16px;\n  margin-top: 10px;\n  color: #fff;\n  background-image: url('heading-bg.png');\n  width: 100%;\n  background-position: center;\n}\n.mindset-guid-head h4 {\n  padding: 5px 0px;\n  margin: 0;\n}\n.mindset-data {\n  padding: 16px;\n}\n.mindset-data .mindset-principle h5 {\n  font-size: 20px;\n  font-weight: 600;\n  color: #e7863d;\n}\np.goal-input input {\n  width: 90%;\n  margin-left: 10px;\n  border: none;\n  outline: none;\n}\n.exercise-img {\n  padding: 20px;\n}\np.goal-input {\n  border-bottom: 1px solid #000;\n}\n.sample-size-container {\n  background: #e2e2e2;\n  color: #fff;\n  height: 100px;\n}\n.sample-text-container {\n  width: 40%;\n  display: inline-block;\n  height: 100px;\n  vertical-align: middle;\n  padding: 0px 10px;\n}\n.sample-text-container p {\n  margin: 0px;\n}\n.sample-image-container {\n  width: 60%;\n  display: inline-block;\n  height: 100px;\n}\n.sample-image-container img {\n  width: 100%;\n  height: 100px;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n.exercises {\n  padding: 20px;\n}\n.exercises .box {\n  width: 100%;\n  height: 100%;\n  padding: 10px 20px;\n  margin-bottom: 20px;\n}\n.exercises .box h4 {\n  text-align: left;\n  color: #fff;\n  font-family: Rajdhani-Bold;\n  font-size: 18px;\n  line-height: 24px;\n  letter-spacing: 1px;\n  width: 48%;\n  margin: 8px 0;\n  word-break: break-word;\n}\n.dfd .df-input ion-input {\n  border: 1px solid #ddd;\n  margin-top: 10px;\n}\n.overview ion-input {\n  border: 1px solid #ddd;\n  margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL0Rpc2syL2JvZHlGaXJzdC9zcmMvYXBwL2V4ZXJjaXNlcy9leGVyY2lzZXMucGFnZS5zY3NzIiwic3JjL2FwcC9leGVyY2lzZXMvZXhlcmNpc2VzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FDQ0Y7QURFRTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0FKO0FERUU7RUFDRSxXQUFBO0FDQUo7QURFRTtFQUNFLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ0FKO0FERUU7RUFDRSxZQUFBO0VBQ0EsY0FBQTtFQUNBLDBCQUFBO0VBQ0EsV0FBQTtBQ0FKO0FER0E7RUFDRSw2QkFBQTtBQ0FGO0FEQ0U7RUFDRSxtQkFBQTtFQUNGLDZCQUFBO0FDQ0Y7QURJQTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFFQSxXQUFBO0VBQ0EsdUNBQUE7RUFDRSxXQUFBO0VBQ0EsMkJBQUE7QUNGSjtBREdFO0VBQ0UsZ0JBQUE7RUFDQSxTQUFBO0FDREo7QURLQTtFQUNFLGFBQUE7QUNGRjtBREtJO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ0hOO0FEWUE7RUFDRSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQ1ZGO0FEWUE7RUFDRSxhQUFBO0FDVEY7QURXQTtFQUNFLDZCQUFBO0FDUkY7QURXQTtFQUNFLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7QUNSRjtBRFlBO0VBQ0ksVUFBQTtFQUNBLHFCQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7QUNUSjtBRFVJO0VBQ0UsV0FBQTtBQ1JOO0FEWUE7RUFDSSxVQUFBO0VBQ0EscUJBQUE7RUFDQSxhQUFBO0FDVEo7QURVSTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtBQ1JOO0FEWUE7RUFDRSxhQUFBO0FDVEY7QURVRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ1JKO0FEU0k7RUFDRSxnQkFBQTtFQUNBLFdBQUE7RUFDQSwwQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsVUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtBQ1BOO0FEYUk7RUFDRSxzQkFBQTtFQUNBLGdCQUFBO0FDVk47QURlRTtFQUNFLHNCQUFBO0VBQ0EsZ0JBQUE7QUNaSiIsImZpbGUiOiJzcmMvYXBwL2V4ZXJjaXNlcy9leGVyY2lzZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlciB7XG4gIC0tYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgYmFja2dyb3VuZDogIzIzMzk0MjtcbiAgY29sb3I6ICNmZmY7XG4gIC8vcGFkZGluZzogIDE2cHg7XG5cbiAgaW9uLXRpdGxlIHtcbiAgICBwYWRkaW5nOiAwcHg7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgICBwYWRkaW5nLWxlZnQ6IDUwcHg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgfVxuICBpb24tbWVudS1idXR0b24ge1xuICAgIGNvbG9yOiAjZmZmO1xuICB9XG4gIGlvbi1pY29uIHtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIH1cbiAgcCB7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGNvbG9yOiAjZjc3ZTIxO1xuICAgIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1Cb2xkO1xuICAgIG1hcmdpbjogMGVtO1xuICB9XG59XG5pb24tY29udGVudCB7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuICBwe1xuICAgIHRleHQtYWxpZ246IGp1c3RpZnk7XG4gIGZvbnQtZmFtaWx5OiBSYWpkaGFuaS1SZWd1bGFyO1xuXG4gIH1cbn1cblxuLm1pbmRzZXQtZ3VpZC1oZWFkIHtcbiAgcGFkZGluZzogNXB4IDE2cHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIC8vYmFja2dyb3VuZDogI2U3ODYzZDtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtaW1hZ2U6dXJsKC4uLy4uL2Fzc2V0cy9pbWFnZXMvaGVhZGluZy1iZy5wbmcpO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgaDQge1xuICAgIHBhZGRpbmc6IDVweCAwcHg7XG4gICAgbWFyZ2luOiAwO1xuICB9XG59XG5cbi5taW5kc2V0LWRhdGEge1xuICBwYWRkaW5nOiAxNnB4O1xuXG4gIC5taW5kc2V0LXByaW5jaXBsZSB7XG4gICAgaDUge1xuICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgIGNvbG9yOiAjZTc4NjNkO1xuICAgIH1cblxuICAgIHAge1xuICAgICAgLy8gdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgICB9XG4gIH1cbn1cblxucC5nb2FsLWlucHV0IGlucHV0IHtcbiAgd2lkdGg6IDkwJTtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbn1cbi5leGVyY2lzZS1pbWcge1xuICBwYWRkaW5nOiAyMHB4O1xufVxucC5nb2FsLWlucHV0IHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMwMDA7XG59XG5cbi5zYW1wbGUtc2l6ZS1jb250YWluZXIge1xuICBiYWNrZ3JvdW5kOiAjZTJlMmUyO1xuICBjb2xvcjogI2ZmZjtcbiAgaGVpZ2h0OiAxMDBweDtcbn1cblxuXG4uc2FtcGxlLXRleHQtY29udGFpbmVyIHtcbiAgICB3aWR0aDogNDAlO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgcGFkZGluZzogMHB4IDEwcHg7XG4gICAgcCB7XG4gICAgICBtYXJnaW46IDBweDtcbiAgICB9XG59XG5cbi5zYW1wbGUtaW1hZ2UtY29udGFpbmVyIHtcbiAgICB3aWR0aDogNjAlO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICAgIGltZyB7XG4gICAgICB3aWR0aDogMTAwJTtcbiAgICAgIGhlaWdodDogMTAwcHg7XG4gICAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgICB9XG59XG5cbi5leGVyY2lzZXMge1xuICBwYWRkaW5nOiAyMHB4O1xuICAuYm94IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgcGFkZGluZzogMTBweCAyMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gICAgaDQge1xuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICBsaW5lLWhlaWdodDogMjRweDtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gICAgICB3aWR0aDogNDglO1xuICAgICAgbWFyZ2luOiA4cHggMDtcbiAgICAgIHdvcmQtYnJlYWs6IGJyZWFrLXdvcmQ7XG4gICAgfVxuICB9XG59XG4uZGZkIHtcbiAgLmRmLWlucHV0e1xuICAgIGlvbi1pbnB1dHtcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XG4gICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICB9XG4gIH1cbn1cbi5vdmVydmlld3tcbiAgaW9uLWlucHV0e1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbn1cbn0iLCIuaGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBiYWNrZ3JvdW5kOiAjMjMzOTQyO1xuICBjb2xvcjogI2ZmZjtcbn1cbi5oZWFkZXIgaW9uLXRpdGxlIHtcbiAgcGFkZGluZzogMHB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LWZhbWlseTogUmFqZGhhbmktUmVndWxhcjtcbiAgcGFkZGluZy1sZWZ0OiA1MHB4O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xufVxuLmhlYWRlciBpb24tbWVudS1idXR0b24ge1xuICBjb2xvcjogI2ZmZjtcbn1cbi5oZWFkZXIgaW9uLWljb24ge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG4uaGVhZGVyIHAge1xuICBmbG9hdDogcmlnaHQ7XG4gIGNvbG9yOiAjZjc3ZTIxO1xuICBmb250LWZhbWlseTogUmFqZGhhbmktQm9sZDtcbiAgbWFyZ2luOiAwZW07XG59XG5cbmlvbi1jb250ZW50IHtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG59XG5pb24tY29udGVudCBwIHtcbiAgdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLVJlZ3VsYXI7XG59XG5cbi5taW5kc2V0LWd1aWQtaGVhZCB7XG4gIHBhZGRpbmc6IDVweCAxNnB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKC4uLy4uL2Fzc2V0cy9pbWFnZXMvaGVhZGluZy1iZy5wbmcpO1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xufVxuLm1pbmRzZXQtZ3VpZC1oZWFkIGg0IHtcbiAgcGFkZGluZzogNXB4IDBweDtcbiAgbWFyZ2luOiAwO1xufVxuXG4ubWluZHNldC1kYXRhIHtcbiAgcGFkZGluZzogMTZweDtcbn1cbi5taW5kc2V0LWRhdGEgLm1pbmRzZXQtcHJpbmNpcGxlIGg1IHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogI2U3ODYzZDtcbn1cbnAuZ29hbC1pbnB1dCBpbnB1dCB7XG4gIHdpZHRoOiA5MCU7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG5cbi5leGVyY2lzZS1pbWcge1xuICBwYWRkaW5nOiAyMHB4O1xufVxuXG5wLmdvYWwtaW5wdXQge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzAwMDtcbn1cblxuLnNhbXBsZS1zaXplLWNvbnRhaW5lciB7XG4gIGJhY2tncm91bmQ6ICNlMmUyZTI7XG4gIGNvbG9yOiAjZmZmO1xuICBoZWlnaHQ6IDEwMHB4O1xufVxuXG4uc2FtcGxlLXRleHQtY29udGFpbmVyIHtcbiAgd2lkdGg6IDQwJTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBoZWlnaHQ6IDEwMHB4O1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBwYWRkaW5nOiAwcHggMTBweDtcbn1cbi5zYW1wbGUtdGV4dC1jb250YWluZXIgcCB7XG4gIG1hcmdpbjogMHB4O1xufVxuXG4uc2FtcGxlLWltYWdlLWNvbnRhaW5lciB7XG4gIHdpZHRoOiA2MCU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgaGVpZ2h0OiAxMDBweDtcbn1cbi5zYW1wbGUtaW1hZ2UtY29udGFpbmVyIGltZyB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMHB4O1xuICBvYmplY3QtZml0OiBjb3Zlcjtcbn1cblxuLmV4ZXJjaXNlcyB7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG4uZXhlcmNpc2VzIC5ib3gge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBwYWRkaW5nOiAxMHB4IDIwcHg7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG4uZXhlcmNpc2VzIC5ib3ggaDQge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1mYW1pbHk6IFJhamRoYW5pLUJvbGQ7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gIHdpZHRoOiA0OCU7XG4gIG1hcmdpbjogOHB4IDA7XG4gIHdvcmQtYnJlYWs6IGJyZWFrLXdvcmQ7XG59XG5cbi5kZmQgLmRmLWlucHV0IGlvbi1pbnB1dCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5vdmVydmlldyBpb24taW5wdXQge1xuICBib3JkZXI6IDFweCBzb2xpZCAjZGRkO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/exercises/exercises.page.ts":
/*!*********************************************!*\
  !*** ./src/app/exercises/exercises.page.ts ***!
  \*********************************************/
/*! exports provided: ExercisesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExercisesPage", function() { return ExercisesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _search_exercises_search_exercises_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ..//search-exercises/search-exercises.page */ "./src/app/search-exercises/search-exercises.page.ts");





let ExercisesPage = class ExercisesPage {
    constructor(navCtrl, router, route, modalController) {
        this.navCtrl = navCtrl;
        this.router = router;
        this.route = route;
        this.modalController = modalController;
        this.type = "guid";
        this.route.queryParams.subscribe((params) => {
            this.type = params["type"];
        });
    }
    search() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _search_exercises_search_exercises_page__WEBPACK_IMPORTED_MODULE_4__["SearchExercisesPage"]
            });
            return yield modal.present();
        });
    }
    mobility() {
        this.navCtrl.navigateForward("/mobility-flexibility");
    }
    balance() {
        this.navCtrl.navigateForward("/balance-coordination");
    }
    core() {
        this.navCtrl.navigateForward("/core-conditioning");
    }
    functional() {
        this.navCtrl.navigateForward("/functional");
    }
    // search() {
    //   this.navCtrl.navigateForward("/search-exercises");
    // }
    ngOnInit() { }
};
ExercisesPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
ExercisesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-exercises",
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./exercises.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/exercises/exercises.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./exercises.page.scss */ "./src/app/exercises/exercises.page.scss")).default]
    })
], ExercisesPage);



/***/ })

}]);
//# sourceMappingURL=exercises-exercises-module-es2015.js.map